<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Data Mata Kuliah';
$currentModule = 'data-akademik';

$conn = getDBConnection();

$search = $_GET['search'] ?? '';
$prodi_filter = intval($_GET['prodi'] ?? 0);
$semester_filter = intval($_GET['semester'] ?? 0);

$query = "SELECT mk.*, p.nama_prodi, d.nama_dosen 
          FROM mata_kuliah mk 
          LEFT JOIN program_studi p ON mk.prodi_id = p.id 
          LEFT JOIN dosen d ON mk.dosen_pengampu_id = d.id 
          WHERE 1=1";

if ($search) {
    $query .= " AND (mk.kode_mk LIKE '%" . $conn->real_escape_string($search) . "%' OR mk.nama_mk LIKE '%" . $conn->real_escape_string($search) . "%')";
}
if ($prodi_filter) {
    $query .= " AND mk.prodi_id = $prodi_filter";
}
if ($semester_filter) {
    $query .= " AND mk.semester = $semester_filter";
}

$query .= " ORDER BY mk.semester, mk.kode_mk";
$mk_list = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Data Mata Kuliah</h1>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="tambah.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Tambah Mata Kuliah
        </a>
        <?php endif; ?>
    </div>
    
    <!-- Search and Filter -->
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="text" name="search" placeholder="Cari kode atau nama MK..." 
                   value="<?= htmlspecialchars($search) ?>"
                   class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            <select name="prodi" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Prodi</option>
                <?php foreach ($prodi_list as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $prodi_filter == $p['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nama_prodi']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="semester" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Semester</option>
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <option value="<?= $i ?>" <?= $semester_filter == $i ? 'selected' : '' ?>>
                        Semester <?= $i ?>
                    </option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    
    <!-- Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Kode MK</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama MK</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Prodi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">SKS</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jenis</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Dosen</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($mk_list)): ?>
                        <tr>
                            <td colspan="9" class="px-6 py-4 text-center text-gray-500">Tidak ada data mata kuliah</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($mk_list as $mk): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($mk['kode_mk']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($mk['nama_mk']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($mk['nama_prodi']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $mk['semester'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $mk['sks'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 rounded text-xs <?= $mk['jenis'] === 'wajib' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>">
                                    <?= ucfirst($mk['jenis']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($mk['nama_dosen'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($mk['status']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $mk['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                <a href="edit.php?id=<?= $mk['id'] ?>" class="text-green-600 hover:text-green-700 mr-3" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="jadwal.php?id=<?= $mk['id'] ?>" class="text-purple-600 hover:text-purple-700 mr-3" title="Jadwal">
                                    <i class="fas fa-calendar"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (in_array($_SESSION['role'], ['admin', 'dosen'])): ?>
                                <a href="prasyarat.php?id=<?= $mk['id'] ?>" class="text-orange-600 hover:text-orange-700" title="Prasyarat">
                                    <i class="fas fa-link"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



