<?php
require_once 'includes/auth.php';

$pdo = getConnection();
$page_title = 'Detail Berita';
$berita = null;
$komentar = [];
$error = '';

$id = $_GET['id'] ?? 0;

if ($id) {
    try {
        $stmt = $pdo->prepare("
            SELECT b.*, u.nama AS penulis
            FROM berita_desa b
            LEFT JOIN users u ON u.id = b.id_user
            WHERE b.id = :id AND b.is_published = 1
        ");
        $stmt->execute(['id' => $id]);
        $berita = $stmt->fetch();

        if ($berita) {
            $stmtKomentar = $pdo->prepare("
                SELECT k.*, u.nama
                FROM komentar_berita k
                LEFT JOIN users u ON u.id = k.id_user
                WHERE k.id_berita = :id
                ORDER BY k.created_at DESC
            ");
            $stmtKomentar->execute(['id' => $id]);
            $komentar = $stmtKomentar->fetchAll();
        } else {
            $error = 'Berita tidak ditemukan.';
        }
    } catch (PDOException $e) {
        error_log('Berita detail error: ' . $e->getMessage());
        $error = 'Terjadi kesalahan saat memuat berita.';
    }
} else {
    $error = 'Berita tidak ditemukan.';
}

include 'includes/header.php';
?>

<div class="container my-4">
    <a href="berita.php" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left me-1"></i> Kembali</a>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo esc($error); ?></div>
    <?php elseif ($berita): ?>
        <article class="card mb-4">
            <div class="card-body">
                <h2><?php echo esc($berita['judul']); ?></h2>
                <p class="text-muted">
                    Dipublikasi <?php echo date('d M Y', strtotime($berita['tanggal_publish'] ?? $berita['created_at'])); ?>
                    oleh <?php echo esc($berita['penulis'] ?? 'Admin Desa'); ?>
                </p>
                <?php if (!empty($berita['gambar_utama'])): ?>
                    <img src="uploads/<?php echo esc($berita['gambar_utama']); ?>" class="img-fluid rounded mb-3" alt="<?php echo esc($berita['judul']); ?>">
                <?php endif; ?>
                <div><?php echo $berita['konten']; ?></div>
            </div>
        </article>

        <section class="card">
            <div class="card-header">
                <h4>Komentar Warga</h4>
            </div>
            <div class="card-body">
                <?php if (empty($komentar)): ?>
                    <p class="text-muted">Belum ada komentar.</p>
                <?php else: ?>
                    <?php foreach ($komentar as $kom): ?>
                        <div class="mb-3">
                            <strong><?php echo esc($kom['nama'] ?? 'Warga'); ?></strong>
                            <small class="text-muted d-block"><?php echo date('d M Y H:i', strtotime($kom['created_at'])); ?></small>
                            <p><?php echo nl2br(esc($kom['komentar'])); ?></p>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>











