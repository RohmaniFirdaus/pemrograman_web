<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Laporan KRS & KHS';
$currentModule = 'laporan';

$conn = getDBConnection();

$filter_prodi = intval($_GET['prodi'] ?? 0);
$filter_semester = intval($_GET['semester'] ?? 0);
$filter_kelas = $_GET['kelas'] ?? '';

// Get KRS & KHS data
$query = "
    SELECT m.*, p.nama_prodi,
           (SELECT COUNT(*) FROM krs WHERE mahasiswa_id = m.id AND status = 'approved') as jumlah_krs,
           (SELECT AVG(ip_semester) FROM khs WHERE mahasiswa_id = m.id) as rata_ip,
           m.ipk
    FROM mahasiswa m
    JOIN program_studi p ON m.prodi_id = p.id
    WHERE m.status = 'active'
";

if ($filter_prodi) {
    $query .= " AND m.prodi_id = $filter_prodi";
}
if ($filter_semester) {
    $query .= " AND m.semester = $filter_semester";
}

$query .= " ORDER BY m.ipk DESC, m.nim";

$data = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Laporan KRS & KHS</h1>
        <a href="export.php?type=krs-khs" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export Excel
        </a>
    </div>
    
    <!-- Filter -->
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="prodi" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Prodi</option>
                <?php foreach ($prodi_list as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $filter_prodi == $p['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nama_prodi']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="semester" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Semester</option>
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <option value="<?= $i ?>" <?= $filter_semester == $i ? 'selected' : '' ?>>
                        Semester <?= $i ?>
                    </option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Filter
            </button>
            <a href="krs-khs.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 text-center">
                Reset
            </a>
        </form>
    </div>
    
    <!-- Data Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Prodi</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Jumlah KRS</th>
                        <th class="px-4 py-2 text-left">Rata IP</th>
                        <th class="px-4 py-2 text-left">IPK</th>
                        <th class="px-4 py-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $index => $d): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $index + 1 ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nim']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_mahasiswa']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_prodi']) ?></td>
                        <td class="px-4 py-2"><?= $d['semester'] ?></td>
                        <td class="px-4 py-2"><?= $d['jumlah_krs'] ?></td>
                        <td class="px-4 py-2"><?= $d['rata_ip'] ? number_format($d['rata_ip'], 2) : '-' ?></td>
                        <td class="px-4 py-2 font-semibold"><?= number_format($d['ipk'], 2) ?></td>
                        <td class="px-4 py-2">
                            <a href="../nilai/khs.php?mahasiswa_id=<?= $d['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3">
                                <i class="fas fa-eye"></i> KHS
                            </a>
                            <a href="../nilai/transkrip.php?mahasiswa_id=<?= $d['id'] ?>" class="text-green-600 hover:text-green-700">
                                <i class="fas fa-file"></i> Transkrip
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



