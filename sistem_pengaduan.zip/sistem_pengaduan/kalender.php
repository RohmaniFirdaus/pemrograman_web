<?php
require_once 'includes/auth.php';

$pdo = getConnection();
$page_title = 'Kalender Desa';

$events = [];
try {
    $stmt = $pdo->query("
        SELECT * FROM kalender_desa
        ORDER BY tanggal_mulai ASC
    ");
    $events = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Kalender error: ' . $e->getMessage());
}

include 'includes/header.php';
?>

<div class="container my-4">
    <h2>Kalender Kegiatan Desa</h2>
    <p class="text-muted">Agenda resmi desa, kegiatan warga, dan hari penting</p>

    <?php if (empty($events)): ?>
        <div class="alert alert-info">Belum ada agenda yang tercatat.</div>
    <?php else: ?>
        <div class="list-group">
            <?php foreach ($events as $event): ?>
                <div class="list-group-item mb-3 shadow-sm">
                    <div class="d-flex justify-content-between flex-wrap">
                        <div>
                            <h4><?php echo esc($event['judul_acara']); ?></h4>
                            <p class="mb-1 text-muted"><?php echo esc($event['deskripsi_acara']); ?></p>
                            <small><i class="fas fa-map-marker-alt me-1"></i><?php echo esc($event['lokasi'] ?? 'Balai Desa'); ?></small>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-primary"><?php echo esc(ucfirst($event['jenis_acara'])); ?></span>
                            <p class="mb-0"><?php echo date('d M Y', strtotime($event['tanggal_mulai'])); ?><?php if ($event['tanggal_selesai'] && $event['tanggal_selesai'] !== $event['tanggal_mulai']) echo ' - ' . date('d M Y', strtotime($event['tanggal_selesai'])); ?></p>
                            <?php if ($event['waktu_mulai']): ?>
                                <small><?php echo substr($event['waktu_mulai'], 0, 5); ?> - <?php echo substr($event['waktu_selesai'], 0, 5); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>











