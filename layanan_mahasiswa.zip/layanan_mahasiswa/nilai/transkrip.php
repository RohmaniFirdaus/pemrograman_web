<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen', 'pimpinan']);

$pageTitle = 'Transkrip Nilai';
$currentModule = 'nilai';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa_id = intval($_GET['mahasiswa_id'] ?? 0);

if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $mahasiswa_id = $mhs['id'];
} elseif ($_SESSION['role'] === 'dosen') {
    if (!$mahasiswa_id) {
        // Show list of mahasiswa bimbingan
        $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
        $mhs_list = $conn->query("
            SELECT m.*, p.nama_prodi 
            FROM mahasiswa m 
            LEFT JOIN program_studi p ON m.prodi_id = p.id
            WHERE m.dosen_wali_id = " . $dosen['id'] . "
            ORDER BY m.nim
        ")->fetch_all(MYSQLI_ASSOC);
    }
}

if ($mahasiswa_id) {
    $mahasiswa = $conn->query("
        SELECT m.*, p.nama_prodi, f.nama_fakultas
        FROM mahasiswa m 
        LEFT JOIN program_studi p ON m.prodi_id = p.id
        LEFT JOIN fakultas f ON p.fakultas_id = f.id
        WHERE m.id = $mahasiswa_id
    ")->fetch_assoc();
    
    // Get transkrip
    $transkrip = $conn->query("
        SELECT * FROM transkrip 
        WHERE mahasiswa_id = $mahasiswa_id
    ")->fetch_assoc();
    
    // Get all nilai (all semesters)
    $nilai_all = $conn->query("
        SELECT n.*, mk.kode_mk, mk.nama_mk, mk.sks, mk.semester as mk_semester
        FROM nilai n
        JOIN mata_kuliah mk ON n.mk_id = mk.id
        WHERE n.mahasiswa_id = $mahasiswa_id AND n.status = 'final'
        ORDER BY n.semester, mk.kode_mk
    ")->fetch_all(MYSQLI_ASSOC);
    
    // Group by semester
    $nilai_by_semester = [];
    foreach ($nilai_all as $n) {
        $sem = $n['semester'];
        if (!isset($nilai_by_semester[$sem])) {
            $nilai_by_semester[$sem] = [];
        }
        $nilai_by_semester[$sem][] = $n;
    }
    
    // Calculate IPK
    $total_bobot = 0;
    $total_sks = 0;
    foreach ($nilai_all as $n) {
        $total_bobot += $n['nilai_angka'] * $n['sks'];
        $total_sks += $n['sks'];
    }
    $ipk = $total_sks > 0 ? round($total_bobot / $total_sks, 2) : 0;
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Transkrip Nilai</h1>
        <?php if ($mahasiswa_id): ?>
        <a href="export-transkrip.php?mahasiswa_id=<?= $mahasiswa_id ?>" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
        <?php endif; ?>
    </div>
    
    <?php if (isset($mhs_list)): ?>
    <!-- List Mahasiswa (Dosen) -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Pilih Mahasiswa</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($mhs_list as $m): ?>
            <a href="transkrip.php?mahasiswa_id=<?= $m['id'] ?>" class="border rounded-lg p-4 hover:bg-gray-50">
                <p class="font-semibold"><?= htmlspecialchars($m['nim']) ?></p>
                <p class="text-sm text-gray-600"><?= htmlspecialchars($m['nama_mahasiswa']) ?></p>
                <p class="text-xs text-gray-500"><?= htmlspecialchars($m['nama_prodi']) ?></p>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php elseif ($mahasiswa_id): ?>
    <!-- Header Transkrip -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">POLITEKNIK PURBAYA</h2>
            <p class="text-gray-600">TRANSKRIP NILAI</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold"><?= htmlspecialchars($mahasiswa['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold"><?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold"><?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Fakultas</p>
                <p class="font-semibold"><?= htmlspecialchars($mahasiswa['nama_fakultas'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Angkatan</p>
                <p class="font-semibold"><?= $mahasiswa['angkatan'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">IPK</p>
                <p class="font-semibold text-2xl text-green-600"><?= number_format($ipk, 2) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Transkrip per Semester -->
    <?php foreach ($nilai_by_semester as $semester => $nilai_sem): ?>
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="bg-green-600 text-white p-4">
            <h3 class="text-xl font-bold">Semester <?= $semester ?></h3>
        </div>
        <div class="p-6">
            <?php
            $sks_semester = 0;
            $bobot_semester = 0;
            foreach ($nilai_sem as $n) {
                $sks_semester += $n['sks'];
                $bobot_semester += $n['nilai_angka'] * $n['sks'];
            }
            $ip_semester = $sks_semester > 0 ? round($bobot_semester / $sks_semester, 2) : 0;
            ?>
            <div class="mb-4 flex justify-between">
                <span class="text-gray-600">Total SKS: <strong><?= $sks_semester ?></strong></span>
                <span class="text-gray-600">IP Semester: <strong><?= number_format($ip_semester, 2) ?></strong></span>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full table-auto">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2 text-left">No</th>
                            <th class="px-4 py-2 text-left">Kode MK</th>
                            <th class="px-4 py-2 text-left">Nama MK</th>
                            <th class="px-4 py-2 text-left">SKS</th>
                            <th class="px-4 py-2 text-left">Nilai</th>
                            <th class="px-4 py-2 text-left">Bobot</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($nilai_sem as $index => $n): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= $index + 1 ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($n['kode_mk']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $n['sks'] ?></td>
                            <td class="px-4 py-2">
                                <span class="font-semibold"><?= $n['nilai_huruf'] ?></span>
                                <span class="text-gray-600">(<?= number_format($n['nilai_angka'], 2) ?>)</span>
                            </td>
                            <td class="px-4 py-2"><?= number_format($n['nilai_angka'] * $n['sks'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <!-- Summary -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Rekapitulasi</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm">Total SKS</p>
                <p class="text-2xl font-bold text-gray-800"><?= $total_sks ?></p>
            </div>
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm">IPK</p>
                <p class="text-2xl font-bold text-green-600"><?= number_format($ipk, 2) ?></p>
            </div>
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm">Status</p>
                <p class="text-lg font-semibold"><?= getStatusBadge($mahasiswa['status']) ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



