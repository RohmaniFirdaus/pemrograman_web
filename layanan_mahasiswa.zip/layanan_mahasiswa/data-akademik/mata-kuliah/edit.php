<?php
require_once '../../config/config.php';
requireRole(['admin']);

$pageTitle = 'Edit Mata Kuliah';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mk = $conn->query("SELECT * FROM mata_kuliah WHERE id = $id")->fetch_assoc();
$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);

if (!$mk) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode_mk = sanitize($_POST['kode_mk'] ?? '');
    $nama_mk = sanitize($_POST['nama_mk'] ?? '');
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $sks = intval($_POST['sks'] ?? 0);
    $semester = intval($_POST['semester'] ?? 1);
    $jenis = $_POST['jenis'] ?? 'wajib';
    $dosen_id = intval($_POST['dosen_pengampu_id'] ?? 0);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    if (empty($kode_mk) || empty($nama_mk) || !$prodi_id || $sks <= 0) {
        $error = 'Field yang wajib diisi tidak boleh kosong';
    } else {
        // Check if kode_mk exists for other MK
        $check = $conn->prepare("SELECT id FROM mata_kuliah WHERE kode_mk = ? AND id != ?");
        $check->bind_param("si", $kode_mk, $id);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = 'Kode mata kuliah sudah digunakan';
        } else {
            $stmt = $conn->prepare("UPDATE mata_kuliah SET kode_mk = ?, nama_mk = ?, prodi_id = ?, sks = ?, semester = ?, jenis = ?, dosen_pengampu_id = ?, deskripsi = ?, status = ? WHERE id = ?");
            $dosen_id = $dosen_id > 0 ? $dosen_id : null;
            $stmt->bind_param("ssiiissisi", $kode_mk, $nama_mk, $prodi_id, $sks, $semester, $jenis, $dosen_id, $deskripsi, $status, $id);
            
            if ($stmt->execute()) {
                header('Location: index.php?success=1');
                exit;
            } else {
                $error = 'Gagal mengupdate mata kuliah';
            }
            $stmt->close();
        }
        $check->close();
    }
    $conn->close();
}

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Edit Mata Kuliah</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Kode MK *</label>
                    <input type="text" name="kode_mk" required value="<?= htmlspecialchars($mk['kode_mk']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama MK *</label>
                    <input type="text" name="nama_mk" required value="<?= htmlspecialchars($mk['nama_mk']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi *</label>
                    <select name="prodi_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= $mk['prodi_id'] == $p['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($p['nama_prodi']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">SKS *</label>
                    <input type="number" name="sks" required min="1" max="6" value="<?= $mk['sks'] ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester *</label>
                    <input type="number" name="semester" required min="1" max="6" value="<?= $mk['semester'] ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jenis</label>
                    <select name="jenis" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="wajib" <?= $mk['jenis'] === 'wajib' ? 'selected' : '' ?>>Wajib</option>
                        <option value="pilihan" <?= $mk['jenis'] === 'pilihan' ? 'selected' : '' ?>>Pilihan</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Dosen Pengampu</label>
                    <select name="dosen_pengampu_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Dosen</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= $mk['dosen_pengampu_id'] == $d['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($d['nama_dosen']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="active" <?= $mk['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $mk['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
                    <textarea name="deskripsi" rows="4"
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"><?= htmlspecialchars($mk['deskripsi'] ?? '') ?></textarea>
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Update
                </button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



