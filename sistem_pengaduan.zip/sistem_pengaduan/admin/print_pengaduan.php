<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;

$page_title = 'Laporan Pengaduan';

$pdo = getConnection();
$pengaduan_list = [];
$status_filter = $_GET['status'] ?? '';
$search_query = $_GET['search'] ?? '';

$sql = "
    SELECT
        p.id,
        p.kode_pengaduan,
        p.judul,
        p.status,
        p.tanggal_pengaduan,
        p.deskripsi,
        kp.nama_kategori,
        u.nama AS user_pengaju,
        u.email AS user_email
    FROM pengaduan p
    LEFT JOIN users u ON p.id_user = u.id
    LEFT JOIN kategori_pengaduan kp ON p.id_kategori = kp.id
    WHERE 1=1
";
$params = [];

if (!empty($status_filter)) {
    $sql .= " AND p.status = ?";
    $params[] = $status_filter;
}

if (!empty($search_query)) {
    $sql .= " AND (p.judul LIKE ? OR p.deskripsi LIKE ? OR p.kode_pengaduan LIKE ? OR kp.nama_kategori LIKE ?)";
    $params[] = '%' . $search_query . '%';
    $params[] = '%' . $search_query . '%';
    $params[] = '%' . $search_query . '%';
    $params[] = '%' . $search_query . '%';
}

$sql .= " ORDER BY p.tanggal_pengaduan DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $pengaduan_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching pengaduan list for print: " . $e->getMessage());
    die("Terjadi kesalahan saat membuat laporan. Silakan coba lagi nanti.");
}

$report_title = "Laporan Daftar Pengaduan";
if (!empty($status_filter)) {
    $report_title .= " (Status: " . ucfirst($status_filter) . ")";
}
if (!empty($search_query)) {
    $report_title .= " (Pencarian: '" . esc($search_query) . "')";
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc($page_title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        .container-print {
            width: 100%;
            max-width: 1000px; 
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2, h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background-color: #f2f2f2;
        }
        .status-badge {
            display: inline-block;
            padding: 0.2em 0.5em;
            font-size: 0.8em;
            font-weight: bold;
            border-radius: 0.25rem;
            color: #fff;
        }
        .status-menunggu { background-color: #ffc107; color: #212529;}
        .status-diproses { background-color: #0dcaf0; color: #212529;}
        .status-selesai { background-color: #198754; }
        .status-ditolak { background-color: #dc3545; }

        @media print {
            body {
                margin: 0;
            }
            .no-print {
                display: none !important;
            }
            table {
                page-break-after: auto;
            }
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
            td, th {
                padding: 5px; 
            }
        }
    </style>
</head>
<body>
    <div class="container-print">
        <h1><?php echo esc($report_title); ?></h1>
        <p class="text-center">Tanggal Cetak: <?php echo date('d-m-Y H:i:s'); ?></p>
        <p class="text-center">Dicetak oleh: <?php echo esc($_SESSION['admin_username'] ?? 'Admin'); ?></p>

        <?php if (empty($pengaduan_list)): ?>
            <p class="text-center">Tidak ada pengaduan yang ditemukan dengan kriteria ini.</p>
        <?php else: ?>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>No Tiket</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Pengaju</th>
                        <th>Status</th>
                        <th>Tanggal Pengajuan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($pengaduan_list as $pengaduan): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo esc($pengaduan['kode_pengaduan']); ?></td>
                        <td><?php echo esc($pengaduan['judul']); ?></td>
                        <td><?php echo esc($pengaduan['nama_kategori'] ?? 'Tidak Diketahui'); ?></td>
                        <td><?php echo esc($pengaduan['user_pengaju'] ?? 'Anonim'); ?></td>
                        <td><span class="status-badge status-<?php echo strtolower(esc($pengaduan['status'])); ?>"><?php echo esc(ucfirst($pengaduan['status'])); ?></span></td>
                        <td><?php echo date('d-m-Y H:i', strtotime(esc($pengaduan['tanggal_pengaduan']))); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="no-print" style="text-align: center; margin-top: 30px;">
            <button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Cetak Dokumen Ini</button>
            <button onclick="window.close()" class="btn btn-secondary">Tutup</button>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/your-font-awesome-kit-id.js" crossorigin="anonymous"></script> 
    </body>
</html>