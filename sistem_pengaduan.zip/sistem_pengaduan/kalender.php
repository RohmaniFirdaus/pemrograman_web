<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$bulan = isset($_GET['bulan']) ? (int)$_GET['bulan'] : date('n');
$tahun = isset($_GET['tahun']) ? (int)$_GET['tahun'] : date('Y');
$jenis = isset($_GET['jenis']) ? sanitize($_GET['jenis']) : '';

$where = "WHERE MONTH(tanggal_mulai) = ? AND YEAR(tanggal_mulai) = ?";
$params = [$bulan, $tahun];

if ($jenis) {
    $where .= " AND jenis_acara = ?";
    $params[] = $jenis;
}

$stmt = $pdo->prepare("
    SELECT * FROM kalender_kegiatan 
    $where 
    ORDER BY tanggal_mulai ASC, waktu_mulai ASC
");
$stmt->execute($params);
$events = $stmt->fetchAll();

$pageTitle = 'Kalender Kegiatan - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Kalender Kegiatan Desa</h1>
        <p class="text-gray-600">Agenda rapat, kegiatan warga, dan hari penting desa</p>
    </div>

    <form method="GET" class="mb-6 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Bulan</label>
                <select name="bulan" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php for ($i = 1; $i <= 12; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php echo $bulan == $i ? 'selected' : ''; ?>>
                            <?php echo date('F', mktime(0, 0, 0, $i, 1)); ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Tahun</label>
                <select name="tahun" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php for ($i = date('Y') - 1; $i <= date('Y') + 1; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php echo $tahun == $i ? 'selected' : ''; ?>>
                            <?php echo $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Jenis Acara</label>
                <select name="jenis" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Semua Jenis</option>
                    <option value="rapat" <?php echo $jenis === 'rapat' ? 'selected' : ''; ?>>Rapat</option>
                    <option value="kegiatan" <?php echo $jenis === 'kegiatan' ? 'selected' : ''; ?>>Kegiatan</option>
                    <option value="hari_penting" <?php echo $jenis === 'hari_penting' ? 'selected' : ''; ?>>Hari Penting</option>
                    <option value="lainnya" <?php echo $jenis === 'lainnya' ? 'selected' : ''; ?>>Lainnya</option>
                </select>
            </div>
            <div class="flex items-end">
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                    <i class="fas fa-filter mr-2"></i>Filter
                </button>
            </div>
        </div>
    </form>

    <?php if (empty($events)): ?>
        <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
            <i class="fas fa-calendar text-6xl text-gray-300 mb-4"></i>
            <p class="text-gray-600 text-lg">Tidak ada kegiatan pada periode yang dipilih.</p>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php foreach ($events as $event): ?>
                <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-start gap-6">
                        <div class="flex-shrink-0 w-20 h-20 bg-blue-600 text-white rounded-lg flex flex-col items-center justify-center">
                            <div class="text-2xl font-bold"><?php echo date('d', strtotime($event['tanggal_mulai'])); ?></div>
                            <div class="text-xs"><?php echo date('M', strtotime($event['tanggal_mulai'])); ?></div>
                        </div>
                        <div class="flex-1">
                            <div class="flex items-start justify-between mb-2">
                                <h3 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($event['judul_acara']); ?></h3>
                                <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                                    <?php 
                                    $jenis_labels = [
                                        'rapat' => 'Rapat',
                                        'kegiatan' => 'Kegiatan',
                                        'hari_penting' => 'Hari Penting',
                                        'lainnya' => 'Lainnya'
                                    ];
                                    echo $jenis_labels[$event['jenis_acara']] ?? 'Lainnya';
                                    ?>
                                </span>
                            </div>
                            <?php if ($event['deskripsi']): ?>
                                <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($event['deskripsi']); ?></p>
                            <?php endif; ?>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                                <?php if ($event['waktu_mulai']): ?>
                                    <div><i class="fas fa-clock mr-2"></i><?php echo date('H:i', strtotime($event['waktu_mulai'])); ?>
                                        <?php if ($event['waktu_selesai']): ?>
                                            - <?php echo date('H:i', strtotime($event['waktu_selesai'])); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($event['lokasi']): ?>
                                    <div><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($event['lokasi']); ?></div>
                                <?php endif; ?>
                                <?php if ($event['tanggal_selesai'] && $event['tanggal_selesai'] != $event['tanggal_mulai']): ?>
                                    <div><i class="fas fa-calendar-alt mr-2"></i>Sampai <?php echo formatTanggal($event['tanggal_selesai']); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>



