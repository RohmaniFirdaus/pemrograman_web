<?php
require_once '../config/config.php';
logout();
?>



