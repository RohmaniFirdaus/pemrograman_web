<?php
require_once '../config/config.php';
requireRole(['admin']);

$pageTitle = 'Generate Tagihan';
$currentModule = 'tagihan';

$conn = getDBConnection();

$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $semester = intval($_POST['semester'] ?? 0);
    $tahun_akademik = sanitize($_POST['tahun_akademik'] ?? '');
    $jenis_tagihan = $_POST['jenis_tagihan'] ?? '';
    $total_tagihan = floatval($_POST['total_tagihan'] ?? 0);
    $jatuh_tempo = $_POST['jatuh_tempo'] ?? '';
    
    if (!$prodi_id || !$semester || !$tahun_akademik || !$jenis_tagihan || $total_tagihan <= 0 || !$jatuh_tempo) {
        $error = 'Semua field wajib diisi';
    } else {
        // Get mahasiswa aktif
        $mahasiswa_list = $conn->query("
            SELECT * FROM mahasiswa 
            WHERE prodi_id = $prodi_id 
            AND status = 'active'
            AND semester = $semester
        ")->fetch_all(MYSQLI_ASSOC);
        
        $count = 0;
        foreach ($mahasiswa_list as $mhs) {
            // Check if tagihan already exists
            $existing = $conn->query("
                SELECT id FROM tagihan 
                WHERE mahasiswa_id = " . $mhs['id'] . " 
                AND semester = $semester 
                AND tahun_akademik = '$tahun_akademik'
            ")->fetch_assoc();
            
            if (!$existing) {
                // Generate nomor tagihan
                $nomor = 'TAG' . date('Y') . str_pad($mhs['id'], 6, '0', STR_PAD_LEFT);
                
                // Check for beasiswa
                $beasiswa = $conn->query("
                    SELECT * FROM beasiswa 
                    WHERE mahasiswa_id = " . $mhs['id'] . " 
                    AND semester = $semester 
                    AND tahun_akademik = '$tahun_akademik'
                    AND status = 'dicairkan'
                ")->fetch_assoc();
                
                $final_total = $total_tagihan;
                $final_sisa = $total_tagihan;
                
                if ($beasiswa) {
                    if ($beasiswa['jenis'] === 'penuh') {
                        $final_sisa = 0;
                        $jenis_tagihan = 'beasiswa_penuh';
                    } elseif ($beasiswa['jenis'] === '50_persen') {
                        $final_total = $total_tagihan * 0.5;
                        $final_sisa = $final_total;
                        $jenis_tagihan = 'beasiswa_50';
                    }
                }
                
                $stmt = $conn->prepare("INSERT INTO tagihan (mahasiswa_id, nomor_tagihan, jenis_tagihan, semester, tahun_akademik, total_tagihan, sisa_tagihan, jatuh_tempo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')");
                $stmt->bind_param("isissdds", $mhs['id'], $nomor, $jenis_tagihan, $semester, $tahun_akademik, $final_total, $final_sisa, $jatuh_tempo);
                $stmt->execute();
                $tagihan_id = $conn->insert_id;
                
                // Insert detail tagihan
                $komponen = 'UKT Semester ' . $semester;
                $conn->query("INSERT INTO detail_tagihan (tagihan_id, komponen, nominal, keterangan) VALUES ($tagihan_id, '$komponen', $final_total, 'Tagihan UKT')");
                
                $count++;
            }
        }
        
        $success = "Berhasil generate $count tagihan";
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Generate Tagihan Massal</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi *</label>
                    <select name="prodi_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama_prodi']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester *</label>
                    <input type="number" name="semester" required min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tahun Akademik *</label>
                    <input type="text" name="tahun_akademik" required placeholder="2024/2025"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jenis Tagihan *</label>
                    <select name="jenis_tagihan" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Jenis</option>
                        <option value="ukt_reguler">UKT Reguler</option>
                        <option value="beasiswa_penuh">Beasiswa Penuh</option>
                        <option value="beasiswa_50">Beasiswa 50%</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Total Tagihan *</label>
                    <input type="number" name="total_tagihan" required min="0" step="1000"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jatuh Tempo *</label>
                    <input type="date" name="jatuh_tempo" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-cogs mr-2"></i>Generate Tagihan
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



