<?php
$admin_page = true;
require_once '../includes/auth.php';

if (is_admin_logged_in()) {
    admin_logout();
}

header('Location: login.php');
exit;