<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$tipe = isset($_GET['tipe']) ? sanitize($_GET['tipe']) : 'pengaduan';
$nomor = isset($_GET['nomor']) ? sanitize($_GET['nomor']) : '';
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $nomor) {
    $nomor = $nomor ?: sanitize($_POST['nomor'] ?? '');
    $tipe = $tipe ?: sanitize($_POST['tipe'] ?? 'pengaduan');
    
    if ($nomor) {
        if ($tipe === 'pengaduan') {
            $stmt = $pdo->prepare("
                SELECT p.*, u.nama_lengkap, k.nama_kategori 
                FROM pengaduan p 
                LEFT JOIN users u ON p.user_id = u.id 
                LEFT JOIN kategori_pengaduan k ON p.kategori_id = k.id 
                WHERE p.id = ?
            ");
            $stmt->execute([$nomor]);
            $result = $stmt->fetch();
        } else {
            $stmt = $pdo->prepare("
                SELECT s.*, u.nama_lengkap, k.nama_kategori 
                FROM surat_menyurat s 
                LEFT JOIN users u ON s.user_id = u.id 
                LEFT JOIN kategori_surat k ON s.kategori_id = k.id 
                WHERE s.id = ?
            ");
            $stmt->execute([$nomor]);
            $result = $stmt->fetch();
        }
    }
}

$pageTitle = 'Cek Status - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-4xl font-bold text-gray-800 mb-8 text-center">Cek Status</h1>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <form method="GET">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Jenis</label>
                    <select name="tipe" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="pengaduan" <?php echo $tipe === 'pengaduan' ? 'selected' : ''; ?>>Pengaduan</option>
                        <option value="surat" <?php echo $tipe === 'surat' ? 'selected' : ''; ?>>Surat Menyurat</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nomor ID</label>
                    <input type="number" name="nomor" value="<?php echo htmlspecialchars($nomor); ?>" 
                           placeholder="Masukkan ID pengaduan/surat" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           required>
                    <p class="text-xs text-gray-500 mt-1">Masukkan ID yang Anda terima saat membuat pengaduan/surat</p>
                </div>
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                    <i class="fas fa-search mr-2"></i>Cek Status
                </button>
            </form>
        </div>

        <?php if ($result): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Detail <?php echo $tipe === 'pengaduan' ? 'Pengaduan' : 'Surat'; ?></h2>
                
                <div class="space-y-4">
                    <div>
                        <h3 class="font-semibold text-gray-800 mb-1">ID</h3>
                        <p class="text-gray-600">#<?php echo $result['id']; ?></p>
                    </div>
                    
                    <?php if ($tipe === 'pengaduan'): ?>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Judul</h3>
                            <p class="text-gray-600"><?php echo htmlspecialchars($result['judul']); ?></p>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Kategori</h3>
                            <p class="text-gray-600"><?php echo htmlspecialchars($result['nama_kategori'] ?? '-'); ?></p>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Deskripsi</h3>
                            <p class="text-gray-600"><?php echo nl2br(htmlspecialchars($result['deskripsi'])); ?></p>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Prioritas</h3>
                            <p class="text-gray-600"><?php echo ucfirst($result['prioritas']); ?></p>
                        </div>
                    <?php else: ?>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Jenis Surat</h3>
                            <p class="text-gray-600"><?php echo htmlspecialchars($result['jenis_surat']); ?></p>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Kategori</h3>
                            <p class="text-gray-600"><?php echo htmlspecialchars($result['nama_kategori'] ?? '-'); ?></p>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Keperluan</h3>
                            <p class="text-gray-600"><?php echo nl2br(htmlspecialchars($result['keperluan'])); ?></p>
                        </div>
                        <?php if ($result['nomor_surat']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-1">Nomor Surat</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($result['nomor_surat']); ?></p>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <div>
                        <h3 class="font-semibold text-gray-800 mb-1">Status</h3>
                        <div class="mt-2">
                            <?php echo getStatusBadge($result['status'], $tipe); ?>
                        </div>
                    </div>
                    
                    <div>
                        <h3 class="font-semibold text-gray-800 mb-1">Tanggal Dibuat</h3>
                        <p class="text-gray-600"><?php echo formatTanggal($result['created_at'], true); ?></p>
                    </div>
                    
                    <?php if ($result['updated_at'] != $result['created_at']): ?>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Terakhir Diupdate</h3>
                            <p class="text-gray-600"><?php echo formatTanggal($result['updated_at'], true); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($nomor): ?>
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
                <i class="fas fa-exclamation-triangle text-4xl text-yellow-600 mb-4"></i>
                <p class="text-gray-700"><?php echo ucfirst($tipe); ?> dengan ID #<?php echo htmlspecialchars($nomor); ?> tidak ditemukan.</p>
                <p class="text-gray-600 text-sm mt-2">Pastikan ID yang Anda masukkan benar.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>



