<?php
require_once '../config/config.php';
requireRole(['dosen']);

$pageTitle = 'Input Nilai';
$currentModule = 'nilai';

$user = getCurrentUser();
$conn = getDBConnection();

$dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
$mk_id = intval($_GET['mk_id'] ?? 0);

// Get mata kuliah yang diajar
$mk_list = $conn->query("
    SELECT DISTINCT mk.* 
    FROM mata_kuliah mk
    JOIN jadwal_kuliah j ON mk.id = j.mk_id
    WHERE j.dosen_id = " . $dosen['id'] . "
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

if ($mk_id) {
    $mk = $conn->query("SELECT * FROM mata_kuliah WHERE id = $mk_id")->fetch_assoc();
    
    // Get mahasiswa yang mengambil mata kuliah ini
    $mahasiswa_list = $conn->query("
        SELECT DISTINCT m.*, k.id as krs_id, k.semester, k.tahun_akademik
        FROM mahasiswa m
        JOIN krs k ON m.id = k.mahasiswa_id
        JOIN krs_detail kd ON k.id = kd.krs_id
        JOIN jadwal_kuliah j ON kd.jadwal_id = j.id
        WHERE kd.mk_id = $mk_id 
        AND j.dosen_id = " . $dosen['id'] . "
        AND k.status = 'approved'
        ORDER BY m.nim
    ")->fetch_all(MYSQLI_ASSOC);
    
    // Get existing nilai
    $nilai_existing = [];
    if (!empty($mahasiswa_list)) {
        $mhs_ids = array_column($mahasiswa_list, 'id');
        $nilai_data = $conn->query("
            SELECT * FROM nilai 
            WHERE mk_id = $mk_id 
            AND mahasiswa_id IN (" . implode(',', $mhs_ids) . ")
        ")->fetch_all(MYSQLI_ASSOC);
        
        foreach ($nilai_data as $n) {
            $nilai_existing[$n['mahasiswa_id']] = $n;
        }
    }
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'input_nilai') {
        $mahasiswa_id = intval($_POST['mahasiswa_id'] ?? 0);
        $nilai_huruf = $_POST['nilai_huruf'] ?? '';
        $krs_id = intval($_POST['krs_id'] ?? 0);
        $semester = intval($_POST['semester'] ?? 0);
        $tahun_akademik = sanitize($_POST['tahun_akademik'] ?? '');
        
        if ($mahasiswa_id && $nilai_huruf && $mk_id) {
            $nilai_angka = getNilaiAngka($nilai_huruf);
            
            // Check if nilai exists
            $existing = $conn->query("SELECT id FROM nilai WHERE mahasiswa_id = $mahasiswa_id AND mk_id = $mk_id")->fetch_assoc();
            
            if ($existing) {
                // Update
                $stmt = $conn->prepare("UPDATE nilai SET nilai_huruf = ?, nilai_angka = ?, dosen_id = ?, status = 'final' WHERE id = ?");
                $stmt->bind_param("sdii", $nilai_huruf, $nilai_angka, $dosen['id'], $existing['id']);
            } else {
                // Insert
                $stmt = $conn->prepare("INSERT INTO nilai (mahasiswa_id, mk_id, dosen_id, krs_id, semester, tahun_akademik, nilai_huruf, nilai_angka, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'final')");
                $stmt->bind_param("iiisissd", $mahasiswa_id, $mk_id, $dosen['id'], $krs_id, $semester, $tahun_akademik, $nilai_huruf, $nilai_angka);
            }
            
            if ($stmt->execute()) {
                // Update KHS
                $conn->query("
                    INSERT INTO khs (mahasiswa_id, semester, tahun_akademik, sks_semester, ip_semester, ipk, status)
                    SELECT 
                        mahasiswa_id,
                        semester,
                        tahun_akademik,
                        SUM(mk.sks) as sks_semester,
                        SUM(n.nilai_angka * mk.sks) / SUM(mk.sks) as ip_semester,
                        (SELECT SUM(n2.nilai_angka * mk2.sks) / SUM(mk2.sks) FROM nilai n2 JOIN mata_kuliah mk2 ON n2.mk_id = mk2.id WHERE n2.mahasiswa_id = n.mahasiswa_id AND n2.status = 'final') as ipk,
                        'final'
                    FROM nilai n
                    JOIN mata_kuliah mk ON n.mk_id = mk.id
                    WHERE n.mahasiswa_id = $mahasiswa_id AND n.semester = $semester AND n.status = 'final'
                    GROUP BY n.mahasiswa_id, n.semester, n.tahun_akademik
                    ON DUPLICATE KEY UPDATE
                        sks_semester = VALUES(sks_semester),
                        ip_semester = VALUES(ip_semester),
                        ipk = VALUES(ipk)
                ");
                
                // Update mahasiswa IPK and SKS
                $conn->query("
                    UPDATE mahasiswa SET 
                        ipk = (SELECT SUM(n.nilai_angka * mk.sks) / SUM(mk.sks) FROM nilai n JOIN mata_kuliah mk ON n.mk_id = mk.id WHERE n.mahasiswa_id = mahasiswa.id AND n.status = 'final'),
                        sks_tempuh = (SELECT SUM(mk.sks) FROM nilai n JOIN mata_kuliah mk ON n.mk_id = mk.id WHERE n.mahasiswa_id = mahasiswa.id AND n.status = 'final')
                    WHERE id = $mahasiswa_id
                ");
                
                $success = 'Nilai berhasil disimpan';
                header('Location: input.php?mk_id=' . $mk_id);
                exit;
            }
            $stmt->close();
        }
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Input Nilai</h1>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Pilih Mata Kuliah -->
    <?php if (!$mk_id): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Pilih Mata Kuliah</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($mk_list as $m): ?>
            <a href="input.php?mk_id=<?= $m['id'] ?>" class="border rounded-lg p-4 hover:bg-gray-50">
                <p class="font-semibold"><?= htmlspecialchars($m['kode_mk']) ?> - <?= htmlspecialchars($m['nama_mk']) ?></p>
                <p class="text-sm text-gray-600"><?= $m['sks'] ?> SKS | Semester <?= $m['semester'] ?></p>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php else: ?>
    <!-- Input Nilai -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">
            <?= htmlspecialchars($mk['kode_mk']) ?> - <?= htmlspecialchars($mk['nama_mk']) ?>
        </h2>
        
        <?php if (empty($mahasiswa_list)): ?>
            <p class="text-gray-500 text-center py-8">Tidak ada mahasiswa yang mengambil mata kuliah ini</p>
        <?php else: ?>
            <form method="POST" id="form-nilai">
                <input type="hidden" name="action" value="input_nilai">
                <div class="overflow-x-auto">
                    <table class="min-w-full table-auto">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-4 py-2 text-left">No</th>
                                <th class="px-4 py-2 text-left">NIM</th>
                                <th class="px-4 py-2 text-left">Nama</th>
                                <th class="px-4 py-2 text-left">Semester</th>
                                <th class="px-4 py-2 text-left">Nilai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mahasiswa_list as $index => $m): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?= $index + 1 ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($m['nim']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($m['nama_mahasiswa']) ?></td>
                                <td class="px-4 py-2"><?= $m['semester'] ?></td>
                                <td class="px-4 py-2">
                                    <input type="hidden" name="mahasiswa_id[]" value="<?= $m['id'] ?>">
                                    <input type="hidden" name="krs_id[]" value="<?= $m['krs_id'] ?>">
                                    <input type="hidden" name="semester[]" value="<?= $m['semester'] ?>">
                                    <input type="hidden" name="tahun_akademik[]" value="<?= htmlspecialchars($m['tahun_akademik']) ?>">
                                    <select name="nilai_huruf[]" required class="px-4 py-2 border border-gray-300 rounded-lg">
                                        <option value="">Pilih</option>
                                        <option value="A" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'A' ? 'selected' : '' ?>>A</option>
                                        <option value="B+" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'B+' ? 'selected' : '' ?>>B+</option>
                                        <option value="B" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'B' ? 'selected' : '' ?>>B</option>
                                        <option value="C+" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'C+' ? 'selected' : '' ?>>C+</option>
                                        <option value="C" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'C' ? 'selected' : '' ?>>C</option>
                                        <option value="D" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'D' ? 'selected' : '' ?>>D</option>
                                        <option value="E" <?= isset($nilai_existing[$m['id']]) && $nilai_existing[$m['id']]['nilai_huruf'] === 'E' ? 'selected' : '' ?>>E</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-6">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                        <i class="fas fa-save mr-2"></i>Simpan Semua Nilai
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



