<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'KRS';
$currentModule = 'krs';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $krs_list = $conn->query("SELECT * FROM krs WHERE mahasiswa_id = " . $mahasiswa['id'] . " ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    $krs_list = $conn->query("
        SELECT k.*, m.nim, m.nama_mahasiswa 
        FROM krs k 
        JOIN mahasiswa m ON k.mahasiswa_id = m.id 
        WHERE m.dosen_wali_id = " . $dosen['id'] . " 
        ORDER BY k.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    $krs_list = $conn->query("
        SELECT k.*, m.nim, m.nama_mahasiswa 
        FROM krs k 
        JOIN mahasiswa m ON k.mahasiswa_id = m.id 
        ORDER BY k.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">KRS</h1>
        <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
        <a href="isi.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Isi KRS
        </a>
        <?php endif; ?>
    </div>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tahun Akademik</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">SKS</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($krs_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'mahasiswa' ? '5' : '7' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada data KRS</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_list as $k): ?>
                        <tr class="hover:bg-gray-50">
                            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($k['nim'] ?? '') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($k['nama_mahasiswa'] ?? '') ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $k['semester'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($k['tahun_akademik']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $k['sks_diambil'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($k['status']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $k['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3">
                                    <i class="fas fa-eye"></i> Detail
                                </a>
                                <?php if ($_SESSION['role'] === 'dosen' && $k['status'] === 'menunggu_approval'): ?>
                                <a href="review.php?id=<?= $k['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-check"></i> Review
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



