<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Jadwal Bimbingan';
$currentModule = 'tugas-akhir';

$ta_id = intval($_GET['id'] ?? 0);
if (!$ta_id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$ta = $conn->query("
    SELECT ta.*, m.nim, m.nama_mahasiswa
    FROM tugas_akhir ta
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    WHERE ta.id = $ta_id
")->fetch_assoc();

if (!$ta) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['dosen_pembimbing1_id'] != $dosen['id'] && $ta['dosen_pembimbing2_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get jadwal bimbingan
$jadwal = $conn->query("
    SELECT jb.*, d.nama_dosen
    FROM jadwal_bimbingan jb
    LEFT JOIN dosen d ON jb.dosen_id = d.id
    WHERE jb.ta_id = $ta_id
    ORDER BY jb.tanggal DESC, jb.waktu DESC
")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'tambah' && $_SESSION['role'] === 'dosen') {
        $tanggal = $_POST['tanggal'] ?? '';
        $waktu = $_POST['waktu'] ?? '';
        $agenda = sanitize($_POST['agenda'] ?? '');
        
        if ($tanggal && $waktu) {
            $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
            $stmt = $conn->prepare("INSERT INTO jadwal_bimbingan (ta_id, dosen_id, tanggal, waktu, agenda, status) VALUES (?, ?, ?, ?, ?, 'menunggu')");
            $stmt->bind_param("issss", $ta_id, $dosen['id'], $tanggal, $waktu, $agenda);
            if ($stmt->execute()) {
                $success = 'Jadwal berhasil ditambahkan';
                header('Location: jadwal-bimbingan.php?id=' . $ta_id);
                exit;
            }
            $stmt->close();
        }
    } elseif ($action === 'konfirmasi' && $_SESSION['role'] === 'mahasiswa') {
        $jadwal_id = intval($_POST['jadwal_id'] ?? 0);
        $conn->query("UPDATE jadwal_bimbingan SET status = 'dikonfirmasi' WHERE id = $jadwal_id AND ta_id = $ta_id");
        $success = 'Jadwal dikonfirmasi';
        header('Location: jadwal-bimbingan.php?id=' . $ta_id);
        exit;
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Jadwal Bimbingan</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info TA -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($ta['judul_ta']) ?></h2>
        <p class="text-gray-600"><?= htmlspecialchars($ta['nim']) ?> - <?= htmlspecialchars($ta['nama_mahasiswa']) ?></p>
    </div>
    
    <!-- Form Tambah Jadwal (Dosen) -->
    <?php if ($_SESSION['role'] === 'dosen'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Tambah Jadwal Bimbingan</h2>
        <form method="POST">
            <input type="hidden" name="action" value="tambah">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tanggal</label>
                    <input type="date" name="tanggal" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Waktu</label>
                    <input type="time" name="waktu" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Agenda</label>
                    <input type="text" name="agenda" placeholder="Agenda bimbingan..."
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-plus mr-2"></i>Tambah Jadwal
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- List Jadwal -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jadwal Bimbingan</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                        <th class="px-4 py-2 text-left">Waktu</th>
                        <th class="px-4 py-2 text-left">Dosen</th>
                        <th class="px-4 py-2 text-left">Agenda</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
                        <th class="px-4 py-2 text-left">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($jadwal)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'mahasiswa' ? '6' : '5' ?>" class="px-4 py-4 text-center text-gray-500">Belum ada jadwal</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($jadwal as $j): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= formatTanggal($j['tanggal']) ?></td>
                            <td class="px-4 py-2"><?= date('H:i', strtotime($j['waktu'])) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($j['nama_dosen'] ?? '-') ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($j['agenda'] ?? '-') ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($j['status']) ?></td>
                            <?php if ($_SESSION['role'] === 'mahasiswa' && $j['status'] === 'menunggu'): ?>
                            <td class="px-4 py-2">
                                <form method="POST" class="inline">
                                    <input type="hidden" name="action" value="konfirmasi">
                                    <input type="hidden" name="jadwal_id" value="<?= $j['id'] ?>">
                                    <button type="submit" class="text-green-600 hover:text-green-700">
                                        <i class="fas fa-check mr-1"></i>Konfirmasi
                                    </button>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



