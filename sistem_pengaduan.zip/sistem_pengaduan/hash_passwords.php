<?php
require_once 'includes/config.php';

$pdo = getConnection();

try {
    $stmt = $pdo->query("SELECT id, password FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $updated = 0;
    $skipped = 0;
    
    foreach ($users as $user) {
        // Cek apakah password sudah di-hash (hash bcrypt selalu dimulai dengan $2y$)
        if (strpos($user['password'], '$2y$') === 0) {
            echo "User ID {$user['id']}: Password sudah di-hash, skip.\n";
            $skipped++;
            continue;
        }
        
        // Hash password yang masih plain text
        $hashed = password_hash($user['password'], PASSWORD_DEFAULT);
        
        $updateStmt = $pdo->prepare("UPDATE users SET password = :hashed WHERE id = :id");
        $updateStmt->execute([
            'hashed' => $hashed,
            'id' => $user['id']
        ]);
        
        echo "User ID {$user['id']}: Password berhasil di-hash.\n";
        $updated++;
    }
    
    echo "\n=== Selesai ===\n";
    echo "Total di-update: $updated\n";
    echo "Total di-skip: $skipped\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}




