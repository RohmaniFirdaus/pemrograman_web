<?php
$new_password = 'password_baru_anda'; 
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
echo $hashed_password;
?>