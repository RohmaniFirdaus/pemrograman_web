<?php
require_once 'includes/auth.php';

require_login('user_login.php');

$page_title = 'Detail Pengaduan Anda';
$pengaduan = null;
$lampiran = [];
$riwayat = [];
$error_message = '';

$pdo = getConnection();
$pengaduan_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

if ($pengaduan_id <= 0) {
    $error_message = 'ID pengaduan tidak valid.';
} elseif (!$pdo) {
    $error_message = 'Koneksi database tidak tersedia.';
} elseif (!$user_id) {
    $error_message = 'Anda harus login untuk melihat detail pengaduan.';
} else {
    try {
        $kode_column_exists = false;
        try {
            $stmt_check_col = $pdo->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pengaduan' AND COLUMN_NAME = 'kode_pengaduan'");
            $kode_column_exists = $stmt_check_col->fetch() !== false;
        } catch (PDOException $e) {
            try {
                $stmt_check_col = $pdo->query("SHOW COLUMNS FROM pengaduan WHERE Field = 'kode_pengaduan'");
                $kode_column_exists = $stmt_check_col->fetch() !== false;
            } catch (PDOException $e2) {
                error_log("Error checking kode_pengaduan column: " . $e2->getMessage());
            }
        }
        
        if ($kode_column_exists) {
            $stmt = $pdo->prepare("
                SELECT p.*, k.nama_kategori
                FROM pengaduan p
                LEFT JOIN kategori_pengaduan k ON k.id = p.id_kategori
                WHERE p.id = :id AND p.id_user = :user
            ");
        } else {
            // Query tanpa kolom kode_pengaduan
            $stmt = $pdo->prepare("
                SELECT p.id, p.id_user, p.id_kategori, p.judul, p.deskripsi, p.lokasi, 
                       p.status, p.prioritas, p.tanggal_pengaduan, p.tanggal_selesai, 
                       p.created_at, p.updated_at,
                       k.nama_kategori
                FROM pengaduan p
                LEFT JOIN kategori_pengaduan k ON k.id = p.id_kategori
                WHERE p.id = :id AND p.id_user = :user
            ");
        }
        
        $stmt->execute(['id' => (int)$pengaduan_id, 'user' => (int)$user_id]);
        $pengaduan = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pengaduan) {
            $error_message = 'Pengaduan tidak ditemukan atau Anda tidak memiliki akses.';
        } else {
            // Simpan info apakah kode_pengaduan ada untuk digunakan di view
            $pengaduan['_has_kode'] = $kode_column_exists;
            
            try {
                $stmtLampiran = $pdo->prepare("SELECT * FROM lampiran_pengaduan WHERE id_pengaduan = :id");
                $stmtLampiran->execute(['id' => $pengaduan_id]);
                $lampiran = $stmtLampiran->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log('Error loading lampiran: ' . $e->getMessage());
                $lampiran = [];
            }

            try {
                $stmtTanggapan = $pdo->prepare("
                    SELECT t.isi_tanggapan, t.created_at, u.nama AS petugas
                    FROM tanggapan t
                    LEFT JOIN users u ON u.id = t.id_user
                    WHERE t.id_pengaduan = :id
                    ORDER BY t.created_at ASC
                ");
                $stmtTanggapan->execute(['id' => $pengaduan_id]);
                $riwayat = $stmtTanggapan->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log('Error loading tanggapan: ' . $e->getMessage());
                $riwayat = [];
            }
        }
    } catch (PDOException $e) {
        error_log('Detail pengaduan error: ' . $e->getMessage());
        error_log('Error code: ' . $e->getCode());
        error_log('SQL State: ' . ($e->errorInfo[0] ?? 'N/A'));
        $error_message = 'Terjadi kesalahan saat mengambil data: ' . htmlspecialchars($e->getMessage());
    } catch (Exception $e) {
        error_log('Unexpected error in detail pengaduan: ' . $e->getMessage());
        $error_message = 'Terjadi kesalahan tidak terduga: ' . htmlspecialchars($e->getMessage());
    }
}

include 'includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Detail Pengaduan</h2>
        <a href="user_dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i> Kembali</a>
    </div>

    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo esc($error_message); ?></div>
    <?php endif; ?>

    <?php if ($pengaduan): ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h4>
                    <?php if (!empty($pengaduan['kode_pengaduan'])): ?>
                        #<?php echo esc($pengaduan['kode_pengaduan']); ?>
                    <?php else: ?>
                        ID: <?php echo esc($pengaduan['id']); ?>
                    <?php endif; ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Judul:</strong> <?php echo esc($pengaduan['judul']); ?></p>
                        <p><strong>Kategori:</strong> <?php echo esc($pengaduan['nama_kategori'] ?? '-'); ?></p>
                        <p><strong>Status:</strong> <span class="status-badge status-<?php echo esc(strtolower($pengaduan['status'])); ?>"><?php echo esc(ucfirst($pengaduan['status'])); ?></span></p>
                        <p><strong>Tanggal Pengajuan:</strong> <?php echo date('d M Y', strtotime($pengaduan['tanggal_pengaduan'])); ?></p>
                        <p><strong>Prioritas:</strong> <?php echo esc(ucfirst($pengaduan['prioritas'])); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Lokasi:</strong> <?php echo esc($pengaduan['lokasi'] ?? '-'); ?></p>
                        <p><strong>Deskripsi:</strong><br><?php echo nl2br(esc($pengaduan['deskripsi'])); ?></p>
                    </div>
                </div>
                <?php if ($lampiran): ?>
                    <h5 class="mt-4">Lampiran</h5>
                    <ul>
                        <?php foreach ($lampiran as $file): ?>
                            <li><a href="uploads/<?php echo esc($file['path_file']); ?>" target="_blank"><?php echo esc($file['nama_file']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-info text-white">
                <h4>Riwayat Tanggapan</h4>
            </div>
            <div class="card-body">
                <?php if (empty($riwayat)): ?>
                    <p class="text-muted">Belum ada tanggapan.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php foreach ($riwayat as $tanggapan): ?>
                            <li class="list-group-item">
                                <strong><?php echo esc($tanggapan['petugas'] ?? 'Petugas Desa'); ?></strong>
                                <small class="text-muted d-block"><?php echo date('d M Y H:i', strtotime($tanggapan['created_at'])); ?></small>
                                <p class="mb-0"><?php echo nl2br(esc($tanggapan['isi_tanggapan'])); ?></p>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
