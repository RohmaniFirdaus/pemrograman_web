<?php
require_once '../../config/config.php';
requireRole(['admin']);

$pageTitle = 'Tambah Mata Kuliah';
$currentModule = 'data-akademik';

$conn = getDBConnection();
$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);
$conn->close();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode_mk = sanitize($_POST['kode_mk'] ?? '');
    $nama_mk = sanitize($_POST['nama_mk'] ?? '');
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $sks = intval($_POST['sks'] ?? 0);
    $semester = intval($_POST['semester'] ?? 1);
    $jenis = $_POST['jenis'] ?? 'wajib';
    $dosen_id = intval($_POST['dosen_pengampu_id'] ?? 0);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');
    
    if (empty($kode_mk) || empty($nama_mk) || !$prodi_id || $sks <= 0) {
        $error = 'Field yang wajib diisi tidak boleh kosong';
    } else {
        $conn = getDBConnection();
        
        // Check if kode_mk exists
        $check = $conn->prepare("SELECT id FROM mata_kuliah WHERE kode_mk = ?");
        $check->bind_param("s", $kode_mk);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = 'Kode mata kuliah sudah digunakan';
        } else {
            $stmt = $conn->prepare("INSERT INTO mata_kuliah (kode_mk, nama_mk, prodi_id, sks, semester, jenis, dosen_pengampu_id, deskripsi, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')");
            $dosen_id = $dosen_id > 0 ? $dosen_id : null;
            $stmt->bind_param("ssiiissi", $kode_mk, $nama_mk, $prodi_id, $sks, $semester, $jenis, $dosen_id, $deskripsi);
            
            if ($stmt->execute()) {
                header('Location: index.php?success=1');
                exit;
            } else {
                $error = 'Gagal menambahkan mata kuliah';
            }
            $stmt->close();
        }
        $check->close();
        $conn->close();
    }
}

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Tambah Mata Kuliah</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Kode MK *</label>
                    <input type="text" name="kode_mk" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama MK *</label>
                    <input type="text" name="nama_mk" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi *</label>
                    <select name="prodi_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama_prodi']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">SKS *</label>
                    <input type="number" name="sks" required min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester *</label>
                    <input type="number" name="semester" required min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jenis</label>
                    <select name="jenis" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="wajib">Wajib</option>
                        <option value="pilihan">Pilihan</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Dosen Pengampu</label>
                    <select name="dosen_pengampu_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Dosen</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_dosen']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
                    <textarea name="deskripsi" rows="4"
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"></textarea>
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Simpan
                </button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



