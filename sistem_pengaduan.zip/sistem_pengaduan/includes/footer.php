<?php
$current_year = date('Y');
?>
    </div>
    <footer class="main-footer">
        <div class="container">
            <p class="mb-2 fw-bold">Sistem Desa Gembong Kulon · Talang, Kabupaten Tegal</p>
            <p class="mb-0">Layanan pengaduan, surat online, berita desa, UMKM, dan kalender kegiatan terpadu.</p>
            <p class="small mb-0">&copy; <?php echo $current_year; ?> Pemerintah Desa Gembong Kulon. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>