<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('warga');

$pdo = getDBConnection();
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT status_verifikasi FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($user['status_verifikasi'] !== 'terverifikasi') {
    setFlashMessage('error', 'Anda harus melengkapi profil dan menunggu verifikasi untuk membuat pengaduan.');
    header('Location: ' . BASE_URL . 'warga/profil.php');
    exit;
}

$error = '';
$success = '';

$stmt = $pdo->query("SELECT * FROM kategori_pengaduan ORDER BY nama_kategori");
$kategori_list = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = sanitize($_POST['judul'] ?? '');
    $kategori_id = intval($_POST['kategori_id'] ?? 0);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');
    $saran = sanitize($_POST['saran'] ?? '');
    $lokasi = sanitize($_POST['lokasi'] ?? '');
    $prioritas = sanitize($_POST['prioritas'] ?? 'sedang');
    
    if (empty($judul) || empty($deskripsi)) {
        $error = 'Judul dan deskripsi harus diisi';
    } else {
        $bukti_file = null;
        $tipe_bukti = null;
        
        if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['bukti'];
            $fileType = $file['type'];
            
            if (in_array($fileType, ALLOWED_IMAGE_TYPES)) {
                $result = uploadFile($file, 'pengaduan', ALLOWED_IMAGE_TYPES);
                if ($result['success']) {
                    $bukti_file = $result['path'];
                    $tipe_bukti = 'foto';
                } else {
                    $error = $result['message'];
                }
            } elseif (in_array($fileType, ALLOWED_VIDEO_TYPES)) {
                $result = uploadFile($file, 'pengaduan', ALLOWED_VIDEO_TYPES);
                if ($result['success']) {
                    $bukti_file = $result['path'];
                    $tipe_bukti = 'video';
                } else {
                    $error = $result['message'];
                }
            } elseif (in_array($fileType, ALLOWED_DOC_TYPES)) {
                $result = uploadFile($file, 'pengaduan', ALLOWED_DOC_TYPES);
                if ($result['success']) {
                    $bukti_file = $result['path'];
                    $tipe_bukti = 'dokumen';
                } else {
                    $error = $result['message'];
                }
            } else {
                $error = 'Format file tidak didukung';
            }
        }
        
        if (empty($error)) {
            $stmt = $pdo->prepare("
                INSERT INTO pengaduan (user_id, judul, kategori_id, deskripsi, saran, lokasi_kejadian, prioritas, bukti_file, tipe_bukti, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'menunggu')
            ");
            
            if ($stmt->execute([$user_id, $judul, $kategori_id ?: null, $deskripsi, $saran ?: null, $lokasi ?: null, $prioritas, $bukti_file, $tipe_bukti])) {
                setFlashMessage('success', 'Pengaduan berhasil dikirim! Nomor tiket: ' . $pdo->lastInsertId());
                header('Location: ' . BASE_URL . 'warga/pengaduan.php');
                exit;
            } else {
                $error = 'Gagal mengirim pengaduan';
            }
        }
    }
}

$pageTitle = 'Buat Pengaduan Baru - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">Buat Pengaduan Baru</h1>
    <p class="text-gray-600 mb-6">Laporkan masalah atau aspirasi Anda kepada Pemerintah Desa</p>

    <?php if ($error): ?>
        <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
            <p><?php echo $error; ?></p>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
        <div class="space-y-6">
            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Judul Pengaduan <span class="text-red-500">*</span></label>
                <input type="text" name="judul" required
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Masukkan judul pengaduan">
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Deskripsi Lengkap <span class="text-red-500">*</span></label>
                <textarea name="deskripsi" required rows="6"
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Jelaskan secara detail permasalahan atau aspirasi yang ingin Anda sampaikan..."></textarea>
                <p class="text-sm text-gray-500 mt-1">Semakin detail deskripsi, semakin mudah untuk ditindaklanjuti</p>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Lokasi Kejadian</label>
                <input type="text" name="lokasi"
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Contoh: Jl. Raya Gembong">
                <p class="text-sm text-gray-500 mt-1">Opsional: Bantu kami mengetahui lokasi masalah</p>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Kategori Pengaduan</label>
                <select name="kategori_id" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">-Pilih Kategori Pengaduan-</option>
                    <?php foreach ($kategori_list as $kategori): ?>
                        <option value="<?php echo $kategori['id']; ?>"><?php echo htmlspecialchars($kategori['nama_kategori']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Prioritas</label>
                <div class="flex space-x-4">
                    <label class="flex items-center">
                        <input type="radio" name="prioritas" value="rendah" class="mr-2">
                        <span>Rendah</span>
                    </label>
                    <label class="flex items-center">
                        <input type="radio" name="prioritas" value="sedang" checked class="mr-2">
                        <span>Sedang</span>
                    </label>
                    <label class="flex items-center">
                        <input type="radio" name="prioritas" value="tinggi" class="mr-2">
                        <span>Tinggi</span>
                    </label>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Saran (Opsional)</label>
                <textarea name="saran" rows="4"
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Masukkan saran atau solusi yang Anda usulkan..."></textarea>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Lampiran Bukti</label>
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <input type="file" name="bukti" id="bukti" accept="image/*,video/*,.pdf" class="hidden">
                    <label for="bukti" class="cursor-pointer">
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                        <p class="text-gray-600">Klik untuk memilih file atau seret file ke sini</p>
                    </label>
                </div>
                <p class="text-sm text-gray-500 mt-2">Format: JPG, PNG, atau PDF (Maksimal 5MB)</p>
            </div>

            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition">
                <i class="fas fa-paper-plane mr-2"></i>Kirim Pengaduan
            </button>
        </div>
    </form>
</div>

<?php include '../includes/footer.php'; ?>

