<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $nama_umkm = sanitize($_POST['nama_umkm'] ?? '');
        $nama_pemilik = sanitize($_POST['nama_pemilik'] ?? '');
        $deskripsi = sanitize($_POST['deskripsi'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);
        $telepon = sanitize($_POST['telepon'] ?? '');
        $alamat = sanitize($_POST['alamat'] ?? '');
        $status_verifikasi = sanitize($_POST['status_verifikasi'] ?? 'menunggu');
        $is_unggulan = isset($_POST['is_unggulan']) ? 1 : 0;
        
        if (empty($nama_umkm) || empty($nama_pemilik)) {
            setFlashMessage('error', 'Nama UMKM dan pemilik harus diisi.');
        } else {
            $gambar_utama = null;
            if (isset($_FILES['gambar_utama']) && $_FILES['gambar_utama']['error'] === UPLOAD_ERR_OK) {
                $upload = uploadFile($_FILES['gambar_utama'], 'umkm', ALLOWED_IMAGE_TYPES);
                if ($upload['success']) {
                    $gambar_utama = $upload['path'];
                    if ($action === 'update' && $id > 0) {
                        $stmt = $pdo->prepare("SELECT gambar_utama FROM umkm WHERE id = ?");
                        $stmt->execute([$id]);
                        $old = $stmt->fetch();
                        if ($old && $old['gambar_utama']) {
                            deleteFile($old['gambar_utama']);
                        }
                    }
                }
            }
            
            if ($action === 'create') {
                $stmt = $pdo->prepare("
                    INSERT INTO umkm (nama_umkm, nama_pemilik, deskripsi, kategori_id, telepon, alamat, gambar_utama, status_verifikasi, is_unggulan) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$nama_umkm, $nama_pemilik, $deskripsi, $kategori_id ?: null, $telepon, $alamat, $gambar_utama, $status_verifikasi, $is_unggulan]);
                setFlashMessage('success', 'UMKM berhasil ditambahkan.');
            } else {
                if ($gambar_utama) {
                    $stmt = $pdo->prepare("
                        UPDATE umkm SET nama_umkm = ?, nama_pemilik = ?, deskripsi = ?, kategori_id = ?, telepon = ?, alamat = ?, gambar_utama = ?, status_verifikasi = ?, is_unggulan = ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([$nama_umkm, $nama_pemilik, $deskripsi, $kategori_id ?: null, $telepon, $alamat, $gambar_utama, $status_verifikasi, $is_unggulan, $id]);
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE umkm SET nama_umkm = ?, nama_pemilik = ?, deskripsi = ?, kategori_id = ?, telepon = ?, alamat = ?, status_verifikasi = ?, is_unggulan = ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([$nama_umkm, $nama_pemilik, $deskripsi, $kategori_id ?: null, $telepon, $alamat, $status_verifikasi, $is_unggulan, $id]);
                }
                setFlashMessage('success', 'UMKM berhasil diperbarui.');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $stmt = $pdo->prepare("SELECT gambar_utama FROM umkm WHERE id = ?");
            $stmt->execute([$id]);
            $umkm = $stmt->fetch();
            if ($umkm && $umkm['gambar_utama']) {
                deleteFile($umkm['gambar_utama']);
            }
            $stmt = $pdo->prepare("DELETE FROM umkm WHERE id = ?");
            $stmt->execute([$id]);
            setFlashMessage('success', 'UMKM berhasil dihapus.');
        }
    }
    header('Location: umkm.php');
    exit;
}

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (u.nama_umkm LIKE ? OR u.nama_pemilik LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$stmt = $pdo->prepare("
    SELECT u.*, k.nama_kategori 
    FROM umkm u 
    LEFT JOIN kategori_umkm k ON u.kategori_id = k.id 
    WHERE $where 
    ORDER BY u.created_at DESC
");
$stmt->execute($params);
$umkm_list = $stmt->fetchAll();

$stmt = $pdo->query("SELECT * FROM kategori_umkm ORDER BY nama_kategori");
$kategori_list = $stmt->fetchAll();

$edit_umkm = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM umkm WHERE id = ?");
    $stmt->execute([$id]);
    $edit_umkm = $stmt->fetch();
}

$pageTitle = 'Kelola UMKM - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Kelola UMKM</h1>
            <p class="text-gray-600">Manajemen UMKM desa</p>
        </div>
        <button onclick="document.getElementById('formModal').classList.remove('hidden')" 
                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
            <i class="fas fa-plus mr-2"></i>Tambah UMKM
        </button>
    </div>

    <form method="GET" class="mb-6">
        <div class="flex gap-2">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                   placeholder="Cari UMKM..." 
                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
            <?php if ($search): ?>
                <a href="umkm.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition">Reset</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($umkm_list as $umkm): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <?php if ($umkm['gambar_utama']): ?>
                    <img src="<?php echo upload_url($umkm['gambar_utama']); ?>" alt="<?php echo htmlspecialchars($umkm['nama_umkm']); ?>" class="w-full h-48 object-cover">
                <?php else: ?>
                    <div class="w-full h-48 bg-blue-100 flex items-center justify-center">
                        <i class="fas fa-store text-6xl text-blue-400"></i>
                    </div>
                <?php endif; ?>
                <div class="p-4">
                    <h3 class="font-bold text-lg text-gray-800 mb-2"><?php echo htmlspecialchars($umkm['nama_umkm']); ?></h3>
                    <p class="text-sm text-gray-600 mb-2">Pemilik: <?php echo htmlspecialchars($umkm['nama_pemilik']); ?></p>
                    <p class="text-sm text-gray-600 mb-2">Kategori: <?php echo htmlspecialchars($umkm['nama_kategori'] ?? '-'); ?></p>
                    <div class="flex items-center gap-2 mb-4">
                        <?php echo getStatusBadge($umkm['status_verifikasi'], 'verifikasi'); ?>
                        <?php if ($umkm['is_unggulan']): ?>
                            <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-semibold">Unggulan</span>
                        <?php endif; ?>
                    </div>
                    <div class="flex gap-2">
                        <a href="?edit=<?php echo $umkm['id']; ?>" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded transition">
                            <i class="fas fa-edit mr-1"></i>Edit
                        </a>
                        <form method="POST" class="inline" onsubmit="return confirm('Yakin hapus UMKM ini?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $umkm['id']; ?>">
                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded transition">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div id="formModal" class="<?php echo $edit_umkm ? '' : 'hidden'; ?> fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800"><?php echo $edit_umkm ? 'Edit' : 'Tambah'; ?> UMKM</h2>
            <button onclick="document.getElementById('formModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo $edit_umkm ? 'update' : 'create'; ?>">
            <?php if ($edit_umkm): ?>
                <input type="hidden" name="id" value="<?php echo $edit_umkm['id']; ?>">
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nama UMKM *</label>
                    <input type="text" name="nama_umkm" value="<?php echo htmlspecialchars($edit_umkm['nama_umkm'] ?? ''); ?>" required 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nama Pemilik *</label>
                    <input type="text" name="nama_pemilik" value="<?php echo htmlspecialchars($edit_umkm['nama_pemilik'] ?? ''); ?>" required 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Kategori</label>
                <select name="kategori_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="0">Pilih Kategori</option>
                    <?php foreach ($kategori_list as $kat): ?>
                        <option value="<?php echo $kat['id']; ?>" <?php echo ($edit_umkm['kategori_id'] ?? 0) == $kat['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
                <textarea name="deskripsi" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($edit_umkm['deskripsi'] ?? ''); ?></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Telepon</label>
                    <input type="text" name="telepon" value="<?php echo htmlspecialchars($edit_umkm['telepon'] ?? ''); ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status Verifikasi</label>
                    <select name="status_verifikasi" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="menunggu" <?php echo ($edit_umkm['status_verifikasi'] ?? '') === 'menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                        <option value="terverifikasi" <?php echo ($edit_umkm['status_verifikasi'] ?? '') === 'terverifikasi' ? 'selected' : ''; ?>>Terverifikasi</option>
                        <option value="ditolak" <?php echo ($edit_umkm['status_verifikasi'] ?? '') === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                    </select>
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Alamat</label>
                <textarea name="alamat" rows="2" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($edit_umkm['alamat'] ?? ''); ?></textarea>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Gambar Utama</label>
                <?php if ($edit_umkm && $edit_umkm['gambar_utama']): ?>
                    <img src="<?php echo upload_url($edit_umkm['gambar_utama']); ?>" alt="Current" class="w-32 h-32 object-cover rounded mb-2">
                <?php endif; ?>
                <input type="file" name="gambar_utama" accept="image/*" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="flex items-center">
                    <input type="checkbox" name="is_unggulan" value="1" <?php echo ($edit_umkm['is_unggulan'] ?? 0) ? 'checked' : ''; ?> 
                           class="mr-2">
                    <span class="text-sm text-gray-700">Tandai sebagai UMKM Unggulan</span>
                </label>
            </div>

            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">Simpan</button>
                <button type="button" onclick="document.getElementById('formModal').classList.add('hidden')" 
                        class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition">Batal</button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>



