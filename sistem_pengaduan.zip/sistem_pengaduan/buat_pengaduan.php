<?php
require_once 'includes/auth.php';

require_login('user_login.php');

$page_title = 'Buat Pengaduan Baru';
$message = '';
$message_type = '';

$form = [
    'judul' => '',
    'deskripsi' => '',
    'lokasi' => '',
    'id_kategori' => '',
    'prioritas' => 'sedang'
];

$pdo = getConnection();

$categories_for_select = [];
if ($pdo) {
    try {
        $stmt_categories = $pdo->query("SELECT id, nama_kategori, deskripsi, icon FROM kategori_pengaduan WHERE is_active = 1 ORDER BY nama_kategori ASC");
        $categories_for_select = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching categories: " . $e->getMessage());
        $message = 'Gagal mengambil daftar kategori.';
        $message_type = 'danger';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['judul'] = trim($_POST['judul'] ?? '');
    $form['deskripsi'] = trim($_POST['deskripsi'] ?? '');
    $form['lokasi'] = trim($_POST['lokasi'] ?? '');
    $form['id_kategori'] = $_POST['id_kategori'] ?? '';
    $form['prioritas'] = $_POST['prioritas'] ?? 'sedang';
    $user_id = $_SESSION['user_id'] ?? null;

    if (empty($form['judul']) || empty($form['deskripsi']) || empty($form['id_kategori'])) {
        $message = 'Judul, deskripsi, dan kategori wajib diisi.';
        $message_type = 'danger';
    } elseif (!$pdo) {
        $message = 'Koneksi database tidak tersedia.';
        $message_type = 'danger';
    } elseif (!$user_id) {
        $message = 'Anda harus login untuk membuat pengaduan.';
        $message_type = 'danger';
    } else {
        try {
            // Validasi user_id ada di database
            $user_id_int = (int)$user_id;
            if ($user_id_int <= 0) {
                throw new Exception('User ID tidak valid.');
            }
            
            $stmt_check_user = $pdo->prepare("SELECT id FROM users WHERE id = :id AND is_active = 1 LIMIT 1");
            $stmt_check_user->execute(['id' => $user_id_int]);
            $user_exists = $stmt_check_user->fetch(PDO::FETCH_ASSOC);
            
            if (!$user_exists) {
                throw new Exception('User tidak ditemukan atau tidak aktif. Silakan login kembali.');
            }
            
            // Validasi kategori ada di database
            $kategori_id = (int)$form['id_kategori'];
            if ($kategori_id <= 0) {
                throw new Exception('Kategori yang dipilih tidak valid.');
            }
            
            $stmt_check = $pdo->prepare("SELECT id FROM kategori_pengaduan WHERE id = :id AND is_active = 1 LIMIT 1");
            $stmt_check->execute(['id' => $kategori_id]);
            $kategori_exists = $stmt_check->fetch(PDO::FETCH_ASSOC);
            
            if (!$kategori_exists) {
                throw new Exception('Kategori yang dipilih tidak valid atau tidak aktif.');
            }
            
            // Jika semua validasi berhasil, lanjutkan insert
            // Generate kode pengaduan yang unik
            // Cek apakah kolom kode_pengaduan ada di tabel
            $kode_column_exists = false;
            try {
                $stmt_check_col = $pdo->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pengaduan' AND COLUMN_NAME = 'kode_pengaduan'");
                $kode_column_exists = $stmt_check_col->fetch() !== false;
            } catch (PDOException $e) {
                // Jika query INFORMATION_SCHEMA gagal, coba cara lain
                try {
                    $stmt_check_col = $pdo->query("SHOW COLUMNS FROM pengaduan WHERE Field = 'kode_pengaduan'");
                    $kode_column_exists = $stmt_check_col->fetch() !== false;
                } catch (PDOException $e2) {
                    error_log("Error checking kode_pengaduan column: " . $e2->getMessage());
                    $kode_column_exists = false;
                }
            }
            
            $max_attempts = 10;
            $kode_pengaduan = '';
            $kode_exists = false;
            
            // Hanya cek duplikasi jika kolom kode_pengaduan ada
            if ($kode_column_exists) {
                $kode_exists = true;
                for ($i = 0; $i < $max_attempts && $kode_exists; $i++) {
                    $kode_pengaduan = 'PGD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
                    try {
                        $stmt_check_kode = $pdo->prepare("SELECT id FROM pengaduan WHERE kode_pengaduan = :kode LIMIT 1");
                        $stmt_check_kode->execute(['kode' => $kode_pengaduan]);
                        $kode_exists = $stmt_check_kode->fetch() !== false;
                    } catch (PDOException $e) {
                        // Jika ada error, anggap kode tidak ada dan lanjutkan
                        $kode_exists = false;
                        break;
                    }
                }
                
                if ($kode_exists) {
                    throw new Exception('Gagal membuat kode pengaduan unik. Silakan coba lagi.');
                }
            } else {
                // Jika kolom tidak ada, generate kode sederhana tanpa pengecekan
                $kode_pengaduan = 'PGD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
            }
            
            $pdo->beginTransaction();
            
            // Validasi prioritas
            $prioritas = in_array($form['prioritas'], ['rendah', 'sedang', 'tinggi'], true) 
                ? $form['prioritas'] 
                : 'sedang';
            
            // Validasi dan sanitasi data
            $judul = trim($form['judul']);
            $deskripsi = trim($form['deskripsi']);
            $lokasi = !empty($form['lokasi']) ? trim($form['lokasi']) : null;
            
            if (empty($judul) || empty($deskripsi)) {
                throw new Exception('Judul dan deskripsi tidak boleh kosong.');
            }
            
            if (strlen($judul) > 255) {
                throw new Exception('Judul terlalu panjang (maksimal 255 karakter).');
            }
            
            // Buat query INSERT yang fleksibel berdasarkan kolom yang ada
            if ($kode_column_exists) {
                $stmt = $pdo->prepare("
                    INSERT INTO pengaduan (kode_pengaduan, id_user, id_kategori, judul, deskripsi, lokasi, prioritas, status, tanggal_pengaduan)
                    VALUES (:kode, :id_user, :id_kategori, :judul, :deskripsi, :lokasi, :prioritas, 'menunggu', :tanggal)
                ");
                $result = $stmt->execute([
                    'kode' => $kode_pengaduan,
                    'id_user' => (int)$user_id,
                    'id_kategori' => $kategori_id,
                    'judul' => $judul,
                    'deskripsi' => $deskripsi,
                    'lokasi' => $lokasi,
                    'prioritas' => $prioritas,
                    'tanggal' => date('Y-m-d')
                ]);
            } else {
                // Jika kolom kode_pengaduan tidak ada, insert tanpa kolom tersebut
                $stmt = $pdo->prepare("
                    INSERT INTO pengaduan (id_user, id_kategori, judul, deskripsi, lokasi, prioritas, status, tanggal_pengaduan)
                    VALUES (:id_user, :id_kategori, :judul, :deskripsi, :lokasi, :prioritas, 'menunggu', :tanggal)
                ");
                $result = $stmt->execute([
                    'id_user' => (int)$user_id,
                    'id_kategori' => $kategori_id,
                    'judul' => $judul,
                    'deskripsi' => $deskripsi,
                    'lokasi' => $lokasi,
                    'prioritas' => $prioritas,
                    'tanggal' => date('Y-m-d')
                ]);
            }
            
            if (!$result) {
                $error_info = $stmt->errorInfo();
                throw new PDOException('Gagal menyimpan pengaduan: ' . ($error_info[2] ?? 'Unknown error'));
            }
            
            $pengaduan_id = $pdo->lastInsertId();
            
            if (!$pengaduan_id || $pengaduan_id <= 0) {
                throw new PDOException('Gagal mendapatkan ID pengaduan setelah insert.');
            }

            if (isset($_FILES['lampiran']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = __DIR__ . '/uploads/pengaduan/';
                    if (!is_dir($upload_dir)) {
                        if (!mkdir($upload_dir, 0777, true)) {
                            error_log("Failed to create upload directory: $upload_dir");
                        }
                    }
                    $ext = strtolower(pathinfo($_FILES['lampiran']['name'], PATHINFO_EXTENSION));
                    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
                    if (in_array($ext, $allowed, true) && $_FILES['lampiran']['size'] <= 5 * 1024 * 1024) {
                        $filename = uniqid('lampiran_') . '.' . $ext;
                        if (move_uploaded_file($_FILES['lampiran']['tmp_name'], $upload_dir . $filename)) {
                            $stmtLampiran = $pdo->prepare("
                                INSERT INTO lampiran_pengaduan (id_pengaduan, nama_file, tipe_file, path_file)
                                VALUES (:id_pengaduan, :nama_file, :tipe_file, :path_file)
                            ");
                            $stmtLampiran->execute([
                                'id_pengaduan' => $pengaduan_id,
                                'nama_file' => $_FILES['lampiran']['name'],
                                'tipe_file' => $ext,
                                'path_file' => 'pengaduan/' . $filename
                            ]);
                        }
                    }
                }

            $pdo->commit();
            if ($kode_column_exists && !empty($kode_pengaduan)) {
                $message = 'Pengaduan berhasil diajukan! Nomor Tiket Anda: <strong>' . esc($kode_pengaduan) . '</strong>';
            } else {
                $message = 'Pengaduan berhasil diajukan! ID Pengaduan: <strong>' . esc($pengaduan_id) . '</strong>';
            }
            $message_type = 'success';
            $form = [
                'judul' => '',
                'deskripsi' => '',
                'lokasi' => '',
                'id_kategori' => '',
                'prioritas' => 'sedang'
            ];
        } catch (PDOException $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_code = $e->getCode();
            $error_msg = $e->getMessage();
            error_log("Error creating pengaduan: " . $error_msg);
            error_log("Error details - Code: " . $error_code . ", User ID: " . ($user_id ?? 'null') . ", Kategori ID: " . ($form['id_kategori'] ?? 'null'));
            error_log("SQL State: " . $e->errorInfo[0] ?? 'N/A');
            error_log("Driver Error: " . ($e->errorInfo[2] ?? 'N/A'));
            
            // Pesan error yang lebih informatif
            if ($error_code == '23000' || (isset($e->errorInfo[0]) && $e->errorInfo[0] == '23000')) {
                $message = 'Data tidak valid. Pastikan kategori yang dipilih valid dan semua field terisi dengan benar.';
            } elseif (strpos($error_msg, 'foreign key') !== false) {
                $message = 'Kategori atau user tidak valid. Silakan refresh halaman dan coba lagi.';
            } elseif (strpos($error_msg, 'Duplicate entry') !== false) {
                $message = 'Kode pengaduan sudah ada. Silakan coba lagi.';
            } else {
                $message = 'Terjadi kesalahan saat menyimpan pengaduan: ' . htmlspecialchars($error_msg);
            }
            $message_type = 'danger';
        } catch (Exception $e) {
            if ($pdo && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Unexpected error creating pengaduan: " . $e->getMessage());
            error_log("Exception type: " . get_class($e));
            $message = 'Terjadi kesalahan tidak terduga: ' . htmlspecialchars($e->getMessage());
            $message_type = 'danger';
        }
    }
}

$extra_styles = <<<CSS
.pengaduan-form-section {
    background: #fff;
    border-radius: 15px;
    padding: 40px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    max-width: 900px;
    margin: 0 auto;
}

.pengaduan-form-header {
    text-align: center;
    margin-bottom: 35px;
    padding-bottom: 25px;
    border-bottom: 3px solid var(--primary-color);
}

.pengaduan-form-header h2 {
    color: var(--primary-color);
    font-size: 2rem;
    margin: 0 0 10px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
}

.pengaduan-form-header i {
    color: var(--accent-color);
    font-size: 2.5rem;
}

.pengaduan-form-header p {
    color: #666;
    margin: 0;
    font-size: 1rem;
}

.form-section {
    margin-bottom: 30px;
}

.form-section-label {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 600;
    color: #555;
    margin-bottom: 10px;
    font-size: 1rem;
}

.form-section-label i {
    color: var(--primary-color);
    font-size: 1.1rem;
}

.form-help-text {
    font-size: 0.85rem;
    color: #888;
    margin-top: 5px;
    display: flex;
    align-items: center;
    gap: 5px;
}

.file-upload-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
}

.file-upload-label {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 15px;
    border: 2px dashed var(--border-color);
    border-radius: 8px;
    background: #f8f9fa;
    cursor: pointer;
    transition: all 0.3s ease;
}

.file-upload-label:hover {
    border-color: var(--primary-color);
    background: rgba(27, 94, 32, 0.05);
}

.file-upload-label i {
    margin-right: 10px;
    color: var(--primary-color);
    font-size: 1.5rem;
}

.file-upload-input {
    position: absolute;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

.priority-badges {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.priority-option {
    flex: 1;
    min-width: 120px;
}

.priority-option input[type="radio"] {
    display: none;
}

.priority-option label {
    display: block;
    padding: 15px;
    border: 2px solid var(--border-color);
    border-radius: 8px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background: #fff;
}

.priority-option input[type="radio"]:checked + label {
    border-color: var(--primary-color);
    background: rgba(27, 94, 32, 0.1);
    color: var(--primary-color);
    font-weight: 600;
}

.priority-option label:hover {
    border-color: var(--primary-color);
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.priority-option.rendah input[type="radio"]:checked + label {
    border-color: var(--info-color);
    background: rgba(2, 136, 209, 0.1);
    color: var(--info-color);
}

.priority-option.sedang input[type="radio"]:checked + label {
    border-color: var(--warning-color);
    background: rgba(249, 168, 37, 0.1);
    color: #856404;
}

.priority-option.tinggi input[type="radio"]:checked + label {
    border-color: var(--danger-color);
    background: rgba(211, 47, 47, 0.1);
    color: var(--danger-color);
}

@media (max-width: 768px) {
    .pengaduan-form-section {
        padding: 25px;
    }
    
    .priority-badges {
        flex-direction: column;
    }
    
    .priority-option {
        min-width: 100%;
    }
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4">
    <div class="pengaduan-form-section">
        <div class="pengaduan-form-header">
            <h2>
                <i class="fas fa-bullhorn"></i>
                <?php echo esc($page_title); ?>
            </h2>
            <p>Laporkan masalah atau aspirasi Anda kepada Pemerintah Desa</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo esc($message_type); ?>" style="margin-bottom: 25px;">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if (!is_user_logged_in()): ?>
            <div class="alert alert-info" style="margin-bottom: 25px;">
                <i class="fas fa-info-circle"></i>
                Untuk memudahkan pelacakan, mohon <a href="user_login.php" style="color: var(--info-color); font-weight: 600;">login</a> terlebih dahulu.
            </div>
        <?php endif; ?>

        <form action="buat_pengaduan.php" method="POST" enctype="multipart/form-data">
            <div class="form-section">
                <label for="judul" class="form-section-label">
                    <i class="fas fa-heading"></i>
                    Judul Pengaduan
                </label>
                <input type="text" id="judul" name="judul" class="form-control" required 
                       value="<?php echo esc($form['judul']); ?>" 
                       placeholder="Masukkan judul pengaduan yang jelas dan singkat">
            </div>

            <div class="form-section">
                <label for="deskripsi" class="form-section-label">
                    <i class="fas fa-align-left"></i>
                    Deskripsi Lengkap
                </label>
                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="6" required 
                          placeholder="Jelaskan secara detail masalah atau aspirasi yang ingin Anda sampaikan..."><?php echo esc($form['deskripsi']); ?></textarea>
                <div class="form-help-text">
                    <i class="fas fa-lightbulb"></i>
                    Semakin detail deskripsi, semakin mudah untuk ditindaklanjuti
                </div>
            </div>

            <div class="form-section">
                <label for="lokasi" class="form-section-label">
                    <i class="fas fa-map-marker-alt"></i>
                    Lokasi Kejadian
                </label>
                <input type="text" id="lokasi" name="lokasi" class="form-control" 
                       value="<?php echo esc($form['lokasi']); ?>" 
                       placeholder="Contoh: Jl. Raya Gembong Kulon, RT 05/RW 02">
                <div class="form-help-text">
                    <i class="fas fa-info-circle"></i>
                    Opsional: Bantu kami mengetahui lokasi masalah
                </div>
            </div>

            <div class="form-section">
                <label for="id_kategori" class="form-section-label">
                    <i class="fas fa-tags"></i>
                    Kategori Pengaduan
                </label>
                <select id="id_kategori" name="id_kategori" class="form-control" required>
                    <option value="">-- Pilih Kategori Pengaduan --</option>
                    <?php foreach ($categories_for_select as $cat): ?>
                        <option value="<?php echo esc($cat['id']); ?>" <?php echo ($form['id_kategori'] == $cat['id'] ? 'selected' : ''); ?> data-deskripsi="<?php echo esc($cat['deskripsi'] ?? ''); ?>">
                            <?php echo esc($cat['nama_kategori']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div id="kategori-deskripsi" class="form-help-text" style="display: none; margin-top: 10px; padding: 10px; background: #f0f7ff; border-left: 3px solid var(--primary-color); border-radius: 5px;">
                    <i class="fas fa-info-circle"></i>
                    <span id="kategori-deskripsi-text"></span>
                </div>
            </div>

            <div class="form-section">
                <label class="form-section-label">
                    <i class="fas fa-flag"></i>
                    Prioritas
                </label>
                <div class="priority-badges">
                    <div class="priority-option rendah">
                        <input type="radio" id="prioritas_rendah" name="prioritas" value="rendah" <?php echo ($form['prioritas'] === 'rendah' ? 'checked' : ''); ?>>
                        <label for="prioritas_rendah">
                            <i class="fas fa-arrow-down"></i><br>
                            Rendah
                        </label>
                    </div>
                    <div class="priority-option sedang">
                        <input type="radio" id="prioritas_sedang" name="prioritas" value="sedang" <?php echo ($form['prioritas'] === 'sedang' || empty($form['prioritas']) ? 'checked' : ''); ?>>
                        <label for="prioritas_sedang">
                            <i class="fas fa-minus"></i><br>
                            Sedang
                        </label>
                    </div>
                    <div class="priority-option tinggi">
                        <input type="radio" id="prioritas_tinggi" name="prioritas" value="tinggi" <?php echo ($form['prioritas'] === 'tinggi' ? 'checked' : ''); ?>>
                        <label for="prioritas_tinggi">
                            <i class="fas fa-arrow-up"></i><br>
                            Tinggi
                        </label>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <label class="form-section-label">
                    <i class="fas fa-paperclip"></i>
                    Lampiran Bukti
                </label>
                <div class="file-upload-wrapper">
                    <input type="file" id="lampiran" name="lampiran" class="file-upload-input" accept="image/*,.pdf">
                    <label for="lampiran" class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Klik untuk memilih file atau seret file ke sini</span>
                    </label>
                </div>
                <div class="form-help-text">
                    <i class="fas fa-info-circle"></i>
                    Format: JPG, PNG, atau PDF (Maksimal 5MB)
                </div>
            </div>

            <div id="file-preview" style="margin-top: 15px; display: none;">
                <div style="background: #e8f5e9; padding: 15px; border-radius: 8px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-file" style="color: var(--primary-color); font-size: 1.5rem;"></i>
                    <div style="flex: 1;">
                        <strong id="file-name"></strong>
                        <div style="font-size: 0.85rem; color: #666;" id="file-size"></div>
                    </div>
                    <button type="button" onclick="clearFile()" style="background: none; border: none; color: var(--danger-color); cursor: pointer; font-size: 1.2rem;">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <div style="text-align: center; margin-top: 35px;">
                <button type="submit" class="btn btn-primary" style="padding: 15px 40px; font-size: 1.1rem;">
                    <i class="fas fa-paper-plane"></i> Kirim Pengaduan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('lampiran').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const preview = document.getElementById('file-preview');
        const fileName = document.getElementById('file-name');
        const fileSize = document.getElementById('file-size');
        
        fileName.textContent = file.name;
        fileSize.textContent = formatFileSize(file.size);
        preview.style.display = 'block';
        
        // Update label
        document.querySelector('.file-upload-label span').textContent = file.name;
    }
});

function clearFile() {
    document.getElementById('lampiran').value = '';
    document.getElementById('file-preview').style.display = 'none';
    document.querySelector('.file-upload-label span').textContent = 'Klik untuk memilih file atau seret file ke sini';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Tampilkan deskripsi kategori saat dipilih
document.addEventListener('DOMContentLoaded', function() {
    const kategoriSelect = document.getElementById('id_kategori');
    if (kategoriSelect) {
        kategoriSelect.addEventListener('change', function(e) {
            const selectedOption = e.target.options[e.target.selectedIndex];
            const deskripsi = selectedOption.getAttribute('data-deskripsi');
            const deskripsiDiv = document.getElementById('kategori-deskripsi');
            const deskripsiText = document.getElementById('kategori-deskripsi-text');
            
            if (deskripsi && deskripsi.trim() !== '') {
                deskripsiText.textContent = deskripsi;
                deskripsiDiv.style.display = 'block';
            } else {
                deskripsiDiv.style.display = 'none';
            }
        });
        
        // Trigger change jika sudah ada nilai yang dipilih
        if (kategoriSelect.value) {
            kategoriSelect.dispatchEvent(new Event('change'));
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>