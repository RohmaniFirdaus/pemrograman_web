<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Ajukan Judul TA';
$currentModule = 'tugas-akhir';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();

// Check if already has TA
$existing = $conn->query("SELECT * FROM tugas_akhir WHERE mahasiswa_id = " . $mahasiswa['id'] . " AND status = 'active'")->fetch_assoc();
if ($existing) {
    header('Location: index.php');
    exit;
}

// Get all dosen
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = sanitize($_POST['judul_ta'] ?? '');
    
    if (empty($judul) || strlen($judul) < 10) {
        $error = 'Judul TA harus diisi minimal 10 karakter';
    } else {
        $stmt = $conn->prepare("INSERT INTO tugas_akhir (mahasiswa_id, judul_ta, status_proposal, status) VALUES (?, ?, 'menunggu', 'active')");
        $stmt->bind_param("is", $mahasiswa['id'], $judul);
        
        if ($stmt->execute()) {
            $success = 'Judul TA berhasil diajukan. Menunggu dosen untuk memilih menjadi pembimbing.';
            header('Location: index.php?success=1');
            exit;
        } else {
            $error = 'Gagal mengajukan judul TA';
        }
        $stmt->close();
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Ajukan Judul Tugas Akhir</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="mb-6">
                <label class="block text-gray-700 font-semibold mb-2">Judul Tugas Akhir *</label>
                <textarea name="judul_ta" required rows="4" minlength="10"
                          placeholder="Masukkan judul tugas akhir Anda..."
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"><?= htmlspecialchars($_POST['judul_ta'] ?? '') ?></textarea>
                <p class="text-xs text-gray-500 mt-1">Minimal 10 karakter</p>
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <p class="text-sm text-blue-800">
                    <i class="fas fa-info-circle mr-2"></i>
                    Setelah mengajukan judul, judul akan muncul di semua dosen. Dosen dapat memilih untuk menjadi pembimbing Anda.
                </p>
            </div>
            
            <div class="flex justify-end space-x-4">
                <a href="index.php" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-paper-plane mr-2"></i>Ajukan Judul
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



