<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = !is_readonly_admin();

$pdo = getConnection();
$page_title = 'Kelola Surat Online';
$message = '';
$message_type = '';

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $surat_id = $_POST['id'] ?? null;
    $status = $_POST['status'] ?? null;
    
    if (!$surat_id) {
        $message = 'ID surat tidak valid.';
        $message_type = 'danger';
    } elseif ($action === 'update_status' && !$status) {
        $message = 'Status tidak valid.';
        $message_type = 'danger';
    } else {
        try {
            if ($action === 'update_status') {
                // Validasi status
                $valid_statuses = ['menunggu', 'diproses', 'selesai', 'ditolak'];
                if (!in_array($status, $valid_statuses, true)) {
                    throw new Exception('Status tidak valid.');
                }
                
                // Perbaiki query - gunakan parameter terpisah untuk CASE
                $tanggal_selesai = in_array($status, ['selesai', 'ditolak'], true) ? date('Y-m-d') : null;
                
                if ($tanggal_selesai) {
                    $stmt = $pdo->prepare("UPDATE surat_online SET status = :status, tanggal_selesai = :tanggal_selesai WHERE id = :id");
                    $stmt->execute([
                        'status' => $status,
                        'tanggal_selesai' => $tanggal_selesai,
                        'id' => (int)$surat_id
                    ]);
                } else {
                    $stmt = $pdo->prepare("UPDATE surat_online SET status = :status WHERE id = :id");
                    $stmt->execute([
                        'status' => $status,
                        'id' => (int)$surat_id
                    ]);
                }
                $message = 'Status surat berhasil diperbarui.';
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM surat_online WHERE id = :id");
                $stmt->execute(['id' => (int)$surat_id]);
                $message = 'Surat berhasil dihapus.';
            } else {
                $message = 'Aksi tidak valid.';
                $message_type = 'danger';
            }
            
            if (!isset($message_type) || $message_type !== 'danger') {
                $message_type = 'success';
            }
        } catch (PDOException $e) {
            error_log('Surat admin error: ' . $e->getMessage());
            error_log('Error details - Code: ' . $e->getCode() . ', Action: ' . $action . ', ID: ' . ($surat_id ?? 'null'));
            $message = 'Terjadi kesalahan saat memproses surat: ' . ($e->getCode() == '23000' ? 'Data terkait masih digunakan.' : 'Silakan coba lagi.');
            $message_type = 'danger';
        } catch (Exception $e) {
            error_log('Surat admin error: ' . $e->getMessage());
            $message = $e->getMessage();
            $message_type = 'danger';
        }
    }
}

$surat_list = [];
try {
    $stmt = $pdo->query("
        SELECT s.*, js.nama_surat, u.nama AS pemohon
        FROM surat_online s
        LEFT JOIN jenis_surat js ON js.id = s.id_jenis_surat
        LEFT JOIN users u ON u.id = s.id_user
        ORDER BY s.created_at DESC
    ");
    $surat_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Load surat error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Permohonan Surat Online</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Surat</th>
                    <th>Pemohon</th>
                    <th>Keperluan</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <?php if ($can_update): ?><th>Aksi</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($surat_list)): ?>
                    <tr><td colspan="<?php echo $can_update ? 6 : 5; ?>" class="text-center text-muted">Belum ada permohonan.</td></tr>
                <?php else: ?>
                    <?php foreach ($surat_list as $surat): ?>
                        <tr>
                            <td><?php echo esc($surat['nama_surat']); ?></td>
                            <td><?php echo esc($surat['pemohon']); ?></td>
                            <td><?php echo esc($surat['keperluan']); ?></td>
                            <td><span class="status-badge status-<?php echo esc(strtolower($surat['status'])); ?>"><?php echo esc(ucfirst($surat['status'])); ?></span></td>
                            <td><?php echo date('d M Y', strtotime($surat['tanggal_pengajuan'])); ?></td>
                            <?php if ($can_update): ?>
                                <td>
                                    <form action="surat.php" method="POST" class="d-flex gap-2">
                                        <input type="hidden" name="id" value="<?php echo esc($surat['id']); ?>">
                                        <select name="status" class="form-select form-select-sm">
                                            <?php foreach (['menunggu','diproses','selesai','ditolak'] as $status): ?>
                                                <option value="<?php echo $status; ?>" <?php echo ($surat['status'] === $status ? 'selected' : ''); ?>><?php echo ucfirst($status); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="hidden" name="action" value="update_status">
                                        <button class="btn btn-primary btn-sm">Update</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>









