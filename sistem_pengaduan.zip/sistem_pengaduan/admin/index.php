<?php
require_once '../includes/auth.php';

ensure_management_access();

$admin_page = true;
$page_title = 'Dashboard Sistem Desa';
$pdo = getConnection();
$stats = [
    'total_pengaduan' => 0,
    'menunggu' => 0,
    'diproses' => 0,
    'selesai' => 0,
    'surat_menunggu' => 0,
    'total_surat' => 0,
    'umkm_verified' => 0,
    'berita_published' => 0,
    'total_users' => 0
];

$pending_pengaduan = [];
$pending_surat = [];

try {
    $counts = $pdo->query("SELECT status, COUNT(*) as total FROM pengaduan GROUP BY status")->fetchAll();
    foreach ($counts as $row) {
        $key = strtolower($row['status']);
        if (isset($stats[$key])) {
            $stats[$key] = (int)$row['total'];
        }
    }
    $stats['total_pengaduan'] = array_sum([$stats['menunggu'], $stats['diproses'], $stats['selesai'], $stats['ditolak'] ?? 0]);
    $stats['surat_menunggu'] = (int)$pdo->query("SELECT COUNT(*) FROM surat_online WHERE status IN ('menunggu','diproses')")->fetchColumn();
    $stats['total_surat'] = (int)$pdo->query("SELECT COUNT(*) FROM surat_online")->fetchColumn();
    $stats['umkm_verified'] = (int)$pdo->query("SELECT COUNT(*) FROM umkm WHERE is_verified = 1")->fetchColumn();
    $stats['berita_published'] = (int)$pdo->query("SELECT COUNT(*) FROM berita_desa WHERE is_published = 1")->fetchColumn();
    $stats['total_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_active = 1")->fetchColumn();

    $stmtPending = $pdo->query("
        SELECT p.id, p.kode_pengaduan, p.judul, p.prioritas, p.tanggal_pengaduan, u.nama AS pelapor
        FROM pengaduan p
        LEFT JOIN users u ON u.id = p.id_user
        WHERE p.status = 'menunggu'
        ORDER BY p.created_at DESC
        LIMIT 5
    ");
    $pending_pengaduan = $stmtPending->fetchAll();

    $stmtSurat = $pdo->query("
        SELECT s.id, s.tanggal_pengajuan, js.nama_surat, u.nama AS pemohon, s.status
        FROM surat_online s
        LEFT JOIN jenis_surat js ON js.id = s.id_jenis_surat
        LEFT JOIN users u ON u.id = s.id_user
        WHERE s.status IN ('menunggu','diproses')
        ORDER BY s.created_at DESC
        LIMIT 5
    ");
    $pending_surat = $stmtSurat->fetchAll();
} catch (PDOException $e) {
    error_log('Admin dashboard error: ' . $e->getMessage());
}

$extra_styles = <<<CSS
.admin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
}
.admin-card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: var(--box-shadow);
}
CSS;

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Dashboard Sistem Desa</h2>
    <p class="text-muted">Monitoring pengaduan, surat, UMKM, dan berita desa</p>

    <div class="admin-grid mb-4">
        <div class="admin-card">
            <p class="text-muted mb-1">Total Pengaduan</p>
            <h3><?php echo esc($stats['total_pengaduan']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Menunggu</p>
            <h3><?php echo esc($stats['menunggu']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Diproses</p>
            <h3><?php echo esc($stats['diproses']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Selesai</p>
            <h3><?php echo esc($stats['selesai']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Surat Diproses</p>
            <h3><?php echo esc($stats['surat_menunggu']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">UMKM Terverifikasi</p>
            <h3><?php echo esc($stats['umkm_verified']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Berita Dipublikasi</p>
            <h3><?php echo esc($stats['berita_published']); ?></h3>
        </div>
        <div class="admin-card">
            <p class="text-muted mb-1">Pengguna Aktif</p>
            <h3><?php echo esc($stats['total_users']); ?></h3>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Pengaduan Menunggu</h4>
                    <a href="pengaduan.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <?php if (empty($pending_pengaduan)): ?>
                        <p class="text-muted">Tidak ada pengaduan menunggu.</p>
                    <?php else: ?>
                        <ul class="list-group">
                            <?php foreach ($pending_pengaduan as $p): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo esc($p['judul']); ?></strong>
                                        <div class="text-muted small"><?php echo esc($p['pelapor'] ?? 'Anonim'); ?> · <?php echo date('d M Y', strtotime($p['tanggal_pengaduan'])); ?></div>
                                    </div>
                                    <a href="detail_pengaduan.php?id=<?php echo esc($p['id']); ?>" class="btn btn-outline-primary btn-sm">Detail</a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Surat Online Diproses</h4>
                    <a href="surat.php" class="btn btn-sm btn-outline-primary">Kelola Surat</a>
                </div>
                <div class="card-body">
                    <?php if (empty($pending_surat)): ?>
                        <p class="text-muted">Tidak ada surat menunggu.</p>
                    <?php else: ?>
                        <ul class="list-group">
                            <?php foreach ($pending_surat as $s): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo esc($s['nama_surat']); ?></strong>
                                        <div class="text-muted small"><?php echo esc($s['pemohon'] ?? 'Warga'); ?> · <?php echo date('d M Y', strtotime($s['tanggal_pengajuan'])); ?></div>
                                    </div>
                                    <span class="status-badge status-<?php echo esc(strtolower($s['status'])); ?>"><?php echo esc(ucfirst($s['status'])); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>











