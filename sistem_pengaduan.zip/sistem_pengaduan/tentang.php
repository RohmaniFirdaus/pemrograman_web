<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$stmt = $pdo->query("SELECT * FROM tentang_aplikasi LIMIT 1");
$tentang = $stmt->fetch();

$pageTitle = 'Tentang Aplikasi - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-4xl font-bold text-gray-800 mb-8">Tentang Aplikasi</h1>

        <?php if (!$tentang): ?>
            <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
                <i class="fas fa-info-circle text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-600 text-lg">Informasi tentang aplikasi belum tersedia.</p>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
                <?php if ($tentang['logo_aplikasi']): ?>
                    <div class="p-8 text-center">
                        <img src="<?php echo upload_url($tentang['logo_aplikasi']); ?>" 
                             alt="Logo Aplikasi" 
                             class="w-32 h-32 mx-auto mb-6">
                    </div>
                <?php endif; ?>
                
                <div class="p-8">
                    <h2 class="text-3xl font-bold text-gray-800 mb-4"><?php echo htmlspecialchars($tentang['judul']); ?></h2>
                    
                    <?php if ($tentang['deskripsi']): ?>
                        <div class="prose max-w-none text-gray-700 leading-relaxed mb-6">
                            <?php echo nl2br(htmlspecialchars($tentang['deskripsi'])); ?>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-gray-200 pt-6 mt-6">
                        <?php if ($tentang['versi']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Versi</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($tentang['versi']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($tentang['pengembang']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Pengembang</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($tentang['pengembang']); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="bg-blue-50 rounded-lg p-6 mb-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4">Fitur Aplikasi</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="flex items-start gap-3">
                    <i class="fas fa-paper-plane text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Pengaduan Warga</h4>
                        <p class="text-gray-600 text-sm">Laporkan masalah dan aspirasi warga secara online</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <i class="fas fa-file-alt text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Surat Online</h4>
                        <p class="text-gray-600 text-sm">Permohonan surat secara digital tanpa antri</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <i class="fas fa-newspaper text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Berita Desa</h4>
                        <p class="text-gray-600 text-sm">Informasi terbaru dari Pemerintah Desa</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <i class="fas fa-store text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">UMKM Desa</h4>
                        <p class="text-gray-600 text-sm">Promosi produk dan jasa lokal warga</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <i class="fas fa-calendar text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Kalender Kegiatan</h4>
                        <p class="text-gray-600 text-sm">Agenda rapat dan kegiatan desa</p>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <i class="fas fa-chart-bar text-blue-600 mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-gray-800">Laporan Statistik</h4>
                        <p class="text-gray-600 text-sm">Data dan statistik pelayanan desa</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>



