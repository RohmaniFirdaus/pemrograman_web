<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen', 'pimpinan']);

$pageTitle = 'Detail Surat';
$currentModule = 'surat';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$surat = $conn->query("
    SELECT s.*, m.nim, m.nama_mahasiswa
    FROM surat s 
    LEFT JOIN mahasiswa m ON s.mahasiswa_id = m.id 
    WHERE s.id = $id
")->fetch_assoc();

if (!$surat) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($surat['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($surat['tujuan'] !== 'dosen' || $surat['tujuan_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'pimpinan') {
    $pimpinan = $conn->query("SELECT id FROM pimpinan WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($surat['tujuan'] !== 'pimpinan' || $surat['tujuan_id'] != $pimpinan['id']) {
        header('Location: index.php');
        exit;
    }
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if (in_array($action, ['approve', 'tolak']) && in_array($_SESSION['role'], ['admin', 'dosen', 'pimpinan'])) {
        $status = $action === 'approve' ? 'approved' : 'ditolak';
        $catatan = sanitize($_POST['catatan'] ?? '');
        
        $stmt = $conn->prepare("UPDATE surat SET status = ?, catatan = ? WHERE id = ?");
        $stmt->bind_param("ssi", $status, $catatan, $id);
        if ($stmt->execute()) {
            $success = 'Surat berhasil ' . ($action === 'approve' ? 'disetujui' : 'ditolak');
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    } elseif ($action === 'update_status' && $_SESSION['role'] === 'admin') {
        $status = $_POST['status'] ?? '';
        if ($status) {
            $conn->query("UPDATE surat SET status = '$status' WHERE id = $id");
            $success = 'Status berhasil diupdate';
            header('Location: detail.php?id=' . $id);
            exit;
        }
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Surat</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info Surat -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($surat['nomor_surat'] ?? 'Belum ada nomor') ?></h2>
                <p class="text-gray-600"><?= htmlspecialchars($surat['perihal']) ?></p>
            </div>
            <div class="text-right">
                <?= getStatusBadge($surat['status']) ?>
                <span class="px-2 py-1 rounded text-xs ml-2 <?= $surat['jenis'] === 'masuk' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700' ?>">
                    <?= ucfirst($surat['jenis']) ?>
                </span>
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
            <div>
                <p class="text-gray-600 text-sm">Mahasiswa</p>
                <p class="font-semibold"><?= htmlspecialchars($surat['nim'] ?? '') ?> - <?= htmlspecialchars($surat['nama_mahasiswa'] ?? '') ?></p>
            </div>
            <?php endif; ?>
            <div>
                <p class="text-gray-600 text-sm">Tujuan</p>
                <p class="font-semibold"><?= ucfirst($surat['tujuan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dibuat</p>
                <p class="font-semibold"><?= formatTanggalWaktu($surat['created_at']) ?></p>
            </div>
            <?php if ($surat['file_surat']): ?>
            <div>
                <p class="text-gray-600 text-sm">File Surat</p>
                <a href="<?= BASE_URL . htmlspecialchars($surat['file_surat']) ?>" target="_blank" class="text-blue-600 hover:text-blue-700">
                    <i class="fas fa-file mr-1"></i>Download
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Isi Surat</p>
            <div class="bg-gray-50 p-4 rounded border">
                <p class="whitespace-pre-wrap"><?= nl2br(htmlspecialchars($surat['isi_surat'])) ?></p>
            </div>
        </div>
        
        <?php if ($surat['catatan']): ?>
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Catatan</p>
            <div class="bg-yellow-50 p-4 rounded border border-yellow-200">
                <p><?= nl2br(htmlspecialchars($surat['catatan'])) ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Actions -->
    <?php if (in_array($_SESSION['role'], ['admin', 'dosen', 'pimpinan']) && $surat['status'] === 'menunggu'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Review Surat</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Catatan</label>
                <textarea name="catatan" rows="3" 
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            <div class="flex space-x-4">
                <button type="submit" name="action" value="approve" 
                        class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-check mr-2"></i>Setujui
                </button>
                <button type="submit" name="action" value="tolak" 
                        class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">
                    <i class="fas fa-times mr-2"></i>Tolak
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



