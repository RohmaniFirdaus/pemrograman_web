<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Detail Mahasiswa';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$user = getCurrentUser();

// Get dosen data if role is dosen
$dosen = null;
if ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if (!$dosen) {
        header('Location: index.php');
        exit;
    }
}

$mahasiswa = $conn->query("
    SELECT m.*, p.nama_prodi, d.nama_dosen as nama_dosen_wali, u.username
    FROM mahasiswa m 
    LEFT JOIN program_studi p ON m.prodi_id = p.id 
    LEFT JOIN dosen d ON m.dosen_wali_id = d.id
    LEFT JOIN users u ON m.user_id = u.id
    WHERE m.id = $id
")->fetch_assoc();

if (!$mahasiswa) {
    header('Location: index.php');
    exit;
}

// Validasi akses: dosen hanya bisa melihat mahasiswa bimbingannya
if ($_SESSION['role'] === 'dosen' && $dosen && $mahasiswa['dosen_wali_id'] != $dosen['id']) {
    header('Location: index.php');
    exit;
}

// Get KRS history
$krs_history = $conn->query("SELECT * FROM krs WHERE mahasiswa_id = $id ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Get latest nilai
$nilai_terbaru = $conn->query("
    SELECT n.*, mk.nama_mk, mk.sks 
    FROM nilai n 
    JOIN mata_kuliah mk ON n.mk_id = mk.id 
    WHERE n.mahasiswa_id = $id 
    ORDER BY n.created_at DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Mahasiswa</h1>
        <div class="flex space-x-2">
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="edit.php?id=<?= $id ?>" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-edit mr-2"></i>Edit
            </a>
            <?php endif; ?>
            <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <!-- Info Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Mahasiswa</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Wali</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_dosen_wali'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Angkatan</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['angkatan'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">IPK</p>
                <p class="font-semibold text-gray-800"><?= number_format($mahasiswa['ipk'], 2) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Tempuh</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['sks_tempuh'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($mahasiswa['status']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Username</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['username'] ?? '-') ?></p>
            </div>
        </div>
    </div>
    
    <!-- KRS History -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Riwayat KRS</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Tahun Akademik</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($krs_history)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Belum ada KRS</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_history as $k): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= $k['semester'] ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($k['tahun_akademik']) ?></td>
                            <td class="px-4 py-2"><?= $k['sks_diambil'] ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($k['status']) ?></td>
                            <td class="px-4 py-2"><?= formatTanggal($k['created_at']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Nilai Terbaru -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Nilai Terbaru</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Nilai</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($nilai_terbaru)): ?>
                        <tr>
                            <td colspan="4" class="px-4 py-4 text-center text-gray-500">Belum ada nilai</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($nilai_terbaru as $n): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $n['sks'] ?></td>
                            <td class="px-4 py-2">
                                <span class="font-semibold"><?= $n['nilai_huruf'] ?></span>
                                <span class="text-gray-600">(<?= number_format($n['nilai_angka'], 2) ?>)</span>
                            </td>
                            <td class="px-4 py-2"><?= $n['semester'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



