<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Laporan Pengaduan';
$currentModule = 'laporan';

$conn = getDBConnection();

// Statistik pengaduan
$total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan")->fetch_assoc()['total'];
$pengaduan_open = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE status IN ('menunggu', 'diproses')")->fetch_assoc()['total'];
$pengaduan_selesai = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE status = 'selesai'")->fetch_assoc()['total'];

// By priority
$by_priority = $conn->query("
    SELECT prioritas, COUNT(*) as jumlah
    FROM pengaduan
    GROUP BY prioritas
")->fetch_all(MYSQLI_ASSOC);

// By status
$by_status = $conn->query("
    SELECT status, COUNT(*) as jumlah
    FROM pengaduan
    GROUP BY status
")->fetch_all(MYSQLI_ASSOC);

// By kategori
$by_kategori = $conn->query("
    SELECT kategori, COUNT(*) as jumlah
    FROM pengaduan
    GROUP BY kategori
    ORDER BY jumlah DESC
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Laporan Pengaduan</h1>
        <a href="export.php?type=pengaduan" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export Excel
        </a>
    </div>
    
    <!-- Statistik -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Total Pengaduan</p>
            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_pengaduan ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Open</p>
            <p class="text-3xl font-bold text-yellow-600 mt-2"><?= $pengaduan_open ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Selesai</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= $pengaduan_selesai ?></p>
        </div>
    </div>
    
    <!-- By Priority -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jumlah Pengaduan (by Priority)</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($by_priority as $p): ?>
            <div class="text-center p-4 rounded <?= 
                $p['prioritas'] === 'high' ? 'bg-red-50' : 
                ($p['prioritas'] === 'medium' ? 'bg-yellow-50' : 'bg-green-50')
            ?>">
                <p class="text-gray-600 text-sm"><?= strtoupper($p['prioritas']) ?></p>
                <p class="text-2xl font-bold text-gray-800"><?= $p['jumlah'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- By Status -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jumlah Pengaduan (by Status)</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <?php foreach ($by_status as $s): ?>
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm"><?= ucfirst(str_replace('_', ' ', $s['status'])) ?></p>
                <p class="text-2xl font-bold text-gray-800"><?= $s['jumlah'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- By Kategori -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Top 10 Kategori Pengaduan</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kategori</th>
                        <th class="px-4 py-2 text-left">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($by_kategori as $k): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($k['kategori']) ?></td>
                        <td class="px-4 py-2"><?= $k['jumlah'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



