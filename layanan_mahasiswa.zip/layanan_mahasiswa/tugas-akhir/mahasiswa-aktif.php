<?php
require_once '../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Mahasiswa Aktif TA';
$currentModule = 'tugas-akhir';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    $ta_list = $conn->query("
        SELECT ta.*, m.nim, m.nama_mahasiswa, p.nama_prodi
        FROM tugas_akhir ta
        JOIN mahasiswa m ON ta.mahasiswa_id = m.id
        LEFT JOIN program_studi p ON m.prodi_id = p.id
        WHERE (ta.dosen_pembimbing1_id = " . $dosen['id'] . " OR ta.dosen_pembimbing2_id = " . $dosen['id'] . ")
        AND ta.status = 'active'
        ORDER BY ta.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin
    $ta_list = $conn->query("
        SELECT ta.*, m.nim, m.nama_mahasiswa, p.nama_prodi, d1.nama_dosen as pembimbing1, d2.nama_dosen as pembimbing2
        FROM tugas_akhir ta
        JOIN mahasiswa m ON ta.mahasiswa_id = m.id
        LEFT JOIN program_studi p ON m.prodi_id = p.id
        LEFT JOIN dosen d1 ON ta.dosen_pembimbing1_id = d1.id
        LEFT JOIN dosen d2 ON ta.dosen_pembimbing2_id = d2.id
        WHERE ta.status = 'active'
        ORDER BY ta.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Mahasiswa Aktif Tugas Akhir</h1>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Prodi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Pembimbing 1</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Pembimbing 2</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Judul TA</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Progress</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($ta_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '9' : '6' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada mahasiswa aktif</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ta_list as $t): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nim']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nama_mahasiswa']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nama_prodi']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['pembimbing1'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['pembimbing2'] ?? '-') ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4"><?= htmlspecialchars($t['judul_ta']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($t['status_proposal']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-1 bg-gray-200 rounded-full h-2 mr-2" style="width: 100px">
                                        <div class="bg-green-600 h-2 rounded-full" style="width: <?= $t['progress'] ?>%"></div>
                                    </div>
                                    <span class="text-sm"><?= $t['progress'] ?>%</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $t['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="repository.php?id=<?= $t['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-folder"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



