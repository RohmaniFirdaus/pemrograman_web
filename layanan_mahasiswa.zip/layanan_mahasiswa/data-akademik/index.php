<?php
require_once '../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Data Akademik';
$currentModule = 'data-akademik';

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Data Akademik</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="dosen/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-chalkboard-teacher text-blue-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Data Dosen</h2>
                </div>
            </div>
        </a>
        
        <a href="mahasiswa/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-users text-green-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Data Mahasiswa</h2>
                </div>
            </div>
        </a>
        
        <a href="mata-kuliah/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-book text-purple-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Data Mata Kuliah</h2>
                </div>
            </div>
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



