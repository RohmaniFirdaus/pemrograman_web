<?php
require_once '../config/config.php';
requireRole(['dosen']);

$pageTitle = 'Review KRS';
$currentModule = 'krs';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
$krs = $conn->query("
    SELECT k.*, m.nim, m.nama_mahasiswa, m.semester as mhs_semester, m.ipk, m.sks_tempuh, p.nama_prodi
    FROM krs k 
    JOIN mahasiswa m ON k.mahasiswa_id = m.id 
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    WHERE k.id = $id
")->fetch_assoc();

if (!$krs || $krs['status'] !== 'menunggu_approval') {
    header('Location: index.php');
    exit;
}

// Check if this dosen is the advisor
$mhs = $conn->query("SELECT dosen_wali_id FROM mahasiswa WHERE id = " . $krs['mahasiswa_id'])->fetch_assoc();
if ($mhs['dosen_wali_id'] != $dosen['id']) {
    header('Location: index.php');
    exit;
}

// Get KRS details
$krs_detail = $conn->query("
    SELECT kd.*, mk.kode_mk, mk.nama_mk, mk.sks, mk.jenis, mk.semester as mk_semester
    FROM krs_detail kd
    JOIN mata_kuliah mk ON kd.mk_id = mk.id
    WHERE kd.krs_id = $id
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

// Check prerequisites
$prasyarat_issues = [];
foreach ($krs_detail as $detail) {
    $prasyarat = $conn->query("
        SELECT pm.mk_prasyarat_id, mk2.kode_mk, mk2.nama_mk
        FROM prasyarat_mk pm
        JOIN mata_kuliah mk2 ON pm.mk_prasyarat_id = mk2.id
        WHERE pm.mk_id = " . $detail['mk_id']
    )->fetch_all(MYSQLI_ASSOC);
    
    foreach ($prasyarat as $p) {
        // Check if mahasiswa has taken this prerequisite
        $taken = $conn->query("
            SELECT COUNT(*) as total 
            FROM nilai n
            JOIN krs k2 ON n.krs_id = k2.id
            WHERE n.mahasiswa_id = " . $krs['mahasiswa_id'] . "
            AND n.mk_id = " . $p['mk_prasyarat_id'] . "
            AND n.status = 'final'
            AND n.nilai_huruf != 'E'
        ")->fetch_assoc()['total'];
        
        if ($taken == 0) {
            $prasyarat_issues[] = [
                'mk' => $detail['kode_mk'] . ' - ' . $detail['nama_mk'],
                'prasyarat' => $p['kode_mk'] . ' - ' . $p['nama_mk']
            ];
        }
    }
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $catatan = sanitize($_POST['catatan'] ?? '');
    
    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE krs SET status = 'approved', catatan_dosen = ?, tanggal_approve = NOW() WHERE id = ?");
        $stmt->bind_param("si", $catatan, $id);
        if ($stmt->execute()) {
            // Update admin untuk verifikasi
            $conn->query("UPDATE krs SET status = 'diproses' WHERE id = $id");
            $success = 'KRS berhasil disetujui';
            header('Location: index.php?success=1');
            exit;
        }
        $stmt->close();
    } elseif ($action === 'revisi') {
        $stmt = $conn->prepare("UPDATE krs SET status = 'ditolak', catatan_dosen = ? WHERE id = ?");
        $stmt->bind_param("si", $catatan, $id);
        if ($stmt->execute()) {
            $success = 'KRS ditolak, mahasiswa dapat merevisi';
            header('Location: index.php?success=1');
            exit;
        }
        $stmt->close();
    } elseif ($action === 'tolak') {
        $stmt = $conn->prepare("UPDATE krs SET status = 'ditolak', catatan_dosen = ? WHERE id = ?");
        $stmt->bind_param("si", $catatan, $id);
        if ($stmt->execute()) {
            $success = 'KRS ditolak';
            header('Location: index.php?success=1');
            exit;
        }
        $stmt->close();
    }
    $conn->close();
}

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Review KRS</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Mahasiswa</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold"><?= htmlspecialchars($krs['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold"><?= htmlspecialchars($krs['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold"><?= $krs['mhs_semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">IPK</p>
                <p class="font-semibold"><?= number_format($krs['ipk'], 2) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Prodi</p>
                <p class="font-semibold"><?= htmlspecialchars($krs['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Tempuh</p>
                <p class="font-semibold"><?= $krs['sks_tempuh'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Max SKS</p>
                <p class="font-semibold">24</p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Diambil</p>
                <p class="font-semibold"><?= $krs['sks_diambil'] ?></p>
            </div>
        </div>
    </div>
    
    <!-- Rincian Mata Kuliah -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Rincian Mata Kuliah</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Nama MK</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Wajib/Pilihan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($krs_detail as $index => $d): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $index + 1 ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['kode_mk']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_mk']) ?></td>
                        <td class="px-4 py-2"><?= $d['sks'] ?></td>
                        <td class="px-4 py-2">
                            <span class="px-2 py-1 rounded text-xs <?= $d['jenis'] === 'wajib' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>">
                                <?= ucfirst($d['jenis']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Status Prasyarat -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Status Prasyarat</h2>
        <?php if (empty($prasyarat_issues)): ?>
            <div class="flex items-center text-green-600">
                <i class="fas fa-check-circle text-2xl mr-3"></i>
                <p>Semua prasyarat terpenuhi</p>
            </div>
        <?php else: ?>
            <div class="flex items-center text-orange-600 mb-4">
                <i class="fas fa-exclamation-triangle text-2xl mr-3"></i>
                <p>Ada prasyarat yang belum terpenuhi</p>
            </div>
            <ul class="list-disc list-inside space-y-2">
                <?php foreach ($prasyarat_issues as $issue): ?>
                <li>
                    <span class="font-semibold"><?= htmlspecialchars($issue['mk']) ?></span> 
                    memerlukan prasyarat: 
                    <span class="text-red-600"><?= htmlspecialchars($issue['prasyarat']) ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    
    <!-- Catatan Dosen -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Catatan Dosen</h2>
        <form method="POST">
            <textarea name="catatan" rows="5" placeholder="Masukkan catatan atau saran untuk mahasiswa..."
                      class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"></textarea>
            
            <div class="mt-4 flex space-x-4">
                <button type="submit" name="action" value="approve" 
                        class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-check mr-2"></i>Setujui KRS
                </button>
                <button type="submit" name="action" value="revisi" 
                        class="bg-yellow-600 text-white px-6 py-2 rounded-lg hover:bg-yellow-700">
                    <i class="fas fa-edit mr-2"></i>Minta Revisi
                </button>
                <button type="submit" name="action" value="tolak" 
                        class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">
                    <i class="fas fa-times mr-2"></i>Tolak KRS
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



