<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Data Dosen';
$currentModule = 'data-akademik-mahasiswa';

$conn = getDBConnection();

$search = $_GET['search'] ?? '';

$query = "SELECT d.*, p.nama_prodi 
          FROM dosen d 
          LEFT JOIN program_studi p ON d.prodi_id = p.id 
          WHERE d.status = 'active'";

if ($search) {
    $query .= " AND (d.nip LIKE '%" . $conn->real_escape_string($search) . "%' OR d.nama_dosen LIKE '%" . $conn->real_escape_string($search) . "%')";
}

$query .= " ORDER BY d.nama_dosen";

$dosen_list = $conn->query($query)->fetch_all(MYSQLI_ASSOC);
$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Data Dosen</h1>
        <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Search -->
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="flex gap-4">
            <input type="text" name="search" placeholder="Cari nama atau NIP dosen..." 
                   value="<?= htmlspecialchars($search) ?>"
                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    
    <!-- Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIP</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Prodi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jabatan</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($dosen_list)): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">Tidak ada data dosen</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($dosen_list as $d): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($d['nip']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($d['nama_dosen']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($d['nama_prodi'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($d['jabatan'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($d['email'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="dosen-detail.php?id=<?= $d['id'] ?>" class="text-blue-600 hover:text-blue-700" title="Detail">
                                    <i class="fas fa-eye mr-2"></i>Detail
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>




