<?php
require_once '../config/config.php';
requireLogin();

$user = getCurrentUser();
$role = $_SESSION['role'];

switch ($role) {
    case 'admin':
        header('Location: ' . BASE_URL . 'dashboard/admin.php');
        break;
    case 'mahasiswa':
        header('Location: ' . BASE_URL . 'dashboard/mahasiswa.php');
        break;
    case 'dosen':
        header('Location: ' . BASE_URL . 'dashboard/dosen.php');
        break;
    case 'pimpinan':
        header('Location: ' . BASE_URL . 'dashboard/pimpinan.php');
        break;
    default:
        logout();
}
exit;
?>



