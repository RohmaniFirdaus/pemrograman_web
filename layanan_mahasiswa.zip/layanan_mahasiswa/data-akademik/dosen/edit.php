<?php
require_once '../../config/config.php';
requireRole(['admin']);

$pageTitle = 'Edit Dosen';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$dosen = $conn->query("SELECT d.*, u.username, u.email as user_email FROM dosen d LEFT JOIN users u ON d.user_id = u.id WHERE d.id = $id")->fetch_assoc();
$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);

if (!$dosen) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nip = sanitize($_POST['nip'] ?? '');
    $nama = sanitize($_POST['nama_dosen'] ?? '');
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $jabatan = sanitize($_POST['jabatan'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $no_hp = sanitize($_POST['no_hp'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    if (empty($nip) || empty($nama)) {
        $error = 'NIP dan Nama wajib diisi';
    } else {
        $stmt = $conn->prepare("UPDATE dosen SET nip = ?, nama_dosen = ?, prodi_id = ?, jabatan = ?, email = ?, no_hp = ?, status = ? WHERE id = ?");
        $stmt->bind_param("ssissssi", $nip, $nama, $prodi_id, $jabatan, $email, $no_hp, $status, $id);
        
        if ($stmt->execute()) {
            // Update user email if changed
            if ($dosen['user_id']) {
                $stmt2 = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                $stmt2->bind_param("si", $email, $dosen['user_id']);
                $stmt2->execute();
                $stmt2->close();
            }
            
            $success = 'Data dosen berhasil diupdate';
            header('Location: index.php?success=1');
            exit;
        } else {
            $error = 'Gagal mengupdate data dosen';
        }
        $stmt->close();
    }
    $conn->close();
}

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Edit Dosen</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">NIP *</label>
                    <input type="text" name="nip" required value="<?= htmlspecialchars($dosen['nip']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama Dosen *</label>
                    <input type="text" name="nama_dosen" required value="<?= htmlspecialchars($dosen['nama_dosen']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi</label>
                    <select name="prodi_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= $dosen['prodi_id'] == $p['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($p['nama_prodi']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jabatan</label>
                    <input type="text" name="jabatan" value="<?= htmlspecialchars($dosen['jabatan'] ?? '') ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($dosen['email'] ?? '') ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">No. HP</label>
                    <input type="text" name="no_hp" value="<?= htmlspecialchars($dosen['no_hp'] ?? '') ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="active" <?= $dosen['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $dosen['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Username</label>
                    <input type="text" value="<?= htmlspecialchars($dosen['username'] ?? '') ?>" disabled
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100">
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Update
                </button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



