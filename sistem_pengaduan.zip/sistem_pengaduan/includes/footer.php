    <footer class="bg-blue-600 text-white mt-auto w-full">
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
                <div>
                    <h3 class="text-lg font-bold mb-3">Sistem Desa Gembong Kulon</h3>
                    <p class="text-blue-100 text-sm">Layanan digital terpadu untuk pengaduan warga, surat online, berita desa, UMKM, dan kalender kegiatan.</p>
                </div>
                <div>
                    <h3 class="text-lg font-bold mb-3">Tautan Cepat</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo BASE_URL; ?>index.php" class="text-blue-100 hover:text-white transition">Beranda</a></li>
                        <li><a href="<?php echo BASE_URL; ?>berita.php" class="text-blue-100 hover:text-white transition">Berita</a></li>
                        <li><a href="<?php echo BASE_URL; ?>umkm.php" class="text-blue-100 hover:text-white transition">UMKM</a></li>
                        <li><a href="<?php echo BASE_URL; ?>kalender.php" class="text-blue-100 hover:text-white transition">Kalender</a></li>
                        <li><a href="<?php echo BASE_URL; ?>profil_desa.php" class="text-blue-100 hover:text-white transition">Profil Desa</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-lg font-bold mb-3">Kontak</h3>
                    <p class="text-blue-100 text-sm">
                        Desa Gembong Kulon<br>
                        Kecamatan Talang<br>
                        Kabupaten Tegal<br>
                        Provinsi Jawa Tengah
                    </p>
                </div>
            </div>
            <div class="border-t border-blue-500 pt-6 text-center">
                <p class="text-blue-200 text-sm">© <?php echo date('Y'); ?> Pemerintah Desa Gembong Kulon. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>

