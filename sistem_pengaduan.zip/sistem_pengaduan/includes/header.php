<?php
if (!isset($pageTitle)) {
    $pageTitle = APP_NAME;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <style>
        [v-cloak] { display: none; }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">
    <nav class="bg-blue-600 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="<?php echo BASE_URL; ?>index.php" class="flex items-center space-x-2">
                        <i class="fas fa-shield-alt text-2xl"></i>
                        <div>
                            <div class="font-bold text-lg">Sistem Desa Gembong Kulon</div>
                            <div class="text-xs text-blue-100">TALANG - KABUPATEN TEGAL</div>
                        </div>
                    </a>
                </div>
                
                <div class="hidden md:flex items-center space-x-6">
                    <?php if (isLoggedIn()): ?>
                        <?php if (hasRole('admin')): ?>
                            <a href="<?php echo BASE_URL; ?>admin/index.php" class="hover:text-blue-200 transition">Dashboard</a>
                            <a href="<?php echo BASE_URL; ?>admin/pengaduan.php" class="hover:text-blue-200 transition">Pengaduan</a>
                            <a href="<?php echo BASE_URL; ?>admin/surat.php" class="hover:text-blue-200 transition">Surat</a>
                            <a href="<?php echo BASE_URL; ?>admin/laporan.php" class="hover:text-blue-200 transition">Laporan</a>
                            <a href="<?php echo BASE_URL; ?>admin/validasi_pengguna.php" class="hover:text-blue-200 transition">Validasi Pengguna</a>
                            <a href="<?php echo BASE_URL; ?>admin/users.php" class="hover:text-blue-200 transition">Pengguna</a>
                            <a href="<?php echo BASE_URL; ?>admin/berita.php" class="hover:text-blue-200 transition">Berita Desa</a>
                            <a href="<?php echo BASE_URL; ?>admin/umkm.php" class="hover:text-blue-200 transition">UMKM</a>
                            <a href="<?php echo BASE_URL; ?>admin/kalender.php" class="hover:text-blue-200 transition">Kalender</a>
                            <a href="<?php echo BASE_URL; ?>admin/profil_desa.php" class="hover:text-blue-200 transition">Profil Desa</a>
                        <?php elseif (hasRole('kepala_desa')): ?>
                            <a href="<?php echo BASE_URL; ?>kepala_desa/index.php" class="hover:text-blue-200 transition">Dashboard</a>
                            <a href="<?php echo BASE_URL; ?>index.php" class="hover:text-blue-200 transition">Beranda</a>
                            <a href="<?php echo BASE_URL; ?>kepala_desa/laporan.php" class="hover:text-blue-200 transition">Laporan</a>
                        <?php else: ?>
                            <a href="<?php echo BASE_URL; ?>index.php" class="hover:text-blue-200 transition">Beranda</a>
                            <a href="<?php echo BASE_URL; ?>warga/dashboard.php" class="hover:text-blue-200 transition">Dashboard Warga</a>
                            <a href="<?php echo BASE_URL; ?>warga/profil.php" class="hover:text-blue-200 transition">Profil Saya</a>
                            <a href="<?php echo BASE_URL; ?>warga/pengaduan.php" class="hover:text-blue-200 transition">Pengaduan</a>
                            <a href="<?php echo BASE_URL; ?>warga/surat_online.php" class="hover:text-blue-200 transition">Surat Online</a>
                            <a href="<?php echo BASE_URL; ?>berita.php" class="hover:text-blue-200 transition">Berita</a>
                            <a href="<?php echo BASE_URL; ?>umkm.php" class="hover:text-blue-200 transition">UMKM</a>
                            <a href="<?php echo BASE_URL; ?>profil_desa.php" class="hover:text-blue-200 transition">Profil Desa</a>
                        <?php endif; ?>
                        
                        <div class="flex items-center space-x-2 ml-4 pl-4 border-l border-blue-500">
                            <span class="bg-white text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">
                                Halo, <?php echo htmlspecialchars($_SESSION['user_nama'] ?? 'User'); ?>
                            </span>
                            <a href="<?php echo BASE_URL; ?>logout.php" class="bg-blue-700 hover:bg-blue-800 px-4 py-2 rounded transition">
                                Keluar
                            </a>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>index.php" class="hover:text-blue-200 transition">Beranda</a>
                        <a href="<?php echo BASE_URL; ?>profil_desa.php" class="hover:text-blue-200 transition">Profil Desa</a>
                        <a href="<?php echo BASE_URL; ?>tentang.php" class="hover:text-blue-200 transition">Tentang</a>
                        <a href="<?php echo BASE_URL; ?>berita.php" class="hover:text-blue-200 transition">Berita</a>
                        <a href="<?php echo BASE_URL; ?>umkm.php" class="hover:text-blue-200 transition">UMKM</a>
                        <a href="<?php echo BASE_URL; ?>kalender.php" class="hover:text-blue-200 transition">Kalender</a>
                        <a href="<?php echo BASE_URL; ?>cek_status.php" class="hover:text-blue-200 transition">Cek Status</a>
                        <a href="<?php echo BASE_URL; ?>login.php" class="bg-blue-700 hover:bg-blue-800 px-4 py-2 rounded transition">Login</a>
                        <a href="<?php echo BASE_URL; ?>register.php" class="bg-white text-blue-600 hover:bg-blue-50 px-4 py-2 rounded transition">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

