<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Jadwal Kuliah';
$currentModule = 'data-akademik';

$mk_id = intval($_GET['id'] ?? 0);
if (!$mk_id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mk = $conn->query("SELECT * FROM mata_kuliah WHERE id = $mk_id")->fetch_assoc();
$jadwal_list = $conn->query("
    SELECT j.*, d.nama_dosen 
    FROM jadwal_kuliah j 
    LEFT JOIN dosen d ON j.dosen_id = d.id 
    WHERE j.mk_id = $mk_id 
    ORDER BY j.hari, j.jam_mulai
")->fetch_all(MYSQLI_ASSOC);
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);

if (!$mk) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'tambah') {
        $dosen_id = intval($_POST['dosen_id'] ?? 0);
        $kelas = sanitize($_POST['kelas'] ?? '');
        $hari = $_POST['hari'] ?? '';
        $jam_mulai = $_POST['jam_mulai'] ?? '';
        $jam_selesai = $_POST['jam_selesai'] ?? '';
        $ruangan = sanitize($_POST['ruangan'] ?? '');
        $semester = sanitize($_POST['semester'] ?? '');
        $tahun_akademik = sanitize($_POST['tahun_akademik'] ?? '');
        
        if ($dosen_id && $kelas && $hari && $jam_mulai && $jam_selesai) {
            $stmt = $conn->prepare("INSERT INTO jadwal_kuliah (mk_id, dosen_id, kelas, hari, jam_mulai, jam_selesai, ruangan, semester, tahun_akademik) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iisssssss", $mk_id, $dosen_id, $kelas, $hari, $jam_mulai, $jam_selesai, $ruangan, $semester, $tahun_akademik);
            if ($stmt->execute()) {
                $success = 'Jadwal berhasil ditambahkan';
                header('Location: jadwal.php?id=' . $mk_id);
                exit;
            }
            $stmt->close();
        }
    } elseif ($action === 'hapus') {
        $jadwal_id = intval($_POST['jadwal_id'] ?? 0);
        $conn->query("DELETE FROM jadwal_kuliah WHERE id = $jadwal_id AND mk_id = $mk_id");
        $success = 'Jadwal berhasil dihapus';
        header('Location: jadwal.php?id=' . $mk_id);
        exit;
    }
}

$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Jadwal Kuliah - <?= htmlspecialchars($mk['nama_mk']) ?></h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Form Tambah Jadwal -->
    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Tambah Jadwal</h2>
        <form method="POST">
            <input type="hidden" name="action" value="tambah">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Dosen</label>
                    <select name="dosen_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Dosen</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_dosen']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Kelas</label>
                    <input type="text" name="kelas" required placeholder="A, B, C..."
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Hari</label>
                    <select name="hari" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Hari</option>
                        <option value="Senin">Senin</option>
                        <option value="Selasa">Selasa</option>
                        <option value="Rabu">Rabu</option>
                        <option value="Kamis">Kamis</option>
                        <option value="Jumat">Jumat</option>
                        <option value="Sabtu">Sabtu</option>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Ruangan</label>
                    <input type="text" name="ruangan" placeholder="Ruang..."
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jam Mulai</label>
                    <input type="time" name="jam_mulai" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jam Selesai</label>
                    <input type="time" name="jam_selesai" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester</label>
                    <input type="text" name="semester" placeholder="Ganjil/Genap"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tahun Akademik</label>
                    <input type="text" name="tahun_akademik" placeholder="2024/2025"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-plus mr-2"></i>Tambah Jadwal
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- List Jadwal -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Dosen</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Kelas</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Hari</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jam</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Ruangan</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tahun Akademik</th>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($jadwal_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '8' : '7' ?>" class="px-6 py-4 text-center text-gray-500">Belum ada jadwal</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($jadwal_list as $j): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['nama_dosen'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['kelas']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['hari']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= date('H:i', strtotime($j['jam_mulai'])) ?> - <?= date('H:i', strtotime($j['jam_selesai'])) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['ruangan'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['semester']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($j['tahun_akademik']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <form method="POST" class="inline" onsubmit="return confirm('Hapus jadwal ini?')">
                                    <input type="hidden" name="action" value="hapus">
                                    <input type="hidden" name="jadwal_id" value="<?= $j['id'] ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



