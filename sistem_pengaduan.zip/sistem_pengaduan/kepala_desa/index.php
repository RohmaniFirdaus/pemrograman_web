<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('kepala_desa');

$pdo = getDBConnection();

$stmt = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM pengaduan) as total_pengaduan,
        (SELECT COUNT(*) FROM surat_menyurat) as total_surat,
        (SELECT COUNT(*) FROM umkm WHERE status_verifikasi = 'terverifikasi') as umkm_terverifikasi,
        (SELECT COUNT(*) FROM users WHERE role = 'warga' AND status_verifikasi = 'terverifikasi') as warga_terverifikasi
");
$stats = $stmt->fetch();

$pageTitle = 'Dashboard Kepala Desa - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">Dashboard Kepala Desa</h1>
    <p class="text-gray-600 mb-8">Monitoring dan laporan sistem desa</p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Total Pengaduan</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_pengaduan'] ?? 0; ?></p>
                </div>
                <i class="fas fa-file-alt text-4xl text-blue-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Total Surat</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_surat'] ?? 0; ?></p>
                </div>
                <i class="fas fa-envelope text-4xl text-blue-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">UMKM Terverifikasi</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $stats['umkm_terverifikasi'] ?? 0; ?></p>
                </div>
                <i class="fas fa-shopping-bag text-4xl text-orange-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Warga Terverifikasi</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $stats['warga_terverifikasi'] ?? 0; ?></p>
                </div>
                <i class="fas fa-users text-4xl text-purple-600"></i>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <a href="<?php echo BASE_URL; ?>kepala_desa/laporan.php" class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:border-blue-500 transition">
            <div class="flex items-center">
                <i class="fas fa-chart-bar text-4xl text-blue-600 mr-4"></i>
                <div>
                    <h3 class="text-xl font-bold text-gray-800">Laporan</h3>
                    <p class="text-gray-600">Lihat laporan per periode dan per kategori</p>
                </div>
            </div>
        </a>

        <a href="<?php echo BASE_URL; ?>index.php" class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:border-blue-500 transition">
            <div class="flex items-center">
                <i class="fas fa-home text-4xl text-blue-600 mr-4"></i>
                <div>
                    <h3 class="text-xl font-bold text-gray-800">Beranda</h3>
                    <p class="text-gray-600">Kembali ke halaman beranda</p>
                </div>
            </div>
        </a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

