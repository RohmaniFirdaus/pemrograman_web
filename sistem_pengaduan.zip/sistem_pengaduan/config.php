<?php
// sistem_pengaduan/includes/config.php

// AKTIFKAN INI HANYA SAAT PENGEMBANGAN UNTUK MELIHAT ERROR
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'pengaduan'); // Pastikan ini nama database Anda: 'pengaduan'
define('DB_USER', 'root');         // Biasanya 'root' untuk XAMPP tanpa password
define('DB_PASS', '');             // Kosongkan jika XAMPP Anda tidak ada password untuk root

// Fungsi untuk mendapatkan koneksi PDO
function getConnection() {
    static $pdo = null; // Menggunakan static agar koneksi hanya dibuat sekali

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Mengaktifkan mode error exception
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     // Mengambil hasil sebagai array asosiatif
            PDO::ATTR_EMULATE_PREPARES   => false,                // Lebih baik untuk keamanan dan kinerja
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log error, jangan tampilkan di produksi
            error_log("Database connection failed: " . $e->getMessage());
            // Berikan pesan ramah pengguna atau alihkan ke halaman error
            die("Terjadi kesalahan koneksi database. Silakan coba lagi nanti.");
        }
    }
    return $pdo;
}

// Fungsi sanitasi output
function esc($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}