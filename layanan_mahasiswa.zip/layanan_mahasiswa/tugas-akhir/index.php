<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Tugas Akhir';
$currentModule = 'tugas-akhir';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $ta = $conn->query("
        SELECT ta.*, d1.nama_dosen as pembimbing1, d2.nama_dosen as pembimbing2
        FROM tugas_akhir ta
        LEFT JOIN dosen d1 ON ta.dosen_pembimbing1_id = d1.id
        LEFT JOIN dosen d2 ON ta.dosen_pembimbing2_id = d2.id
        WHERE ta.mahasiswa_id = " . $mahasiswa['id'] . "
        ORDER BY ta.created_at DESC
        LIMIT 1
    ")->fetch_assoc();
    
    if (!$ta) {
        header('Location: ajukan.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    $ta_list = $conn->query("
        SELECT ta.*, m.nim, m.nama_mahasiswa
        FROM tugas_akhir ta
        JOIN mahasiswa m ON ta.mahasiswa_id = m.id
        WHERE (ta.dosen_pembimbing1_id = " . $dosen['id'] . " OR ta.dosen_pembimbing2_id = " . $dosen['id'] . ")
        AND ta.status = 'active'
        ORDER BY ta.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin
    $ta_list = $conn->query("
        SELECT ta.*, m.nim, m.nama_mahasiswa, d1.nama_dosen as pembimbing1, d2.nama_dosen as pembimbing2
        FROM tugas_akhir ta
        JOIN mahasiswa m ON ta.mahasiswa_id = m.id
        LEFT JOIN dosen d1 ON ta.dosen_pembimbing1_id = d1.id
        LEFT JOIN dosen d2 ON ta.dosen_pembimbing2_id = d2.id
        ORDER BY ta.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Tugas Akhir</h1>
        <?php if ($_SESSION['role'] === 'mahasiswa' && !$ta): ?>
        <a href="ajukan.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-plus mr-2"></i>Ajukan Judul TA
        </a>
        <?php endif; ?>
    </div>
    
    <?php if ($_SESSION['role'] === 'mahasiswa' && $ta): ?>
    <!-- Status TA Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Status TA</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">Judul</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['judul_ta']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pembimbing 1</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['pembimbing1'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pembimbing 2</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['pembimbing2'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status Proposal</p>
                <p><?= getStatusBadge($ta['status_proposal']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Progress</p>
                <div class="flex items-center">
                    <div class="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                        <div class="bg-green-600 h-2 rounded-full" style="width: <?= $ta['progress'] ?>%"></div>
                    </div>
                    <span class="text-sm font-semibold"><?= $ta['progress'] ?>%</span>
                </div>
            </div>
            <?php if ($ta['deadline_sidang']): ?>
            <div>
                <p class="text-gray-600 text-sm">Deadline Sidang</p>
                <p class="font-semibold text-gray-800"><?= formatTanggal($ta['deadline_sidang']) ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="mt-6 flex space-x-4">
            <a href="repository.php?id=<?= $ta['id'] ?>" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                <i class="fas fa-upload mr-2"></i>Upload Bab
            </a>
            <a href="jadwal-bimbingan.php?id=<?= $ta['id'] ?>" class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700">
                <i class="fas fa-calendar mr-2"></i>Jadwal Bimbingan
            </a>
            <a href="pengajuan-sidang.php?id=<?= $ta['id'] ?>" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-gavel mr-2"></i>Pengajuan Sidang
            </a>
        </div>
    </div>
    
    <!-- Repository File -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Repository File</h2>
        <a href="repository.php?id=<?= $ta['id'] ?>" class="text-blue-600 hover:text-blue-700">
            <i class="fas fa-folder-open mr-2"></i>Lihat Repository
        </a>
    </div>
    
    <?php elseif (in_array($_SESSION['role'], ['dosen', 'admin'])): ?>
    <!-- List TA -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Judul TA</th>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Pembimbing 1</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Pembimbing 2</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Progress</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($ta_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '7' : '4' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada data tugas akhir</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ta_list as $t): ?>
                        <tr class="hover:bg-gray-50">
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nim']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nama_mahasiswa']) ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4"><?= htmlspecialchars($t['judul_ta']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['pembimbing1'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['pembimbing2'] ?? '-') ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($t['status_proposal']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-1 bg-gray-200 rounded-full h-2 mr-2" style="width: 100px">
                                        <div class="bg-green-600 h-2 rounded-full" style="width: <?= $t['progress'] ?>%"></div>
                                    </div>
                                    <span class="text-sm"><?= $t['progress'] ?>%</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $t['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if ($_SESSION['role'] === 'dosen'): ?>
                                <a href="repository.php?id=<?= $t['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-folder"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



