<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa']);

$pageTitle = 'Riwayat Pembayaran';
$currentModule = 'tagihan';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $riwayat = $conn->query("
        SELECT p.*, t.nomor_tagihan, t.semester, t.tahun_akademik
        FROM pembayaran p
        JOIN tagihan t ON p.tagihan_id = t.id
        WHERE p.mahasiswa_id = " . $mahasiswa['id'] . "
        ORDER BY p.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin
    $riwayat = $conn->query("
        SELECT p.*, t.nomor_tagihan, m.nim, m.nama_mahasiswa
        FROM pembayaran p
        JOIN tagihan t ON p.tagihan_id = t.id
        JOIN mahasiswa m ON p.mahasiswa_id = m.id
        ORDER BY p.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Riwayat Pembayaran</h1>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nomor Pembayaran</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nomor Tagihan</th>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <?php else: ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Metode</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nominal</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tanggal</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($riwayat)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '9' : '8' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada riwayat pembayaran</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($riwayat as $r): ?>
                        <tr class="hover:bg-gray-50">
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['nim']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['nama_mahasiswa']) ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['nomor_pembayaran']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['nomor_tagihan']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <?php else: ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $r['semester'] ?> - <?= htmlspecialchars($r['tahun_akademik']) ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php
                                $metode = [
                                    'transfer_bank' => 'Transfer Bank',
                                    'e_wallet' => 'E-Wallet',
                                    'qris' => 'QRIS',
                                    'credit_card' => 'Credit Card'
                                ];
                                echo $metode[$r['metode_pembayaran']] ?? $r['metode_pembayaran'];
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatRupiah($r['nominal']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($r['status']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatTanggalWaktu($r['created_at']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if ($r['status'] === 'success' && $r['e_receipt']): ?>
                                <a href="<?= BASE_URL . htmlspecialchars($r['e_receipt']) ?>" target="_blank" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-download"></i> Receipt
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



