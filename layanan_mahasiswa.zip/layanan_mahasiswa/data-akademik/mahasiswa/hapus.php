<?php
require_once '../../config/config.php';
requireRole(['admin']);

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE id = $id")->fetch_assoc();

if ($mahasiswa) {
    // Check if mahasiswa has related data
    $check_krs = $conn->query("SELECT COUNT(*) as total FROM krs WHERE mahasiswa_id = $id")->fetch_assoc()['total'];
    $check_nilai = $conn->query("SELECT COUNT(*) as total FROM nilai WHERE mahasiswa_id = $id")->fetch_assoc()['total'];
    
    if ($check_krs > 0 || $check_nilai > 0) {
        // Set status to inactive instead of delete
        $conn->query("UPDATE mahasiswa SET status = 'inactive' WHERE id = $id");
        if ($mahasiswa['user_id']) {
            $conn->query("UPDATE users SET status = 'inactive' WHERE id = " . $mahasiswa['user_id']);
        }
        $_SESSION['success'] = 'Mahasiswa dinonaktifkan karena memiliki data terkait';
    } else {
        // Safe to delete
        if ($mahasiswa['user_id']) {
            $conn->query("DELETE FROM users WHERE id = " . $mahasiswa['user_id']);
        }
        $conn->query("DELETE FROM mahasiswa WHERE id = $id");
        $_SESSION['success'] = 'Data mahasiswa berhasil dihapus';
    }
}

$conn->close();
header('Location: index.php');
exit;
?>



