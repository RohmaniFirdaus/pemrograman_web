<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Laporan Keuangan';
$currentModule = 'laporan';

$conn = getDBConnection();

// Statistik keuangan
$total_tagihan = $conn->query("SELECT SUM(total_tagihan) as total FROM tagihan")->fetch_assoc()['total'] ?? 0;
$total_bayar = $conn->query("SELECT SUM(total_bayar) as total FROM tagihan")->fetch_assoc()['total'] ?? 0;
$total_sisa = $conn->query("SELECT SUM(sisa_tagihan) as total FROM tagihan WHERE status IN ('open', 'pending')")->fetch_assoc()['total'] ?? 0;
$total_beasiswa = $conn->query("SELECT SUM(nominal) as total FROM beasiswa WHERE status = 'dicairkan'")->fetch_assoc()['total'] ?? 0;

// Collection rate per prodi
$collection_rate = $conn->query("
    SELECT p.nama_prodi,
           COUNT(t.id) as jumlah_tagihan,
           SUM(t.total_tagihan) as total_tagihan,
           SUM(t.total_bayar) as total_bayar,
           (SUM(t.total_bayar) / SUM(t.total_tagihan) * 100) as collection_rate
    FROM tagihan t
    JOIN mahasiswa m ON t.mahasiswa_id = m.id
    JOIN program_studi p ON m.prodi_id = p.id
    GROUP BY p.id
    ORDER BY collection_rate DESC
")->fetch_all(MYSQLI_ASSOC);

// Payment trend (last 6 months)
$payment_trend = $conn->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as bulan,
           COUNT(*) as jumlah,
           SUM(nominal) as total
    FROM pembayaran
    WHERE status = 'success'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY bulan
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Laporan Keuangan</h1>
        <a href="export.php?type=keuangan" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
    </div>
    
    <!-- Statistik -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Total Tagihan</p>
            <p class="text-2xl font-bold text-gray-800 mt-2"><?= formatRupiah($total_tagihan) ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Total Bayar</p>
            <p class="text-2xl font-bold text-green-600 mt-2"><?= formatRupiah($total_bayar) ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Sisa Tagihan</p>
            <p class="text-2xl font-bold text-red-600 mt-2"><?= formatRupiah($total_sisa) ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Beasiswa Tersalurkan</p>
            <p class="text-2xl font-bold text-blue-600 mt-2"><?= formatRupiah($total_beasiswa) ?></p>
        </div>
    </div>
    
    <!-- Collection Rate per Prodi -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Collection Rate per Prodi</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Program Studi</th>
                        <th class="px-4 py-2 text-left">Jumlah Tagihan</th>
                        <th class="px-4 py-2 text-left">Total Tagihan</th>
                        <th class="px-4 py-2 text-left">Total Bayar</th>
                        <th class="px-4 py-2 text-left">Collection Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($collection_rate as $c): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($c['nama_prodi']) ?></td>
                        <td class="px-4 py-2"><?= $c['jumlah_tagihan'] ?></td>
                        <td class="px-4 py-2"><?= formatRupiah($c['total_tagihan']) ?></td>
                        <td class="px-4 py-2"><?= formatRupiah($c['total_bayar']) ?></td>
                        <td class="px-4 py-2">
                            <span class="font-semibold <?= $c['collection_rate'] >= 80 ? 'text-green-600' : ($c['collection_rate'] >= 50 ? 'text-yellow-600' : 'text-red-600') ?>">
                                <?= number_format($c['collection_rate'], 2) ?>%
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Payment Trend -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Trend Pembayaran 6 Bulan</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Bulan</th>
                        <th class="px-4 py-2 text-left">Jumlah Transaksi</th>
                        <th class="px-4 py-2 text-left">Total Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payment_trend as $p): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= date('M Y', strtotime($p['bulan'] . '-01')) ?></td>
                        <td class="px-4 py-2"><?= $p['jumlah'] ?></td>
                        <td class="px-4 py-2"><?= formatRupiah($p['total']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



