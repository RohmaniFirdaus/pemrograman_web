<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('warga');

$pdo = getDBConnection();
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_lengkap = sanitize($_POST['nama_lengkap'] ?? '');
    $no_hp = sanitize($_POST['no_hp'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    
    // Handle file uploads
    $foto_profil = $user['foto_profil'];
    $foto_ktp = $user['foto_ktp'];
    
    if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($_FILES['foto_profil'], 'profil', ALLOWED_IMAGE_TYPES);
        if ($result['success']) {
            if ($foto_profil) deleteFile($foto_profil);
            $foto_profil = $result['path'];
        }
    }
    
    if (isset($_FILES['foto_ktp']) && $_FILES['foto_ktp']['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($_FILES['foto_ktp'], 'ktp', ALLOWED_IMAGE_TYPES);
        if ($result['success']) {
            if ($foto_ktp) deleteFile($foto_ktp);
            $foto_ktp = $result['path'];
            $stmt = $pdo->prepare("UPDATE users SET nama_lengkap = ?, no_hp = ?, alamat = ?, foto_profil = ?, foto_ktp = ?, status_verifikasi = 'menunggu' WHERE id = ?");
            $stmt->execute([$nama_lengkap, $no_hp, $alamat, $foto_profil, $foto_ktp, $user_id]);
        }
    } else {
        $stmt = $pdo->prepare("UPDATE users SET nama_lengkap = ?, no_hp = ?, alamat = ?, foto_profil = ? WHERE id = ?");
        $stmt->execute([$nama_lengkap, $no_hp, $alamat, $foto_profil, $user_id]);
    }
    
    setFlashMessage('success', 'Profil berhasil diperbarui');
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$pageTitle = 'Profil Saya - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg p-8 shadow-sm border border-gray-200">
            <div class="text-center mb-6">
                <i class="fas fa-user-circle text-6xl text-blue-600 mb-4"></i>
                <h1 class="text-3xl font-bold text-gray-800">Profil Saya</h1>
            </div>

            <div class="mb-6 p-4 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                <p class="font-semibold text-gray-800 mb-2">Status Verifikasi: 
                    <?php echo getStatusBadge($user['status_verifikasi'], 'verifikasi'); ?>
                </p>
                <p class="text-sm text-gray-600">Lengkapi profil Anda dan upload foto KTP untuk verifikasi. Akun yang belum terverifikasi tidak dapat membuat pengaduan.</p>
            </div>

            <form method="POST" enctype="multipart/form-data" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">NIK</label>
                        <input type="text" value="<?php echo htmlspecialchars($user['nik']); ?>" disabled
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Email</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Nama Lengkap <span class="text-red-500">*</span></label>
                        <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($user['nama_lengkap']); ?>" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">No. HP</label>
                        <input type="tel" name="no_hp" value="<?php echo htmlspecialchars($user['no_hp']); ?>"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Alamat Lengkap</label>
                        <input type="text" name="alamat" value="<?php echo htmlspecialchars($user['alamat']); ?>"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Foto Profil</label>
                        <input type="file" name="foto_profil" accept="image/*"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        <p class="text-sm text-gray-500 mt-1">Format: JPG, PNG (Maks 2MB)</p>
                        <?php if ($user['foto_profil']): ?>
                            <img src="<?php echo upload_url($user['foto_profil']); ?>" alt="Foto Profil" class="mt-2 w-24 h-24 object-cover rounded">
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Foto KTP <span class="text-red-500">*</span></label>
                        <input type="file" name="foto_ktp" accept="image/*"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        <p class="text-sm text-gray-500 mt-1">Format: JPG, PNG (Maks 5MB)</p>
                        <?php if ($user['foto_ktp']): ?>
                            <img src="<?php echo upload_url($user['foto_ktp']); ?>" alt="Foto KTP" class="mt-2 w-24 h-24 object-cover rounded">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="flex space-x-4">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition">
                        <i class="fas fa-save mr-2"></i>Simpan Perubahan
                    </button>
                    <a href="<?php echo BASE_URL; ?>warga/dashboard.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold transition">
                        <i class="fas fa-arrow-left mr-2"></i>Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

