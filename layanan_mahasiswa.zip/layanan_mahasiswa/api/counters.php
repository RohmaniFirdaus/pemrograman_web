<?php
require_once '../config/config.php';

$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'active'")->fetch_assoc()['total'];
$dosen = $conn->query("SELECT COUNT(*) as total FROM dosen WHERE status = 'active'")->fetch_assoc()['total'];
$mata_kuliah = $conn->query("SELECT COUNT(*) as total FROM mata_kuliah WHERE status = 'active'")->fetch_assoc()['total'];
$prodi = $conn->query("SELECT COUNT(*) as total FROM program_studi")->fetch_assoc()['total'];

$conn->close();

header('Content-Type: application/json');
echo json_encode([
    'mahasiswa' => (int)$mahasiswa,
    'dosen' => (int)$dosen,
    'mata_kuliah' => (int)$mata_kuliah,
    'prodi' => (int)$prodi
]);
?>



