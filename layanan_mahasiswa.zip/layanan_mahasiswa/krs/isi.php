<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Isi KRS';
$currentModule = 'krs';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT m.*, p.nama_prodi FROM mahasiswa m JOIN program_studi p ON m.prodi_id = p.id WHERE m.user_id = " . $user['id'])->fetch_assoc();

// Get available courses
$mata_kuliah = $conn->query("
    SELECT mk.*, j.id as jadwal_id, j.hari, j.jam_mulai, j.jam_selesai, j.kelas, j.ruangan, d.nama_dosen
    FROM mata_kuliah mk
    LEFT JOIN jadwal_kuliah j ON mk.id = j.mk_id
    LEFT JOIN dosen d ON j.dosen_id = d.id
    WHERE mk.prodi_id = " . $mahasiswa['prodi_id'] . " 
    AND mk.status = 'active'
    AND mk.semester <= " . $mahasiswa['semester'] . "
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

// Get current KRS if exists
$krs_aktif = $conn->query("SELECT * FROM krs WHERE mahasiswa_id = " . $mahasiswa['id'] . " AND status IN ('draft', 'menunggu_approval') ORDER BY created_at DESC LIMIT 1")->fetch_assoc();

$selected_courses = [];
if ($krs_aktif) {
    $selected = $conn->query("SELECT mk_id, jadwal_id FROM krs_detail WHERE krs_id = " . $krs_aktif['id'])->fetch_all(MYSQLI_ASSOC);
    foreach ($selected as $s) {
        $selected_courses[$s['mk_id']] = $s['jadwal_id'];
    }
}

$max_sks = 24; // Default max SKS
$sks_diambil = $krs_aktif ? $krs_aktif['sks_diambil'] : 0;
$sks_available = $max_sks - $sks_diambil;

$conn->close();

require_once '../includes/header.php';
?>

<div id="app" class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Isi KRS</h1>
    
    <!-- Info Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <p class="text-gray-600 text-sm">Prodi</p>
                <p class="font-semibold"><?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold"><?= $mahasiswa['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Diambil</p>
                <p class="font-semibold">{{ totalSKS }}</p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Available</p>
                <p class="font-semibold">{{ maxSKS - totalSKS }}</p>
            </div>
        </div>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Available Courses -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah Available</h2>
            <div class="space-y-3 max-h-96 overflow-y-auto">
                <template v-for="mk in mataKuliah" :key="mk.id">
                    <div class="border rounded-lg p-4 hover:bg-gray-50">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center">
                                    <input type="checkbox" 
                                           :value="mk.id" 
                                           v-model="selectedCourses"
                                           @change="updateSchedule(mk)"
                                           class="mr-3">
                                    <div>
                                        <p class="font-semibold">{{ mk.kode_mk }} - {{ mk.nama_mk }}</p>
                                        <p class="text-sm text-gray-600">{{ mk.sks }} SKS | {{ mk.jenis }}</p>
                                        <template v-if="mk.jadwal_id">
                                            <p class="text-xs text-gray-500 mt-1">
                                                {{ mk.hari }}, {{ mk.jam_mulai }} - {{ mk.jam_selesai }} | {{ mk.kelas }} | {{ mk.ruangan }}
                                            </p>
                                            <p class="text-xs text-gray-500">{{ mk.nama_dosen }}</p>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
        </div>
        
        <!-- Selected Courses & Schedule -->
        <div class="space-y-6">
            <!-- Selected Courses -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah Dipilih</h2>
                <div class="space-y-2 max-h-64 overflow-y-auto">
                    <template v-for="mkId in selectedCourses" :key="mkId">
                        <div class="text-sm p-2 bg-green-50 rounded">
                            {{ getMataKuliah(mkId).kode_mk }} - {{ getMataKuliah(mkId).nama_mk }}
                        </div>
                    </template>
                    <p v-if="selectedCourses.length === 0" class="text-gray-500 text-sm text-center py-4">Belum ada mata kuliah dipilih</p>
                </div>
            </div>
            
            <!-- Temporary Schedule -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Jadwal Sementara</h2>
                <div class="text-xs">
                    <table class="w-full border-collapse">
                        <thead>
                            <tr>
                                <th class="border p-1">Waktu</th>
                                <th class="border p-1">Sen</th>
                                <th class="border p-1">Sel</th>
                                <th class="border p-1">Rab</th>
                                <th class="border p-1">Kam</th>
                                <th class="border p-1">Jum</th>
                                <th class="border p-1">Sab</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="time in timeSlots" :key="time">
                                <td class="border p-1 font-semibold">{{ time }}</td>
                                <td v-for="day in days" :key="day" class="border p-1 text-xs">
                                    <template v-for="mk in getSchedule(day, time)" :key="mk.id">
                                        {{ mk.kode_mk }}<br>{{ mk.kelas }}
                                    </template>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Actions -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-end space-x-4">
            <button @click="saveDraft" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                <i class="fas fa-save mr-2"></i>Simpan Draft
            </button>
            <button @click="kirimApproval" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-paper-plane mr-2"></i>Kirim untuk Approval
            </button>
        </div>
    </div>
</div>

<script>
const { createApp } = Vue;

createApp({
    data() {
        return {
            mataKuliah: <?= json_encode($mata_kuliah) ?>,
            selectedCourses: <?= json_encode(array_keys($selected_courses)) ?>,
            courseSchedules: <?= json_encode($selected_courses) ?>,
            maxSKS: <?= $max_sks ?>,
            days: ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'],
            timeSlots: ['08:00', '10:00', '13:00', '15:00'],
            krsId: <?= $krs_aktif ? $krs_aktif['id'] : 'null' ?>
        }
    },
    computed: {
        totalSKS() {
            return this.selectedCourses.reduce((total, mkId) => {
                const mk = this.getMataKuliah(mkId);
                return total + (mk ? mk.sks : 0);
            }, 0);
        }
    },
    methods: {
        getMataKuliah(id) {
            return this.mataKuliah.find(mk => mk.id == id) || {};
        },
        updateSchedule(mk) {
            if (this.selectedCourses.includes(mk.id)) {
                this.courseSchedules[mk.id] = mk.jadwal_id;
            } else {
                delete this.courseSchedules[mk.id];
            }
        },
        getSchedule(day, time) {
            return this.mataKuliah.filter(mk => {
                if (!this.selectedCourses.includes(mk.id)) return false;
                if (mk.hari !== day) return false;
                const start = mk.jam_mulai?.substring(0, 5);
                return start === time;
            });
        },
        async saveDraft() {
            await this.saveKRS('draft');
            alert('Draft berhasil disimpan');
        },
        async kirimApproval() {
            if (this.totalSKS === 0) {
                alert('Pilih minimal satu mata kuliah');
                return;
            }
            if (this.totalSKS > this.maxSKS) {
                alert('SKS melebihi batas maksimal');
                return;
            }
            if (confirm('Kirim KRS untuk approval?')) {
                await this.saveKRS('menunggu_approval');
                alert('KRS berhasil dikirim untuk approval');
                window.location.href = 'index.php';
            }
        },
        async saveKRS(status) {
            const formData = new FormData();
            formData.append('action', 'save');
            formData.append('status', status);
            formData.append('krs_id', this.krsId || '');
            formData.append('courses', JSON.stringify(this.selectedCourses));
            formData.append('schedules', JSON.stringify(this.courseSchedules));
            
            const response = await fetch('save.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            if (result.success) {
                this.krsId = result.krs_id;
            }
        }
    }
}).mount('#app');
</script>

<?php require_once '../includes/footer.php'; ?>



