<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Repository Tugas Akhir';
$currentModule = 'tugas-akhir';

$ta_id = intval($_GET['id'] ?? 0);
if (!$ta_id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$ta = $conn->query("
    SELECT ta.*, m.nim, m.nama_mahasiswa
    FROM tugas_akhir ta
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    WHERE ta.id = $ta_id
")->fetch_assoc();

if (!$ta) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['dosen_pembimbing1_id'] != $dosen['id'] && $ta['dosen_pembimbing2_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get repository files
$files = $conn->query("
    SELECT * FROM repository_ta 
    WHERE ta_id = $ta_id 
    ORDER BY tipe_file, created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'upload' && $_SESSION['role'] === 'mahasiswa') {
        $tipe_file = $_POST['tipe_file'] ?? '';
        $file = $_FILES['file'] ?? null;
        
        if ($tipe_file && $file && $file['error'] === UPLOAD_ERR_OK) {
            $upload = uploadFile($file, UPLOAD_REPOSITORY, ['pdf', 'doc', 'docx', 'zip', 'rar']);
            
            if ($upload['success']) {
                $stmt = $conn->prepare("INSERT INTO repository_ta (ta_id, nama_file, tipe_file, path_file, ukuran_file, status) VALUES (?, ?, ?, ?, ?, 'menunggu')");
                $stmt->bind_param("isssi", $ta_id, $file['name'], $tipe_file, $upload['path'], $upload['size']);
                if ($stmt->execute()) {
                    $success = 'File berhasil diupload';
                    header('Location: repository.php?id=' . $ta_id);
                    exit;
                }
                $stmt->close();
            } else {
                $error = $upload['message'];
            }
        }
    } elseif ($action === 'review' && $_SESSION['role'] === 'dosen') {
        $file_id = intval($_POST['file_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $catatan = sanitize($_POST['catatan'] ?? '');
        
        if ($file_id && $status) {
            $stmt = $conn->prepare("UPDATE repository_ta SET status = ?, catatan = ? WHERE id = ? AND ta_id = ?");
            $stmt->bind_param("ssii", $status, $catatan, $file_id, $ta_id);
            if ($stmt->execute()) {
                $success = 'Review berhasil disimpan';
                header('Location: repository.php?id=' . $ta_id);
                exit;
            }
            $stmt->close();
        }
    } elseif ($action === 'hapus' && $_SESSION['role'] === 'mahasiswa') {
        $file_id = intval($_POST['file_id'] ?? 0);
        $file = $conn->query("SELECT path_file FROM repository_ta WHERE id = $file_id AND ta_id = $ta_id")->fetch_assoc();
        if ($file) {
            if (file_exists($file['path_file'])) {
                unlink($file['path_file']);
            }
            $conn->query("DELETE FROM repository_ta WHERE id = $file_id AND ta_id = $ta_id");
            $success = 'File berhasil dihapus';
            header('Location: repository.php?id=' . $ta_id);
            exit;
        }
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Repository File</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info TA -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($ta['judul_ta']) ?></h2>
        <p class="text-gray-600"><?= htmlspecialchars($ta['nim']) ?> - <?= htmlspecialchars($ta['nama_mahasiswa']) ?></p>
    </div>
    
    <!-- Upload File (Mahasiswa) -->
    <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Upload File</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="upload">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tipe File</label>
                    <select name="tipe_file" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Tipe</option>
                        <option value="bab1">Bab 1</option>
                        <option value="bab2">Bab 2</option>
                        <option value="bab3">Bab 3</option>
                        <option value="bab4">Bab 4</option>
                        <option value="bab5">Bab 5</option>
                        <option value="source_code">Source Code</option>
                        <option value="lainnya">Lainnya</option>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">File</label>
                    <input type="file" name="file" required accept=".pdf,.doc,.docx,.zip,.rar"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-upload mr-2"></i>Upload File
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- List Files -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Repository File</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">File</th>
                        <th class="px-4 py-2 text-left">Tgl Upload</th>
                        <th class="px-4 py-2 text-left">Size</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <?php if ($_SESSION['role'] === 'dosen'): ?>
                        <th class="px-4 py-2 text-left">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($files)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'dosen' ? '5' : '4' ?>" class="px-4 py-4 text-center text-gray-500">Belum ada file</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($files as $f): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2">
                                <a href="<?= BASE_URL . htmlspecialchars($f['path_file']) ?>" target="_blank" class="text-blue-600 hover:text-blue-700">
                                    <i class="fas fa-file mr-2"></i><?= htmlspecialchars($f['nama_file']) ?>
                                </a>
                                <br><small class="text-gray-500"><?= ucfirst(str_replace('_', ' ', $f['tipe_file'])) ?></small>
                            </td>
                            <td class="px-4 py-2"><?= formatTanggal($f['created_at']) ?></td>
                            <td class="px-4 py-2"><?= number_format($f['ukuran_file'] / 1024, 2) ?> KB</td>
                            <td class="px-4 py-2"><?= getStatusBadge($f['status']) ?></td>
                            <?php if ($_SESSION['role'] === 'dosen'): ?>
                            <td class="px-4 py-2">
                                <button onclick="reviewFile(<?= $f['id'] ?>)" class="text-green-600 hover:text-green-700 mr-3">
                                    <i class="fas fa-check"></i> Review
                                </button>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php if ($f['catatan']): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'dosen' ? '5' : '4' ?>" class="px-4 py-2 bg-yellow-50">
                                <p class="text-sm"><strong>Catatan:</strong> <?= htmlspecialchars($f['catatan']) ?></p>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Review (Dosen) -->
<?php if ($_SESSION['role'] === 'dosen'): ?>
<div id="reviewModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-xl font-bold mb-4">Review File</h3>
        <form method="POST" id="reviewForm">
            <input type="hidden" name="action" value="review">
            <input type="hidden" name="file_id" id="review_file_id">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Status</label>
                <select name="status" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="menunggu">Menunggu</option>
                    <option value="revisi">Revisi</option>
                    <option value="approved">Approved</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Catatan</label>
                <textarea name="catatan" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeReviewModal()" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </button>
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function reviewFile(fileId) {
    document.getElementById('review_file_id').value = fileId;
    document.getElementById('reviewModal').classList.remove('hidden');
}

function closeReviewModal() {
    document.getElementById('reviewModal').classList.add('hidden');
}
</script>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>



