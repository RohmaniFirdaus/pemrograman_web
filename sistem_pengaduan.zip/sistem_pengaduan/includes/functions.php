<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}

function hasRole($role) {
    return isLoggedIn() && $_SESSION['user_role'] === $role;
}

function hasAnyRole($roles) {
    if (!isLoggedIn()) return false;
    return in_array($_SESSION['user_role'], $roles);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}

function requireAnyRole($roles) {
    requireLogin();
    if (!hasAnyRole($roles)) {
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}

function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function sanitizeDB($data) {
    return getDBConnection()->quote($data);
}

function setFlashMessage($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlashMessage() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function formatTanggal($date, $includeTime = false) {
    if (empty($date)) return '-';
    
    $timestamp = is_numeric($date) ? $date : strtotime($date);
    $hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $bulan = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
              'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    $format = $hari[date('w', $timestamp)] . ', ' . 
              date('d', $timestamp) . ' ' . 
              $bulan[date('n', $timestamp)] . ' ' . 
              date('Y', $timestamp);
    
    if ($includeTime) {
        $format .= ' ' . date('H:i', $timestamp);
    }
    
    return $format;
}

function formatRupiah($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}

function uploadFile($file, $subfolder = '', $allowedTypes = null) {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Error uploading file'];
    }

    if ($file['size'] > UPLOAD_MAX_SIZE) {
        return ['success' => false, 'message' => 'File size exceeds maximum limit'];
    }

    $fileType = $file['type'];
    if ($allowedTypes && !in_array($fileType, $allowedTypes)) {
        return ['success' => false, 'message' => 'File type not allowed'];
    }

    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $uploadPath = UPLOAD_DIR . ($subfolder ? $subfolder . '/' : '');
    
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }

    $fullPath = $uploadPath . $filename;

    if (move_uploaded_file($file['tmp_name'], $fullPath)) {
        $relativePath = ($subfolder ? $subfolder . '/' : '') . $filename;
        return ['success' => true, 'path' => $relativePath, 'filename' => $filename];
    }

    return ['success' => false, 'message' => 'Failed to move uploaded file'];
}

function deleteFile($filepath) {
    $fullPath = UPLOAD_DIR . $filepath;
    if (file_exists($fullPath)) {
        return unlink($fullPath);
    }
    return false;
}

function getStatusBadge($status, $type = 'default') {
    $badges = [
        'pengaduan' => [
            'menunggu' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800">Menunggu</span>',
            'diproses' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Diproses</span>',
            'selesai' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Selesai</span>',
            'ditolak' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">Ditolak</span>',
        ],
        'surat' => [
            'menunggu' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800">Menunggu</span>',
            'diproses' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Diproses</span>',
            'selesai' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Selesai</span>',
            'ditolak' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">Ditolak</span>',
        ],
        'verifikasi' => [
            'menunggu' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800">Menunggu</span>',
            'terverifikasi' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Terverifikasi</span>',
            'ditolak' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">Ditolak</span>',
        ],
        'default' => [
            'aktif' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Aktif</span>',
            'nonaktif' => '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800">Nonaktif</span>',
        ]
    ];

    $badgeSet = $badges[$type] ?? $badges['default'];
    return $badgeSet[$status] ?? '<span class="px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800">' . ucfirst($status) . '</span>';
}

function generatePagination($currentPage, $totalPages, $baseUrl) {
    if ($totalPages <= 1) return '';

    $html = '<div class="flex justify-center items-center space-x-2 mt-4">';
    
    if ($currentPage > 1) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($currentPage - 1) . '" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Sebelumnya</a>';
    }
    
    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == $currentPage) {
            $html .= '<span class="px-4 py-2 bg-blue-700 text-white rounded">' . $i . '</span>';
        } else {
            $html .= '<a href="' . $baseUrl . '?page=' . $i . '" class="px-4 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200">' . $i . '</a>';
        }
    }
    
    if ($currentPage < $totalPages) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($currentPage + 1) . '" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Selanjutnya</a>';
    }
    
    $html .= '</div>';
    return $html;
}

function calculateStatistics($bulan, $tahun) {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("SELECT * FROM laporan_statistik WHERE periode_bulan = ? AND periode_tahun = ?");
    $stmt->execute([$bulan, $tahun]);
    $stats = $stmt->fetch();
    
    if (!$stats) {
        $stmt = $pdo->prepare("INSERT INTO laporan_statistik (periode_bulan, periode_tahun) VALUES (?, ?)");
        $stmt->execute([$bulan, $tahun]);
        $stats = ['periode_bulan' => $bulan, 'periode_tahun' => $tahun];
    }
    
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'menunggu' THEN 1 ELSE 0 END) as menunggu,
            SUM(CASE WHEN status = 'diproses' THEN 1 ELSE 0 END) as diproses,
            SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as selesai,
            SUM(CASE WHEN status = 'ditolak' THEN 1 ELSE 0 END) as ditolak
        FROM pengaduan 
        WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?
    ");
    $stmt->execute([$bulan, $tahun]);
    $pengaduan = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'menunggu' THEN 1 ELSE 0 END) as menunggu,
            SUM(CASE WHEN status = 'diproses' THEN 1 ELSE 0 END) as diproses,
            SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as selesai,
            SUM(CASE WHEN status = 'ditolak' THEN 1 ELSE 0 END) as ditolak
        FROM surat_menyurat 
        WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?
    ");
    $stmt->execute([$bulan, $tahun]);
    $surat = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status_verifikasi = 'terverifikasi' THEN 1 ELSE 0 END) as terverifikasi
        FROM umkm 
        WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?
    ");
    $stmt->execute([$bulan, $tahun]);
    $umkm = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM berita 
        WHERE MONTH(created_at) = ? AND YEAR(created_at) = ? AND status = 'dipublikasi'
    ");
    $stmt->execute([$bulan, $tahun]);
    $berita = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM users 
        WHERE role = 'warga' AND MONTH(created_at) = ? AND YEAR(created_at) = ?
    ");
    $stmt->execute([$bulan, $tahun]);
    $warga = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        UPDATE laporan_statistik SET
            total_pengaduan = ?,
            pengaduan_menunggu = ?,
            pengaduan_diproses = ?,
            pengaduan_selesai = ?,
            pengaduan_ditolak = ?,
            total_surat = ?,
            surat_menunggu = ?,
            surat_diproses = ?,
            surat_selesai = ?,
            surat_ditolak = ?,
            total_umkm = ?,
            umkm_terverifikasi = ?,
            total_berita = ?,
            total_warga = ?,
            updated_at = NOW()
        WHERE periode_bulan = ? AND periode_tahun = ?
    ");
    $stmt->execute([
        $pengaduan['total'] ?? 0,
        $pengaduan['menunggu'] ?? 0,
        $pengaduan['diproses'] ?? 0,
        $pengaduan['selesai'] ?? 0,
        $pengaduan['ditolak'] ?? 0,
        $surat['total'] ?? 0,
        $surat['menunggu'] ?? 0,
        $surat['diproses'] ?? 0,
        $surat['selesai'] ?? 0,
        $surat['ditolak'] ?? 0,
        $umkm['total'] ?? 0,
        $umkm['terverifikasi'] ?? 0,
        $berita['total'] ?? 0,
        $warga['total'] ?? 0,
        $bulan,
        $tahun
    ]);
    
    return [
        'pengaduan' => $pengaduan,
        'surat' => $surat,
        'umkm' => $umkm,
        'berita' => $berita,
        'warga' => $warga
    ];
}

