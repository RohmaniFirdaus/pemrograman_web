<?php
require_once 'includes/auth.php';

require_login('user_login.php');

$pdo = getConnection();
$page_title = 'Surat Online Warga';
$message = '';
$message_type = '';

$jenis_surat = [];
$form = [
    'id_jenis_surat' => '',
    'keperluan' => '',
    'data_surat' => ''
];

if ($pdo) {
    try {
        $jenis_stmt = $pdo->query("SELECT id, nama_surat, persyaratan, kode_surat FROM jenis_surat WHERE is_active = 1 ORDER BY nama_surat ASC");
        $jenis_surat = $jenis_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log('Jenis surat error: ' . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'cancel' && isset($_POST['surat_id'])) {
        try {
            $stmt = $pdo->prepare("UPDATE surat_online SET status = 'ditolak', catatan_admin = 'Dibatalkan oleh pemohon', tanggal_selesai = CURDATE() WHERE id = :id AND id_user = :user AND status IN ('menunggu','diproses')");
            $stmt->execute([
                'id' => $_POST['surat_id'],
                'user' => $_SESSION['user_id']
            ]);
            $message = 'Permohonan surat dibatalkan.';
            $message_type = 'success';
        } catch (PDOException $e) {
            error_log('Cancel surat error: ' . $e->getMessage());
            $message = 'Gagal membatalkan surat.';
            $message_type = 'danger';
        }
    } else {
        $form['id_jenis_surat'] = $_POST['id_jenis_surat'] ?? '';
        $form['keperluan'] = trim($_POST['keperluan'] ?? '');
        $form['data_surat'] = trim($_POST['data_surat'] ?? '');

        if (empty($form['id_jenis_surat']) || empty($form['keperluan'])) {
            $message = 'Jenis surat dan keperluan wajib diisi.';
            $message_type = 'danger';
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO surat_online (id_user, id_jenis_surat, nomor_surat, keperluan, data_surat, status, tanggal_pengajuan)
                    VALUES (:user, :jenis, NULL, :keperluan, :data, 'menunggu', :tanggal)
                ");
                $stmt->execute([
                    'user' => $_SESSION['user_id'],
                    'jenis' => $form['id_jenis_surat'],
                    'keperluan' => $form['keperluan'],
                    'data' => $form['data_surat'] ? json_encode(['keterangan' => $form['data_surat']]) : null,
                    'tanggal' => date('Y-m-d')
                ]);
                $message = 'Permohonan surat berhasil dikirim.';
                $message_type = 'success';
                $form = ['id_jenis_surat' => '', 'keperluan' => '', 'data_surat' => ''];
            } catch (PDOException $e) {
                error_log('Create surat error: ' . $e->getMessage());
                $message = 'Terjadi kesalahan saat menyimpan permohonan surat.';
                $message_type = 'danger';
            }
        }
    }
}

$formatTanggal = function ($tanggal) {
    return $tanggal ? date('d M Y', strtotime($tanggal)) : '-';
};

$surat_list = [];
if ($pdo) {
    try {
        $stmt = $pdo->prepare("
            SELECT s.*, js.nama_surat
            FROM surat_online s
            LEFT JOIN jenis_surat js ON js.id = s.id_jenis_surat
            WHERE s.id_user = :user
            ORDER BY s.created_at DESC
        ");
        $stmt->execute(['user' => $_SESSION['user_id']]);
        $surat_list = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('List surat error: ' . $e->getMessage());
    }
}

$extra_styles = <<<CSS
.surat-container {
    max-width: 1400px;
    margin: 0 auto;
}

.surat-form-section {
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.surat-form-section h3 {
    color: var(--primary-color);
    font-size: 1.75rem;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.surat-form-section h3 i {
    color: var(--accent-color);
}

.surat-list-section {
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
}

.surat-list-section h3 {
    color: var(--primary-color);
    font-size: 1.75rem;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.surat-list-section h3 i {
    color: var(--accent-color);
}

.surat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.surat-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.surat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.surat-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
    gap: 10px;
}

.surat-card-title {
    font-weight: 700;
    font-size: 1.1rem;
    color: var(--primary-color);
    flex: 1;
}

.surat-card-body {
    margin-bottom: 15px;
}

.surat-card-keperluan {
    color: #666;
    font-size: 0.95rem;
    line-height: 1.6;
    margin-bottom: 12px;
}

.surat-card-meta {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 15px;
}

.surat-card-meta small {
    color: #888;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 6px;
}

.surat-card-meta i {
    color: var(--info-color);
    width: 16px;
}

.surat-card-actions {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid var(--border-color);
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state i {
    font-size: 4rem;
    color: var(--border-color);
    margin-bottom: 20px;
}

.empty-state p {
    font-size: 1.1rem;
    margin: 0;
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    color: #555;
    margin-bottom: 8px;
}

.form-group label i {
    color: var(--primary-color);
    font-size: 0.9rem;
}

.form-group input[type="text"],
.form-group select,
.form-group textarea {
    border: 2px solid var(--border-color);
    transition: all 0.3s ease;
}

.form-group input[type="text"]:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 0.2rem rgba(27, 94, 32, 0.15);
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    border: none;
    padding: 14px 28px;
    font-weight: 600;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(27, 94, 32, 0.3);
}

.btn-outline-danger {
    border: 2px solid var(--danger-color);
    color: var(--danger-color);
    background: transparent;
    transition: all 0.3s ease;
}

.btn-outline-danger:hover {
    background: var(--danger-color);
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    .surat-grid {
        grid-template-columns: 1fr;
    }
    
    .surat-form-section,
    .surat-list-section {
        padding: 20px;
    }
    
    .surat-card {
        padding: 20px;
    }
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4 surat-container">
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>" style="margin-bottom: 25px;">
            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo esc($message); ?>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-5 mb-4">
            <div class="surat-form-section">
                <h3>
                    <i class="fas fa-file-alt"></i>
                    Ajukan Surat Online
                </h3>
                <form action="surat_online.php" method="POST">
                    <div class="form-group mb-3">
                        <label for="id_jenis_surat">
                            <i class="fas fa-list"></i>
                            Jenis Surat
                        </label>
                        <select id="id_jenis_surat" name="id_jenis_surat" class="form-control" required>
                            <option value="">-- Pilih Jenis Surat --</option>
                            <?php 
                            $current_group = '';
                            foreach ($jenis_surat as $js): 
                                // Group berdasarkan prefix kode
                                $group = '';
                                if (strpos($js['kode_surat'] ?? '', 'SK-') === 0) {
                                    $group = 'SURAT KETERANGAN';
                                } elseif (strpos($js['kode_surat'] ?? '', 'SP-') === 0) {
                                    $group = 'SURAT PENGANTAR';
                                } elseif (strpos($js['kode_surat'] ?? '', 'SI-') === 0) {
                                    $group = 'SURAT IZIN';
                                } elseif (strpos($js['kode_surat'] ?? '', 'SR-') === 0) {
                                    $group = 'SURAT REKOMENDASI';
                                }
                                
                                if ($group && $group !== $current_group):
                                    $current_group = $group;
                            ?>
                                    <optgroup label="<?php echo esc($group); ?>">
                            <?php endif; ?>
                                <option value="<?php echo esc($js['id']); ?>" <?php echo ($form['id_jenis_surat'] == $js['id'] ? 'selected' : ''); ?> data-persyaratan="<?php echo esc($js['persyaratan'] ?? ''); ?>">
                                    <?php echo esc($js['nama_surat']); ?>
                                </option>
                            <?php 
                                if ($group && $group !== $current_group):
                            ?>
                                    </optgroup>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </select>
                        <div id="surat-persyaratan" class="form-help-text" style="display: none; margin-top: 10px; padding: 12px; background: #f0f7ff; border-left: 3px solid var(--primary-color); border-radius: 5px;">
                            <strong style="color: var(--primary-color); display: block; margin-bottom: 8px;">
                                <i class="fas fa-clipboard-list"></i> Persyaratan:
                            </strong>
                            <span id="surat-persyaratan-text" style="color: #555; line-height: 1.7;"></span>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="keperluan">
                            <i class="fas fa-info-circle"></i>
                            Keperluan
                        </label>
                        <textarea id="keperluan" name="keperluan" class="form-control" rows="4" required placeholder="Jelaskan keperluan surat yang Anda butuhkan..."><?php echo esc($form['keperluan']); ?></textarea>
                    </div>
                    <div class="form-group mb-4">
                        <label for="data_surat">
                            <i class="fas fa-edit"></i>
                            Detail Data Tambahan
                        </label>
                        <textarea id="data_surat" name="data_surat" class="form-control" rows="4" placeholder="Contoh: Nama orang tua, alamat tujuan, atau informasi tambahan lainnya"><?php echo esc($form['data_surat']); ?></textarea>
                        <small class="text-muted" style="display: block; margin-top: 5px;">
                            <i class="fas fa-lightbulb"></i> Opsional: Isi jika diperlukan informasi tambahan
                        </small>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane"></i>
                        Kirim Permohonan
                    </button>
                </form>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="surat-list-section">
                <h3>
                    <i class="fas fa-history"></i>
                    Riwayat Permohonan Surat
                </h3>
                <?php if (empty($surat_list)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>Belum ada permohonan surat.</p>
                        <p style="font-size: 0.9rem; margin-top: 10px;">Mulai dengan mengajukan permohonan surat di form sebelah kiri.</p>
                    </div>
                <?php else: ?>
                    <div class="surat-grid">
                        <?php foreach ($surat_list as $surat): ?>
                            <div class="surat-card">
                                <div class="surat-card-header">
                                    <div class="surat-card-title"><?php echo esc($surat['nama_surat']); ?></div>
                                    <span class="status-badge status-<?php echo esc(strtolower($surat['status'])); ?>">
                                        <?php echo esc(ucfirst($surat['status'])); ?>
                                    </span>
                                </div>
                                <div class="surat-card-body">
                                    <div class="surat-card-keperluan">
                                        <strong><i class="fas fa-quote-left"></i> Keperluan:</strong><br>
                                        <?php echo esc($surat['keperluan']); ?>
                                    </div>
                                </div>
                                <div class="surat-card-meta">
                                    <small>
                                        <i class="fas fa-calendar-alt"></i>
                                        <strong>Pengajuan:</strong> <?php echo $formatTanggal($surat['tanggal_pengajuan']); ?>
                                    </small>
                                    <?php if ($surat['tanggal_selesai']): ?>
                                        <small>
                                            <i class="fas fa-check-circle"></i>
                                            <strong>Selesai:</strong> <?php echo $formatTanggal($surat['tanggal_selesai']); ?>
                                        </small>
                                    <?php endif; ?>
                                    <?php if ($surat['nomor_surat']): ?>
                                        <small>
                                            <i class="fas fa-hashtag"></i>
                                            <strong>No. Surat:</strong> <?php echo esc($surat['nomor_surat']); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                                <?php if (in_array($surat['status'], ['menunggu','diproses'])): ?>
                                    <div class="surat-card-actions">
                                        <form action="surat_online.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin membatalkan permohonan surat ini?');">
                                            <input type="hidden" name="action" value="cancel">
                                            <input type="hidden" name="surat_id" value="<?php echo esc($surat['id']); ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm w-100">
                                                <i class="fas fa-times-circle"></i>
                                                Batalkan Permohonan
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Tampilkan persyaratan surat saat dipilih
document.addEventListener('DOMContentLoaded', function() {
    const jenisSuratSelect = document.getElementById('id_jenis_surat');
    if (jenisSuratSelect) {
        jenisSuratSelect.addEventListener('change', function(e) {
            const selectedOption = e.target.options[e.target.selectedIndex];
            const persyaratan = selectedOption.getAttribute('data-persyaratan');
            const persyaratanDiv = document.getElementById('surat-persyaratan');
            const persyaratanText = document.getElementById('surat-persyaratan-text');
            
            if (persyaratan && persyaratan.trim() !== '') {
                // Format persyaratan dengan line break
                const items = persyaratan.split(',').map(item => item.trim()).filter(item => item);
                persyaratanText.innerHTML = items.map(item => '• ' + item).join('<br>');
                persyaratanDiv.style.display = 'block';
            } else {
                persyaratanDiv.style.display = 'none';
            }
        });
        
        // Trigger change jika sudah ada nilai yang dipilih
        if (jenisSuratSelect.value) {
            jenisSuratSelect.dispatchEvent(new Event('change'));
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>

