<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    $user_id = intval($_POST['user_id']);
    $action = sanitize($_POST['action']); 
    
    $stmt = $pdo->prepare("UPDATE users SET status_verifikasi = ? WHERE id = ?");
    if ($stmt->execute([$action, $user_id])) {
        setFlashMessage('success', 'Status verifikasi berhasil diperbarui');
    } else {
        setFlashMessage('error', 'Gagal memperbarui status verifikasi');
    }
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$stmt = $pdo->query("
    SELECT * FROM users 
    WHERE role = 'warga' AND status_verifikasi = 'menunggu' 
    ORDER BY created_at DESC
");
$pending_users = $stmt->fetchAll();

$pageTitle = 'Validasi Pengguna - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">
        <i class="fas fa-user-check mr-2"></i>Validasi Pengguna
    </h1>
    <p class="text-gray-600 mb-6">Verifikasi akun warga yang menunggu validasi</p>

    <?php if (empty($pending_users)): ?>
        <div class="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 rounded">
            <div class="flex">
                <i class="fas fa-info-circle mr-2"></i>
                <p>Tidak ada pengguna yang menunggu validasi.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="px-6 py-3 text-left text-sm font-semibold">NIK</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Nama</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Email</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Foto KTP</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Tanggal</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($pending_users as $user): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4"><?php echo htmlspecialchars($user['nik']); ?></td>
                                <td class="px-6 py-4">
                                    <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($user['nama_lengkap']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($user['username']); ?></div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo htmlspecialchars($user['email']); ?></td>
                                <td class="px-6 py-4">
                                    <?php if ($user['foto_ktp']): ?>
                                        <img src="<?php echo upload_url($user['foto_ktp']); ?>" alt="KTP" class="w-20 h-20 object-cover rounded cursor-pointer" onclick="window.open('<?php echo upload_url($user['foto_ktp']); ?>', '_blank')">
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo formatTanggal($user['created_at']); ?></td>
                                <td class="px-6 py-4">
                                    <div class="flex space-x-2">
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="terverifikasi">
                                            <button type="submit" name="verify" value="1" 
                                                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">
                                                <i class="fas fa-check mr-1"></i>Terima
                                            </button>
                                        </form>
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="ditolak">
                                            <button type="submit" name="verify" value="1" 
                                                class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded text-sm">
                                                <i class="fas fa-times mr-1"></i>Tolak
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

