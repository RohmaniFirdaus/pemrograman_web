<?php
require_once '../config/config.php';
requireRole(['admin']);

$pageTitle = 'Dashboard Admin';
$currentModule = 'dashboard';

$conn = getDBConnection();

$total_mahasiswa = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'active'")->fetch_assoc()['total'];
$total_dosen = $conn->query("SELECT COUNT(*) as total FROM dosen WHERE status = 'active'")->fetch_assoc()['total'];
$total_mk = $conn->query("SELECT COUNT(*) as total FROM mata_kuliah WHERE status = 'active'")->fetch_assoc()['total'];
$krs_pending = $conn->query("SELECT COUNT(*) as total FROM krs WHERE status = 'menunggu_approval'")->fetch_assoc()['total'];
$pengaduan_terbaru = $conn->query("SELECT * FROM pengaduan WHERE status IN ('menunggu', 'diproses') ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$krs_menunggu = $conn->query("SELECT k.*, m.nim, m.nama_mahasiswa FROM krs k JOIN mahasiswa m ON k.mahasiswa_id = m.id WHERE k.status = 'menunggu_approval' ORDER BY k.created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Dashboard Admin</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Mahasiswa</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_mahasiswa ?></p>
                </div>
                <div class="bg-green-100 p-4 rounded-full">
                    <i class="fas fa-users text-green-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Dosen</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_dosen ?></p>
                </div>
                <div class="bg-blue-100 p-4 rounded-full">
                    <i class="fas fa-chalkboard-teacher text-blue-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Mata Kuliah</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_mk ?></p>
                </div>
                <div class="bg-purple-100 p-4 rounded-full">
                    <i class="fas fa-book text-purple-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">KRS Pending</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $krs_pending ?></p>
                </div>
                <div class="bg-yellow-100 p-4 rounded-full">
                    <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Quick Actions</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <a href="<?= BASE_URL ?>data-akademik/mahasiswa/tambah.php" class="bg-green-600 text-white p-4 rounded-lg hover:bg-green-700 transition text-center">
                <i class="fas fa-user-plus text-2xl mb-2"></i>
                <p class="font-semibold">Tambah Mahasiswa</p>
            </a>
            <a href="<?= BASE_URL ?>laporan/index.php" class="bg-blue-600 text-white p-4 rounded-lg hover:bg-blue-700 transition text-center">
                <i class="fas fa-file-alt text-2xl mb-2"></i>
                <p class="font-semibold">Generate Laporan</p>
            </a>
            <a href="<?= BASE_URL ?>data-akademik/index.php" class="bg-purple-600 text-white p-4 rounded-lg hover:bg-purple-700 transition text-center">
                <i class="fas fa-database text-2xl mb-2"></i>
                <p class="font-semibold">Data</p>
            </a>
            <a href="<?= BASE_URL ?>pengumuman/index.php" class="bg-orange-600 text-white p-4 rounded-lg hover:bg-orange-700 transition text-center">
                <i class="fas fa-bullhorn text-2xl mb-2"></i>
                <p class="font-semibold">Broadcast Pengumuman</p>
            </a>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Pengaduan Terbaru (Last 7 Days)</h2>
            <a href="<?= BASE_URL ?>pengaduan/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="space-y-3">
            <?php if (empty($pengaduan_terbaru)): ?>
                <p class="text-gray-500 text-center py-4">Tidak ada pengaduan terbaru</p>
            <?php else: ?>
                <?php foreach ($pengaduan_terbaru as $p): ?>
                <div class="border-l-4 border-yellow-500 pl-4 py-2">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold text-gray-800"><?= htmlspecialchars($p['judul_pengaduan']) ?></p>
                            <p class="text-sm text-gray-600"><?= htmlspecialchars($p['kategori']) ?> - <?= formatTanggal($p['created_at']) ?></p>
                        </div>
                        <?= getStatusBadge($p['status']) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">KRS Menunggu Verifikasi Admin</h2>
            <a href="<?= BASE_URL ?>krs/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($krs_menunggu)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Tidak ada KRS yang menunggu verifikasi</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_menunggu as $k): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($k['nim']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($k['nama_mahasiswa']) ?></td>
                            <td class="px-4 py-2"><?= $k['semester'] ?></td>
                            <td class="px-4 py-2"><?= $k['sks_diambil'] ?></td>
                            <td class="px-4 py-2">
                                <a href="<?= BASE_URL ?>krs/detail.php?id=<?= $k['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-eye"></i> Detail
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



