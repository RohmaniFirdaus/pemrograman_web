<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Statistik Kinerja Dosen';
$currentModule = 'laporan';

$conn = getDBConnection();

// Get top 5 dosen by jumlah mahasiswa bimbingan
$top_dosen_bimbingan = $conn->query("
    SELECT d.*, 
           COUNT(DISTINCT ta.id) as jumlah_bimbingan,
           COUNT(DISTINCT CASE WHEN ta.status = 'active' THEN ta.id END) as bimbingan_aktif
    FROM dosen d
    LEFT JOIN tugas_akhir ta ON (d.id = ta.dosen_pembimbing1_id OR d.id = ta.dosen_pembimbing2_id)
    WHERE d.status = 'active'
    GROUP BY d.id
    ORDER BY jumlah_bimbingan DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

// Get top 5 dosen by jumlah mata kuliah
$top_dosen_mk = $conn->query("
    SELECT d.*, COUNT(DISTINCT j.mk_id) as jumlah_mk
    FROM dosen d
    LEFT JOIN jadwal_kuliah j ON d.id = j.dosen_id
    WHERE d.status = 'active'
    GROUP BY d.id
    ORDER BY jumlah_mk DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

// Get statistik umum
$total_dosen = $conn->query("SELECT COUNT(*) as total FROM dosen WHERE status = 'active'")->fetch_assoc()['total'];
$total_bimbingan = $conn->query("SELECT COUNT(*) as total FROM tugas_akhir WHERE status = 'active'")->fetch_assoc()['total'];
$total_mk = $conn->query("SELECT COUNT(DISTINCT dosen_id) as total FROM jadwal_kuliah")->fetch_assoc()['total'];

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Statistik Kinerja Dosen</h1>
        <a href="export.php?type=dosen" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
    </div>
    
    <!-- Statistik Umum -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Dosen Aktif</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_dosen ?></p>
                </div>
                <div class="bg-blue-100 p-4 rounded-full">
                    <i class="fas fa-chalkboard-teacher text-blue-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Bimbingan</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_bimbingan ?></p>
                </div>
                <div class="bg-green-100 p-4 rounded-full">
                    <i class="fas fa-book text-green-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Dosen Mengajar</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_mk ?></p>
                </div>
                <div class="bg-purple-100 p-4 rounded-full">
                    <i class="fas fa-graduation-cap text-purple-600 text-2xl"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Top 5 Dosen Bimbingan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Top 5 Dosen - Jumlah Bimbingan</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">NIP</th>
                        <th class="px-4 py-2 text-left">Nama Dosen</th>
                        <th class="px-4 py-2 text-left">Jumlah Bimbingan</th>
                        <th class="px-4 py-2 text-left">Bimbingan Aktif</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_dosen_bimbingan as $index => $d): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $index + 1 ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nip']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_dosen']) ?></td>
                        <td class="px-4 py-2"><?= $d['jumlah_bimbingan'] ?></td>
                        <td class="px-4 py-2"><?= $d['bimbingan_aktif'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Top 5 Dosen Mata Kuliah -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Top 5 Dosen - Jumlah Mata Kuliah</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">NIP</th>
                        <th class="px-4 py-2 text-left">Nama Dosen</th>
                        <th class="px-4 py-2 text-left">Jumlah Mata Kuliah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_dosen_mk as $index => $d): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $index + 1 ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nip']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_dosen']) ?></td>
                        <td class="px-4 py-2"><?= $d['jumlah_mk'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



