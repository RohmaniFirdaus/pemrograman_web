<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

$stmt = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM pengaduan) as total_pengaduan,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'menunggu') as menunggu,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'diproses') as diproses,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'selesai') as selesai,
        (SELECT COUNT(*) FROM surat_menyurat WHERE status = 'diproses') as surat_diproses,
        (SELECT COUNT(*) FROM umkm WHERE status_verifikasi = 'terverifikasi') as umkm_terverifikasi,
        (SELECT COUNT(*) FROM berita WHERE status = 'dipublikasi') as berita_dipublikasi,
        (SELECT COUNT(*) FROM users WHERE role = 'warga' AND status_aktif = 'aktif') as pengguna_aktif
");
$stats = $stmt->fetch();

$stmt = $pdo->query("
    SELECT p.*, u.nama_lengkap 
    FROM pengaduan p 
    LEFT JOIN users u ON p.user_id = u.id 
    WHERE p.status = 'menunggu' 
    ORDER BY p.created_at DESC 
    LIMIT 5
");
$pending_pengaduan = $stmt->fetchAll();

$stmt = $pdo->query("
    SELECT s.*, u.nama_lengkap 
    FROM surat_menyurat s 
    LEFT JOIN users u ON s.user_id = u.id 
    WHERE s.status = 'menunggu' 
    ORDER BY s.created_at DESC 
    LIMIT 5
");
$pending_surat = $stmt->fetchAll();

$pageTitle = 'Dashboard Sistem Desa - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">Dashboard Sistem Desa</h1>
    <p class="text-gray-600 mb-8">Monitoring pengaduan, surat, UMKM, dan berita desa</p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Total Pengaduan</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_pengaduan'] ?? 0; ?></p>
                </div>
                <i class="fas fa-file-alt text-4xl text-blue-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Menunggu</p>
                    <p class="text-3xl font-bold text-yellow-600"><?php echo $stats['menunggu'] ?? 0; ?></p>
                </div>
                <i class="fas fa-clock text-4xl text-yellow-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Diproses</p>
                    <p class="text-3xl font-bold text-blue-600"><?php echo $stats['diproses'] ?? 0; ?></p>
                </div>
                <i class="fas fa-spinner text-4xl text-blue-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Selesai</p>
                    <p class="text-3xl font-bold text-blue-600"><?php echo $stats['selesai'] ?? 0; ?></p>
                </div>
                <i class="fas fa-check-circle text-4xl text-blue-600"></i>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Surat Diproses</p>
                    <p class="text-3xl font-bold text-purple-600"><?php echo $stats['surat_diproses'] ?? 0; ?></p>
                </div>
                <i class="fas fa-envelope text-4xl text-purple-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">UMKM Terverifikasi</p>
                    <p class="text-3xl font-bold text-orange-600"><?php echo $stats['umkm_terverifikasi'] ?? 0; ?></p>
                </div>
                <i class="fas fa-shopping-bag text-4xl text-orange-600"></i>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm mb-1">Berita Dipublikasi</p>
                    <p class="text-3xl font-bold text-red-600"><?php echo $stats['berita_dipublikasi'] ?? 0; ?></p>
                </div>
                <i class="fas fa-newspaper text-4xl text-red-600"></i>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-gray-800">Pengaduan Menunggu</h2>
                <a href="<?php echo BASE_URL; ?>admin/pengaduan.php" class="text-blue-600 hover:text-blue-700 text-sm font-semibold">Lihat Semua</a>
            </div>
            
            <?php if (empty($pending_pengaduan)): ?>
                <p class="text-gray-500 text-center py-8">Tidak ada pengaduan menunggu.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($pending_pengaduan as $pengaduan): ?>
                        <div class="border-l-4 border-yellow-500 pl-4 py-2">
                            <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($pengaduan['judul']); ?></h3>
                            <p class="text-sm text-gray-600">Oleh: <?php echo htmlspecialchars($pengaduan['nama_lengkap']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo formatTanggal($pengaduan['created_at']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-gray-800">Surat Online Diproses</h2>
                <a href="<?php echo BASE_URL; ?>admin/surat.php" class="text-blue-600 hover:text-blue-700 text-sm font-semibold">Kelola Surat</a>
            </div>
            
            <?php if (empty($pending_surat)): ?>
                <p class="text-gray-500 text-center py-8">Tidak ada surat menunggu.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($pending_surat as $surat): ?>
                        <div class="border-l-4 border-blue-500 pl-4 py-2">
                            <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($surat['jenis_surat']); ?></h3>
                            <p class="text-sm text-gray-600">Oleh: <?php echo htmlspecialchars($surat['nama_lengkap']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo formatTanggal($surat['created_at']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

