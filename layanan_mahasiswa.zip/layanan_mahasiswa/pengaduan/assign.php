<?php
require_once '../config/config.php';
requireRole(['admin']);

$pageTitle = 'Assign Pengaduan';
$currentModule = 'pengaduan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();

$pengaduan = $conn->query("
    SELECT p.*, m.nim, m.nama_mahasiswa 
    FROM pengaduan p 
    JOIN mahasiswa m ON p.mahasiswa_id = m.id 
    WHERE p.id = $id
")->fetch_assoc();

if (!$pengaduan) {
    header('Location: index.php');
    exit;
}

// Get users untuk assign
$users = $conn->query("
    SELECT u.id, u.username, u.role, 
           COALESCE(d.nama_dosen, m.nama_mahasiswa, p.nama_pimpinan) as nama
    FROM users u
    LEFT JOIN dosen d ON u.id = d.user_id
    LEFT JOIN mahasiswa m ON u.id = m.user_id
    LEFT JOIN pimpinan p ON u.id = p.user_id
    WHERE u.role IN ('admin', 'dosen', 'pimpinan') AND u.status = 'active'
    ORDER BY u.role, nama
")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $assigned_to = intval($_POST['assigned_to'] ?? 0);
    $status = $_POST['status'] ?? 'diproses';
    $komentar = sanitize($_POST['komentar'] ?? '');
    
    if ($assigned_to) {
        $stmt = $conn->prepare("UPDATE pengaduan SET assigned_to = ?, status = ? WHERE id = ?");
        $stmt->bind_param("isi", $assigned_to, $status, $id);
        if ($stmt->execute()) {
            $user = getCurrentUser();
            $conn->query("INSERT INTO timeline_pengaduan (pengaduan_id, user_id, status, komentar) VALUES ($id, " . $user['id'] . ", '$status', '" . $conn->real_escape_string($komentar ?: 'Pengaduan diassign ke unit') . "')");
            $success = 'Pengaduan berhasil diassign';
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Assign Pengaduan</h1>
        <a href="detail.php?id=<?= $id ?>" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Pengaduan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4"><?= htmlspecialchars($pengaduan['judul_pengaduan']) ?></h2>
        <p class="text-gray-600"><?= htmlspecialchars($pengaduan['nim']) ?> - <?= htmlspecialchars($pengaduan['nama_mahasiswa']) ?></p>
    </div>
    
    <!-- Form Assign -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Assign ke Unit</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Assign To *</label>
                <select name="assigned_to" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih User/Unit</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= $u['id'] ?>">
                            <?= ucfirst($u['role']) ?> - <?= htmlspecialchars($u['nama']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Status</label>
                <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="diproses">Diproses</option>
                    <option value="menunggu">Menunggu</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Komentar</label>
                <textarea name="komentar" rows="3" 
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            
            <div class="flex justify-end space-x-4">
                <a href="detail.php?id=<?= $id ?>" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-check mr-2"></i>Assign
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



