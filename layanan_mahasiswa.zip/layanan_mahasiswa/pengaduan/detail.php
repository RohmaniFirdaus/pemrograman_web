<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa']);

$pageTitle = 'Detail Pengaduan';
$currentModule = 'pengaduan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$pengaduan = $conn->query("
    SELECT p.*, m.nim, m.nama_mahasiswa 
    FROM pengaduan p 
    JOIN mahasiswa m ON p.mahasiswa_id = m.id 
    WHERE p.id = $id
")->fetch_assoc();

if (!$pengaduan) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($pengaduan['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get lampiran
$lampiran = $conn->query("SELECT * FROM lampiran_pengaduan WHERE pengaduan_id = $id")->fetch_all(MYSQLI_ASSOC);

// Get timeline
$timeline = $conn->query("
    SELECT t.*, u.username 
    FROM timeline_pengaduan t 
    LEFT JOIN users u ON t.user_id = u.id 
    WHERE t.pengaduan_id = $id 
    ORDER BY t.created_at ASC
")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'assign' && $_SESSION['role'] === 'admin') {
        $assigned_to = intval($_POST['assigned_to'] ?? 0);
        $status = $_POST['status'] ?? 'diproses';
        
        $stmt = $conn->prepare("UPDATE pengaduan SET assigned_to = ?, status = ? WHERE id = ?");
        $stmt->bind_param("isi", $assigned_to, $status, $id);
        if ($stmt->execute()) {
            $conn->query("INSERT INTO timeline_pengaduan (pengaduan_id, user_id, status, komentar) VALUES ($id, " . $user['id'] . ", '$status', 'Pengaduan diassign ke unit')");
            $success = 'Pengaduan berhasil diassign';
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    } elseif ($action === 'update_status' && $_SESSION['role'] === 'admin') {
        $status = $_POST['status'] ?? '';
        $komentar = sanitize($_POST['komentar'] ?? '');
        
        $stmt = $conn->prepare("UPDATE pengaduan SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        if ($stmt->execute()) {
            $conn->query("INSERT INTO timeline_pengaduan (pengaduan_id, user_id, status, komentar) VALUES ($id, " . $user['id'] . ", '$status', '" . $conn->real_escape_string($komentar) . "')");
            $success = 'Status berhasil diupdate';
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    } elseif ($action === 'rating' && $_SESSION['role'] === 'mahasiswa' && $pengaduan['status'] === 'selesai') {
        $rating = intval($_POST['rating'] ?? 0);
        $feedback = sanitize($_POST['feedback'] ?? '');
        
        if ($rating >= 1 && $rating <= 5) {
            $stmt = $conn->prepare("UPDATE pengaduan SET rating = ?, feedback = ? WHERE id = ?");
            $stmt->bind_param("isi", $rating, $feedback, $id);
            $stmt->execute();
            $stmt->close();
            $success = 'Rating berhasil disimpan';
            header('Location: detail.php?id=' . $id);
            exit;
        }
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Pengaduan</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info Pengaduan -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">#<?= htmlspecialchars($pengaduan['kode_pengaduan']) ?></h2>
                <p class="text-gray-600"><?= htmlspecialchars($pengaduan['judul_pengaduan']) ?></p>
            </div>
            <div class="text-right">
                <?= getStatusBadge($pengaduan['status']) ?>
                <span class="px-2 py-1 rounded text-xs font-semibold ml-2 <?= 
                    $pengaduan['prioritas'] === 'high' ? 'bg-red-100 text-red-700' : 
                    ($pengaduan['prioritas'] === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700')
                ?>">
                    <?= strtoupper($pengaduan['prioritas']) ?>
                </span>
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <p class="text-gray-600 text-sm">Kategori</p>
                <p class="font-semibold"><?= htmlspecialchars($pengaduan['kategori']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Mahasiswa</p>
                <p class="font-semibold"><?= htmlspecialchars($pengaduan['nim']) ?> - <?= htmlspecialchars($pengaduan['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dibuat</p>
                <p class="font-semibold"><?= formatTanggalWaktu($pengaduan['created_at']) ?></p>
            </div>
            <?php if ($pengaduan['assigned_to']): ?>
            <div>
                <p class="text-gray-600 text-sm">Assigned To</p>
                <p class="font-semibold">Unit terkait</p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Deskripsi</p>
            <p class="text-gray-800 bg-gray-50 p-4 rounded"><?= nl2br(htmlspecialchars($pengaduan['deskripsi'])) ?></p>
        </div>
        
        <?php if ($pengaduan['saran']): ?>
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Saran</p>
            <p class="text-gray-800 bg-blue-50 p-4 rounded"><?= nl2br(htmlspecialchars($pengaduan['saran'])) ?></p>
        </div>
        <?php endif; ?>
        
        <!-- Lampiran -->
        <?php if (!empty($lampiran)): ?>
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Lampiran</p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
                <?php foreach ($lampiran as $l): ?>
                <a href="<?= BASE_URL . htmlspecialchars($l['path_file']) ?>" target="_blank" class="border rounded p-2 hover:bg-gray-50">
                    <i class="fas fa-file mr-1"></i><?= htmlspecialchars($l['nama_file']) ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Timeline -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Timeline</h2>
        <div class="space-y-4">
            <?php foreach ($timeline as $t): ?>
            <div class="border-l-4 border-green-500 pl-4 py-2">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="font-semibold"><?= htmlspecialchars($t['status']) ?></p>
                        <?php if ($t['komentar']): ?>
                        <p class="text-gray-600 text-sm"><?= htmlspecialchars($t['komentar']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="text-right text-sm text-gray-500">
                        <p><?= htmlspecialchars($t['username'] ?? 'System') ?></p>
                        <p><?= formatTanggalWaktu($t['created_at']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Actions -->
    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Actions</h2>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-gray-700 font-semibold mb-2">Update Status</label>
                <div class="flex gap-2">
                    <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="menunggu">Menunggu</option>
                        <option value="diproses">Diproses</option>
                        <option value="selesai">Selesai</option>
                        <option value="escalated">Escalated</option>
                    </select>
                    <input type="text" name="komentar" placeholder="Komentar..." 
                           class="flex-1 px-4 py-2 border border-gray-300 rounded-lg">
                    <button type="submit" name="action" value="update_status" 
                            class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                        Update
                    </button>
                </div>
            </div>
        </form>
    </div>
    <?php elseif ($_SESSION['role'] === 'mahasiswa' && $pengaduan['status'] === 'selesai' && !$pengaduan['rating']): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Rating & Feedback</h2>
        <form method="POST">
            <input type="hidden" name="action" value="rating">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Rating</label>
                <select name="rating" required class="px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih Rating</option>
                    <option value="5">5 - Sangat Baik</option>
                    <option value="4">4 - Baik</option>
                    <option value="3">3 - Cukup</option>
                    <option value="2">2 - Kurang</option>
                    <option value="1">1 - Sangat Kurang</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Feedback</label>
                <textarea name="feedback" rows="3" 
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                Submit Rating
            </button>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



