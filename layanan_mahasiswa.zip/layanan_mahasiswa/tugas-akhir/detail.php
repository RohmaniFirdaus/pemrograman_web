<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Detail Tugas Akhir';
$currentModule = 'tugas-akhir';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$ta = $conn->query("
    SELECT ta.*, m.nim, m.nama_mahasiswa, p.nama_prodi,
           d1.nama_dosen as pembimbing1, d2.nama_dosen as pembimbing2
    FROM tugas_akhir ta
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    LEFT JOIN dosen d1 ON ta.dosen_pembimbing1_id = d1.id
    LEFT JOIN dosen d2 ON ta.dosen_pembimbing2_id = d2.id
    WHERE ta.id = $id
")->fetch_assoc();

if (!$ta) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['dosen_pembimbing1_id'] != $dosen['id'] && $ta['dosen_pembimbing2_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Tugas Akhir</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info TA -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Tugas Akhir</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama Mahasiswa</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['nama_prodi']) ?></p>
            </div>
            <?php endif; ?>
            <div>
                <p class="text-gray-600 text-sm">Judul TA</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['judul_ta']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pembimbing 1</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['pembimbing1'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pembimbing 2</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($ta['pembimbing2'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status Proposal</p>
                <p><?= getStatusBadge($ta['status_proposal']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Progress</p>
                <div class="flex items-center">
                    <div class="flex-1 bg-gray-200 rounded-full h-3 mr-2">
                        <div class="bg-green-600 h-3 rounded-full" style="width: <?= $ta['progress'] ?>%"></div>
                    </div>
                    <span class="text-sm font-semibold"><?= $ta['progress'] ?>%</span>
                </div>
            </div>
            <?php if ($ta['deadline_sidang']): ?>
            <div>
                <p class="text-gray-600 text-sm">Deadline Sidang</p>
                <p class="font-semibold text-gray-800"><?= formatTanggal($ta['deadline_sidang']) ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Quick Links -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="repository.php?id=<?= $id ?>" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-folder-open text-blue-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800">Repository</h3>
            <p class="text-gray-600 text-sm">Lihat file repository</p>
        </a>
        <a href="jadwal-bimbingan.php?id=<?= $id ?>" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-calendar text-purple-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800">Jadwal Bimbingan</h3>
            <p class="text-gray-600 text-sm">Lihat jadwal bimbingan</p>
        </a>
        <a href="log-bimbingan.php?id=<?= $id ?>" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-clipboard-list text-green-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800">Log Bimbingan</h3>
            <p class="text-gray-600 text-sm">Lihat log bimbingan</p>
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



