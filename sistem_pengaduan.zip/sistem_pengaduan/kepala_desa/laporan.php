<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('kepala_desa');

$pdo = getDBConnection();

$bulan = isset($_GET['bulan']) ? intval($_GET['bulan']) : date('n');
$tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');

$prev_bulan = $bulan - 1;
$prev_tahun = $tahun;
if ($prev_bulan < 1) {
    $prev_bulan = 12;
    $prev_tahun--;
}

$stats_sekarang = calculateStatistics($bulan, $tahun);
$stats_sebelumnya = calculateStatistics($prev_bulan, $prev_tahun);

$stmt = $pdo->prepare("SELECT * FROM laporan_statistik WHERE periode_bulan = ? AND periode_tahun = ?");
$stmt->execute([$bulan, $tahun]);
$stat_sekarang = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM laporan_statistik WHERE periode_bulan = ? AND periode_tahun = ?");
$stmt->execute([$prev_bulan, $prev_tahun]);
$stat_sebelumnya = $stmt->fetch();

$pageTitle = 'Laporan - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">Laporan</h1>
    <p class="text-gray-600 mb-8">Laporan per periode dan per kategori</p>

    <div class="bg-white rounded-lg p-6 mb-6 shadow-sm border border-gray-200">
        <form method="GET" class="flex items-center gap-4">
            <select name="bulan" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <?php
                $bulan_nama = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                for ($i = 1; $i <= 12; $i++):
                ?>
                    <option value="<?php echo $i; ?>" <?php echo $bulan == $i ? 'selected' : ''; ?>>
                        <?php echo $bulan_nama[$i]; ?>
                    </option>
                <?php endfor; ?>
            </select>
            <select name="tahun" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <?php for ($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                    <option value="<?php echo $i; ?>" <?php echo $tahun == $i ? 'selected' : ''; ?>>
                        <?php echo $i; ?>
                    </option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                <i class="fas fa-search mr-2"></i>Tampilkan Laporan
            </button>
        </form>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">Pengaduan</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang:</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_pengaduan'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya:</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_pengaduan'] ?? 0; ?></span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">Surat Menyurat</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang:</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_surat'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya:</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_surat'] ?? 0; ?></span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">UMKM</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang:</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_umkm'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya:</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_umkm'] ?? 0; ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="text-center">
        <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition">
            <i class="fas fa-print mr-2"></i>Cetak Laporan
        </button>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

