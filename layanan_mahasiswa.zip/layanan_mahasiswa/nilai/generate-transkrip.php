<?php
require_once '../config/config.php';
requireRole(['admin', 'dosen', 'pimpinan']);

$mahasiswa_id = intval($_GET['mahasiswa_id'] ?? 0);

if (!$mahasiswa_id) {
    header('Location: transkrip.php');
    exit;
}

$conn = getDBConnection();

$mahasiswa = $conn->query("
    SELECT m.*, p.nama_prodi, f.nama_fakultas
    FROM mahasiswa m 
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    LEFT JOIN fakultas f ON p.fakultas_id = f.id
    WHERE m.id = $mahasiswa_id
")->fetch_assoc();

$nilai_all = $conn->query("
    SELECT n.*, mk.kode_mk, mk.nama_mk, mk.sks
    FROM nilai n
    JOIN mata_kuliah mk ON n.mk_id = mk.id
    WHERE n.mahasiswa_id = $mahasiswa_id AND n.status = 'final'
    ORDER BY n.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

// Placeholder untuk PDF generation
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Transkrip_' . $mahasiswa['nim'] . '.pdf"');

// Generate PDF content (simplified)
echo "TRANSKRIP NILAI\n";
echo "NIM: " . $mahasiswa['nim'] . "\n";
echo "Nama: " . $mahasiswa['nama_mahasiswa'] . "\n";
echo "Prodi: " . $mahasiswa['nama_prodi'] . "\n\n";
echo "Nilai:\n";
foreach ($nilai_all as $n) {
    echo $n['kode_mk'] . " - " . $n['nama_mk'] . " | " . $n['nilai_huruf'] . "\n";
}
?>



