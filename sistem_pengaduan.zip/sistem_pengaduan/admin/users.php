<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $role = sanitize($_POST['role'] ?? '');
        $status_aktif = sanitize($_POST['status_aktif'] ?? 'aktif');
        
        if ($id > 0 && in_array($role, ['admin', 'warga', 'kepala_desa'])) {
            $stmt = $pdo->prepare("UPDATE users SET role = ?, status_aktif = ? WHERE id = ?");
            $stmt->execute([$role, $status_aktif, $id]);
            setFlashMessage('success', 'Pengguna berhasil diperbarui.');
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0 && $id != $_SESSION['user_id']) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            setFlashMessage('success', 'Pengguna berhasil dihapus.');
        }
    }
    header('Location: users.php');
    exit;
}

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$role_filter = isset($_GET['role']) ? sanitize($_GET['role']) : '';

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (nama_lengkap LIKE ? OR username LIKE ? OR email LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

if ($role_filter) {
    $where .= " AND role = ?";
    $params[] = $role_filter;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE $where ORDER BY created_at DESC");
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'Kelola Pengguna - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Kelola Pengguna</h1>

    <form method="GET" class="mb-6 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                       placeholder="Cari pengguna..." 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <select name="role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Semua Role</option>
                    <option value="admin" <?php echo $role_filter === 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="warga" <?php echo $role_filter === 'warga' ? 'selected' : ''; ?>>Warga</option>
                    <option value="kepala_desa" <?php echo $role_filter === 'kepala_desa' ? 'selected' : ''; ?>>Kepala Desa</option>
                </select>
            </div>
            <div>
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                    <i class="fas fa-search mr-2"></i>Cari
                </button>
            </div>
        </div>
    </form>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Username</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="font-medium text-gray-800"><?php echo htmlspecialchars($user['nama_lengkap']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($user['nik'] ?? '-'); ?></div>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?php echo htmlspecialchars($user['username']); ?></td>
                        <td class="px-6 py-4 text-gray-600"><?php echo htmlspecialchars($user['email']); ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs font-semibold bg-blue-100 text-blue-800">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <?php echo getStatusBadge($user['status_aktif']); ?>
                            <?php echo getStatusBadge($user['status_verifikasi'], 'verifikasi'); ?>
                        </td>
                        <td class="px-6 py-4">
                            <button onclick="document.getElementById('editModal<?php echo $user['id']; ?>').classList.remove('hidden')" 
                                    class="text-blue-600 hover:text-blue-700 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                <form method="POST" class="inline" onsubmit="return confirm('Yakin hapus pengguna ini?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <div id="editModal<?php echo $user['id']; ?>" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                        <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4">
                            <div class="flex items-center justify-between mb-6">
                                <h2 class="text-2xl font-bold text-gray-800">Edit Pengguna</h2>
                                <button onclick="document.getElementById('editModal<?php echo $user['id']; ?>').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>

                            <form method="POST">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
                                    <select name="role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                        <option value="warga" <?php echo $user['role'] === 'warga' ? 'selected' : ''; ?>>Warga</option>
                                        <option value="kepala_desa" <?php echo $user['role'] === 'kepala_desa' ? 'selected' : ''; ?>>Kepala Desa</option>
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Status Aktif</label>
                                    <select name="status_aktif" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="aktif" <?php echo $user['status_aktif'] === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                        <option value="nonaktif" <?php echo $user['status_aktif'] === 'nonaktif' ? 'selected' : ''; ?>>Nonaktif</option>
                                    </select>
                                </div>

                                <div class="flex gap-2">
                                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                                        Simpan
                                    </button>
                                    <button type="button" onclick="document.getElementById('editModal<?php echo $user['id']; ?>').classList.add('hidden')" 
                                            class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition">
                                        Batal
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>



