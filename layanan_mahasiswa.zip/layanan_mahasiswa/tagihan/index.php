<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'pimpinan']);

$pageTitle = 'Tagihan';
$currentModule = 'tagihan';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $tagihan_list = $conn->query("
        SELECT t.*, 
               (SELECT SUM(nominal) FROM pembayaran WHERE tagihan_id = t.id AND status = 'success') as total_bayar_actual
        FROM tagihan t 
        WHERE t.mahasiswa_id = " . $mahasiswa['id'] . " 
        ORDER BY t.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    $tagihan_list = $conn->query("
        SELECT t.*, m.nim, m.nama_mahasiswa,
               (SELECT SUM(nominal) FROM pembayaran WHERE tagihan_id = t.id AND status = 'success') as total_bayar_actual
        FROM tagihan t 
        JOIN mahasiswa m ON t.mahasiswa_id = m.id
        ORDER BY t.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Tagihan</h1>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="generate.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Generate Tagihan
        </a>
        <?php endif; ?>
    </div>
    
    <!-- Filter (Admin) -->
    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="prodi" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Prodi</option>
                <!-- Options from database -->
            </select>
            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Status</option>
                <option value="open">Open</option>
                <option value="pending">Pending</option>
                <option value="paid">Paid</option>
                <option value="lunas">Lunas</option>
            </select>
            <input type="text" name="search" placeholder="Cari NIM/Nama..." 
                   class="px-4 py-2 border border-gray-300 rounded-lg">
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- Tagihan List -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nomor Tagihan</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jenis</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Bayar</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Sisa</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jatuh Tempo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($tagihan_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'mahasiswa' ? '8' : '10' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada data tagihan</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($tagihan_list as $t): ?>
                        <tr class="hover:bg-gray-50">
                            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nim'] ?? '') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nama_mahasiswa'] ?? '') ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($t['nomor_tagihan']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php
                                $jenis = [
                                    'ukt_reguler' => 'UKT Reguler',
                                    'beasiswa_penuh' => 'Beasiswa Penuh',
                                    'beasiswa_50' => 'Beasiswa 50%'
                                ];
                                echo $jenis[$t['jenis_tagihan']] ?? $t['jenis_tagihan'];
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatRupiah($t['total_tagihan']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatRupiah($t['total_bayar_actual'] ?? $t['total_bayar']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatRupiah($t['sisa_tagihan']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatTanggal($t['jatuh_tempo']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($t['status']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $t['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if ($_SESSION['role'] === 'mahasiswa' && in_array($t['status'], ['open', 'pending'])): ?>
                                <a href="bayar.php?id=<?= $t['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-money-bill-wave"></i> Bayar
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



