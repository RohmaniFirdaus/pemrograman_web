<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Detail Dosen';
$currentModule = 'data-akademik-mahasiswa';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: dosen.php');
    exit;
}

$conn = getDBConnection();
$dosen = $conn->query("
    SELECT d.*, p.nama_prodi
    FROM dosen d 
    LEFT JOIN program_studi p ON d.prodi_id = p.id
    WHERE d.id = $id AND d.status = 'active'
")->fetch_assoc();

if (!$dosen) {
    header('Location: dosen.php');
    exit;
}

// Get mata kuliah yang diajar (current semester)
$current_semester = date('n') <= 6 ? date('Y') . '/2' : date('Y') . '/1';
$mata_kuliah = $conn->query("
    SELECT DISTINCT mk.id, mk.*, j.kelas, j.hari, j.jam_mulai, j.jam_selesai, j.ruangan
    FROM mata_kuliah mk
    JOIN jadwal_kuliah j ON mk.id = j.mk_id
    WHERE j.dosen_id = $id AND j.tahun_akademik = '" . $conn->real_escape_string($current_semester) . "'
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Dosen</h1>
        <a href="dosen.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Dosen -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Dosen</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">NIP</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nip']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nama_dosen']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nama_prodi'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jabatan</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['jabatan'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Email</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['email'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">No. HP</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['no_hp'] ?? '-') ?></p>
            </div>
        </div>
    </div>
    
    <!-- Mata Kuliah yang Diajar -->
    <?php if (!empty($mata_kuliah)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah yang Diajar (<?= htmlspecialchars($current_semester) ?>)</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Nama Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Kelas</th>
                        <th class="px-4 py-2 text-left">Jadwal</th>
                        <th class="px-4 py-2 text-left">Ruangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($mata_kuliah as $mk): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($mk['kode_mk']) ?></td>
                        <td class="px-4 py-2">
                            <a href="mata-kuliah-detail.php?id=<?= $mk['id'] ?>" class="text-blue-600 hover:text-blue-700">
                                <?= htmlspecialchars($mk['nama_mk']) ?>
                            </a>
                        </td>
                        <td class="px-4 py-2"><?= $mk['sks'] ?></td>
                        <td class="px-4 py-2"><?= $mk['semester'] ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($mk['kelas'] ?? '-') ?></td>
                        <td class="px-4 py-2">
                            <?= htmlspecialchars($mk['hari']) ?><br>
                            <span class="text-sm text-gray-600">
                                <?= date('H:i', strtotime($mk['jam_mulai'])) ?> - <?= date('H:i', strtotime($mk['jam_selesai'])) ?>
                            </span>
                        </td>
                        <td class="px-4 py-2"><?= htmlspecialchars($mk['ruangan'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>


