<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

$tipe = isset($_GET['tipe']) ? sanitize($_GET['tipe']) : 'pengaduan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $nama_kategori = sanitize($_POST['nama_kategori'] ?? '');
        $deskripsi = sanitize($_POST['deskripsi'] ?? '');
        
        if (empty($nama_kategori)) {
            setFlashMessage('error', 'Nama kategori harus diisi.');
        } else {
            $table = $tipe === 'pengaduan' ? 'kategori_pengaduan' : ($tipe === 'surat' ? 'kategori_surat' : 'kategori_umkm');
            
            if ($action === 'create') {
                if ($tipe === 'umkm') {
                    $stmt = $pdo->prepare("INSERT INTO $table (nama_kategori) VALUES (?)");
                    $stmt->execute([$nama_kategori]);
                } else {
                    $stmt = $pdo->prepare("INSERT INTO $table (nama_kategori, deskripsi) VALUES (?, ?)");
                    $stmt->execute([$nama_kategori, $deskripsi]);
                }
                setFlashMessage('success', 'Kategori berhasil ditambahkan.');
            } else {
                if ($tipe === 'umkm') {
                    $stmt = $pdo->prepare("UPDATE $table SET nama_kategori = ? WHERE id = ?");
                    $stmt->execute([$nama_kategori, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE $table SET nama_kategori = ?, deskripsi = ? WHERE id = ?");
                    $stmt->execute([$nama_kategori, $deskripsi, $id]);
                }
                setFlashMessage('success', 'Kategori berhasil diperbarui.');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $table = $tipe === 'pengaduan' ? 'kategori_pengaduan' : ($tipe === 'surat' ? 'kategori_surat' : 'kategori_umkm');
        $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
        $stmt->execute([$id]);
        setFlashMessage('success', 'Kategori berhasil dihapus.');
    }
    header('Location: kategori.php?tipe=' . $tipe);
    exit;
}

$table = $tipe === 'pengaduan' ? 'kategori_pengaduan' : ($tipe === 'surat' ? 'kategori_surat' : 'kategori_umkm');
$stmt = $pdo->query("SELECT * FROM $table ORDER BY nama_kategori");
$kategori_list = $stmt->fetchAll();

$edit_kategori = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = ?");
    $stmt->execute([$id]);
    $edit_kategori = $stmt->fetch();
}

$pageTitle = 'Kelola Kategori - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Kelola Kategori</h1>
            <p class="text-gray-600">Manajemen kategori</p>
        </div>
        <div class="flex gap-2">
            <a href="?tipe=pengaduan" class="px-4 py-2 rounded-lg <?php echo $tipe === 'pengaduan' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'; ?>">
                Pengaduan
            </a>
            <a href="?tipe=surat" class="px-4 py-2 rounded-lg <?php echo $tipe === 'surat' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'; ?>">
                Surat
            </a>
            <a href="?tipe=umkm" class="px-4 py-2 rounded-lg <?php echo $tipe === 'umkm' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'; ?>">
                UMKM
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Daftar Kategori <?php echo ucfirst($tipe); ?></h2>
            <div class="space-y-2">
                <?php foreach ($kategori_list as $kat): ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                            <div class="font-medium text-gray-800"><?php echo htmlspecialchars($kat['nama_kategori']); ?></div>
                            <?php if (isset($kat['deskripsi']) && $kat['deskripsi']): ?>
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($kat['deskripsi']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="flex gap-2">
                            <a href="?tipe=<?php echo $tipe; ?>&edit=<?php echo $kat['id']; ?>" class="text-blue-600 hover:text-blue-700">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form method="POST" class="inline" onsubmit="return confirm('Yakin hapus kategori ini?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo $kat['id']; ?>">
                                <button type="submit" class="text-red-600 hover:text-red-700">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4"><?php echo $edit_kategori ? 'Edit' : 'Tambah'; ?> Kategori</h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $edit_kategori ? 'update' : 'create'; ?>">
                <?php if ($edit_kategori): ?>
                    <input type="hidden" name="id" value="<?php echo $edit_kategori['id']; ?>">
                <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nama Kategori *</label>
                    <input type="text" name="nama_kategori" value="<?php echo htmlspecialchars($edit_kategori['nama_kategori'] ?? ''); ?>" required 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <?php if ($tipe !== 'umkm'): ?>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
                        <textarea name="deskripsi" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($edit_kategori['deskripsi'] ?? ''); ?></textarea>
                    </div>
                <?php endif; ?>

                <div class="flex gap-2">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                        Simpan
                    </button>
                    <?php if ($edit_kategori): ?>
                        <a href="kategori.php?tipe=<?php echo $tipe; ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition">
                            Batal
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>



