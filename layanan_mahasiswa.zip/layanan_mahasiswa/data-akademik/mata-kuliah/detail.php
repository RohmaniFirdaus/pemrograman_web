<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Detail Mata Kuliah';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mk = $conn->query("
    SELECT mk.*, p.nama_prodi, d.nama_dosen 
    FROM mata_kuliah mk 
    LEFT JOIN program_studi p ON mk.prodi_id = p.id 
    LEFT JOIN dosen d ON mk.dosen_pengampu_id = d.id 
    WHERE mk.id = $id
")->fetch_assoc();

if (!$mk) {
    header('Location: index.php');
    exit;
}

// Get prasyarat
$prasyarat = $conn->query("
    SELECT mk2.kode_mk, mk2.nama_mk 
    FROM prasyarat_mk pm 
    JOIN mata_kuliah mk2 ON pm.mk_prasyarat_id = mk2.id 
    WHERE pm.mk_id = $id
")->fetch_all(MYSQLI_ASSOC);

// Get jadwal
$jadwal = $conn->query("
    SELECT j.*, d.nama_dosen 
    FROM jadwal_kuliah j 
    LEFT JOIN dosen d ON j.dosen_id = d.id 
    WHERE j.mk_id = $id 
    ORDER BY j.hari, j.jam_mulai
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Mata Kuliah</h1>
        <div class="flex space-x-2">
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="edit.php?id=<?= $id ?>" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-edit mr-2"></i>Edit
            </a>
            <?php endif; ?>
            <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <!-- Info Mata Kuliah -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Mata Kuliah</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">Kode MK</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['kode_mk']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama MK</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_mk']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $mk['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS</p>
                <p class="font-semibold text-gray-800"><?= $mk['sks'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jenis</p>
                <p>
                    <span class="px-2 py-1 rounded text-xs <?= $mk['jenis'] === 'wajib' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>">
                        <?= ucfirst($mk['jenis']) ?>
                    </span>
                </p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pengampu</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_dosen'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($mk['status']) ?></p>
            </div>
            <?php if ($mk['deskripsi']): ?>
            <div class="md:col-span-2">
                <p class="text-gray-600 text-sm">Deskripsi</p>
                <p class="text-gray-800"><?= nl2br(htmlspecialchars($mk['deskripsi'])) ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Prasyarat -->
    <?php if (!empty($prasyarat)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Prasyarat</h2>
        <ul class="list-disc list-inside space-y-2">
            <?php foreach ($prasyarat as $p): ?>
            <li><?= htmlspecialchars($p['kode_mk']) ?> - <?= htmlspecialchars($p['nama_mk']) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Jadwal -->
    <?php if (!empty($jadwal)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jadwal Kuliah</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Dosen</th>
                        <th class="px-4 py-2 text-left">Kelas</th>
                        <th class="px-4 py-2 text-left">Hari</th>
                        <th class="px-4 py-2 text-left">Jam</th>
                        <th class="px-4 py-2 text-left">Ruangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($jadwal as $j): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($j['nama_dosen'] ?? '-') ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['kelas']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['hari']) ?></td>
                        <td class="px-4 py-2"><?= date('H:i', strtotime($j['jam_mulai'])) ?> - <?= date('H:i', strtotime($j['jam_selesai'])) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['ruangan'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../../includes/footer.php'; ?>



