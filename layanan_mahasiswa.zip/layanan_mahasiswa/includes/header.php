<?php
if (!isset($pageTitle)) $pageTitle = 'Dashboard';
if (!isset($currentModule)) $currentModule = '';
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - Sistem Pelayanan Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-md">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <i class="fas fa-graduation-cap text-green-600 text-2xl"></i>
                    <span class="text-xl font-bold text-gray-800">Politeknik Purbaya</span>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <span class="text-gray-700">
                            <i class="fas fa-user-circle mr-2"></i>
                            <?= htmlspecialchars($user['nama'] ?? $user['username']) ?>
                            <span class="text-sm text-gray-500">(<?= ucfirst($_SESSION['role']) ?>)</span>
                        </span>
                    </div>
                    <a href="<?= BASE_URL ?>auth/logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Sidebar & Main Content -->
    <div class="flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-lg min-h-screen">
            <nav class="p-4">
                <ul class="space-y-2">
                    <li>
                        <a href="<?= BASE_URL ?>dashboard/<?= $_SESSION['role'] ?>.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'dashboard' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-home mr-3"></i>Dashboard
                        </a>
                    </li>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'dosen'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>data-akademik/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'data-akademik' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-database mr-3"></i>Data Akademik
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
                    <li>
                        <a href="<?= BASE_URL ?>data-akademik-mahasiswa/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'data-akademik-mahasiswa' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-database mr-3"></i>Data Akademik
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa', 'dosen'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>krs/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'krs' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-clipboard-list mr-3"></i>KRS
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa', 'dosen', 'pimpinan'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>nilai/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'nilai' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-star mr-3"></i>Nilai
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa', 'dosen'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>tugas-akhir/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'tugas-akhir' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-book mr-3"></i>Tugas Akhir
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa', 'dosen', 'pimpinan'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>surat/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'surat' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-envelope mr-3"></i>Surat
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>pengaduan/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'pengaduan' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-exclamation-triangle mr-3"></i>Pengaduan
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'mahasiswa', 'pimpinan'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>tagihan/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'tagihan' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-money-bill-wave mr-3"></i>Tagihan
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['admin', 'pimpinan'])): ?>
                    <li>
                        <a href="<?= BASE_URL ?>laporan/index.php" 
                           class="flex items-center px-4 py-2 rounded-lg <?= $currentModule === 'laporan' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-green-50' ?>">
                            <i class="fas fa-chart-bar mr-3"></i>Laporan
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">



