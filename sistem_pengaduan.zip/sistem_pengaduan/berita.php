<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 9;
$offset = ($page - 1) * $perPage;

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$where = "WHERE status = 'dipublikasi'";
if ($search) {
    $where .= " AND (judul LIKE :search OR konten LIKE :search)";
}

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM berita $where");
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$total = $stmt->fetch()['total'];
$totalPages = ceil($total / $perPage);

$stmt = $pdo->prepare("
    SELECT b.*, u.nama_lengkap as admin_nama 
    FROM berita b 
    LEFT JOIN users u ON b.admin_id = u.id 
    $where 
    ORDER BY b.created_at DESC 
    LIMIT $perPage OFFSET $offset
");
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$berita_list = $stmt->fetchAll();

$pageTitle = 'Berita Desa - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Berita Desa</h1>
        <p class="text-gray-600">Informasi terbaru dari Pemerintah Desa Gembong Kulon</p>
    </div>

    <form method="GET" class="mb-6">
        <div class="flex gap-2">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                   placeholder="Cari berita..." 
                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
            <?php if ($search): ?>
                <a href="berita.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition">
                    <i class="fas fa-times mr-2"></i>Reset
                </a>
            <?php endif; ?>
        </div>
    </form>

    <?php if (empty($berita_list)): ?>
        <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
            <i class="fas fa-newspaper text-6xl text-gray-300 mb-4"></i>
            <p class="text-gray-600 text-lg"><?php echo $search ? 'Tidak ada berita yang ditemukan.' : 'Belum ada berita dipublikasi.'; ?></p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <?php foreach ($berita_list as $berita): ?>
                <div class="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition">
                    <?php if ($berita['gambar_utama']): ?>
                        <img src="<?php echo upload_url($berita['gambar_utama']); ?>" 
                             alt="<?php echo htmlspecialchars($berita['judul']); ?>" 
                             class="w-full h-48 object-cover">
                    <?php else: ?>
                        <div class="w-full h-48 bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-image text-4xl text-blue-400"></i>
                        </div>
                    <?php endif; ?>
                    <div class="p-6">
                        <h3 class="font-bold text-lg mb-2 text-gray-800"><?php echo htmlspecialchars($berita['judul']); ?></h3>
                        <p class="text-gray-600 text-sm mb-4"><?php echo htmlspecialchars(substr(strip_tags($berita['konten']), 0, 120)) . '...'; ?></p>
                        <div class="flex items-center justify-between text-xs text-gray-500 mb-4">
                            <span><i class="fas fa-calendar mr-1"></i><?php echo formatTanggal($berita['created_at']); ?></span>
                            <span><i class="fas fa-eye mr-1"></i><?php echo $berita['views']; ?> views</span>
                        </div>
                        <a href="berita_detail.php?id=<?php echo $berita['id']; ?>" 
                           class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded-lg transition">
                            Baca Selengkapnya
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php echo generatePagination($page, $totalPages, BASE_URL . 'berita.php'); ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>



