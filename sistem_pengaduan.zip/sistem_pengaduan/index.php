<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$stmt = $pdo->query("SELECT * FROM profil_desa LIMIT 1");
$profil_desa = $stmt->fetch();

$stmt = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM pengaduan) as total_pengaduan,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'menunggu') as menunggu_verifikasi,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'diproses') as sedang_diproses,
        (SELECT COUNT(*) FROM pengaduan WHERE status = 'selesai') as selesai,
        (SELECT COUNT(*) FROM surat_menyurat WHERE status = 'diproses') as surat_diproses,
        (SELECT COUNT(*) FROM umkm WHERE status_verifikasi = 'terverifikasi') as umkm_terverifikasi,
        (SELECT COUNT(*) FROM berita WHERE status = 'dipublikasi') as berita_dipublikasi
");
$stats = $stmt->fetch();

$stmt = $pdo->query("
    SELECT p.*, u.nama_lengkap, k.nama_kategori 
    FROM pengaduan p 
    LEFT JOIN users u ON p.user_id = u.id 
    LEFT JOIN kategori_pengaduan k ON p.kategori_id = k.id
    ORDER BY p.created_at DESC 
    LIMIT 5
");
$latest_pengaduan = $stmt->fetchAll();

$stmt = $pdo->query("
    SELECT * FROM berita 
    WHERE status = 'dipublikasi' 
    ORDER BY created_at DESC 
    LIMIT 3
");
$latest_berita = $stmt->fetchAll();

$stmt = $pdo->query("
    SELECT u.*, k.nama_kategori 
    FROM umkm u 
    LEFT JOIN kategori_umkm k ON u.kategori_id = k.id
    WHERE u.is_unggulan = 1 AND u.status_verifikasi = 'terverifikasi'
    ORDER BY u.created_at DESC 
    LIMIT 3
");
$featured_umkm = $stmt->fetchAll();

$stmt = $pdo->query("
    SELECT * FROM kalender_kegiatan 
    WHERE tanggal_mulai >= CURDATE()
    ORDER BY tanggal_mulai ASC 
    LIMIT 5
");
$upcoming_events = $stmt->fetchAll();

$pageTitle = 'Beranda - ' . APP_NAME;
include 'includes/header.php';
?>

<style>
    .hero-section {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
                    <?php echo $profil_desa && $profil_desa['background_homepage'] ? "url('" . upload_url($profil_desa['background_homepage']) . "')" : "url('assets/images/default-bg.jpg')"; ?>;
        background-size: cover;
        background-position: center;
        min-height: 500px;
    }
</style>

<div class="min-h-screen flex flex-col">
    <section class="hero-section flex items-center justify-center text-white text-center px-4">
        <div class="max-w-4xl">
            <h1 class="text-5xl font-bold mb-4">Sistem Desa Gembong Kulon</h1>
            <p class="text-xl mb-8 text-blue-100">
                Layanan digital terpadu untuk pengaduan warga, surat online, berita desa, UMKM unggulan, dan kalender kegiatan secara real time.
            </p>
            <div class="flex justify-center space-x-4">
                <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-semibold transition">
                    <i class="fas fa-paper-plane mr-2"></i>Ajukan Pengaduan
                </a>
                <a href="<?php echo BASE_URL; ?>warga/surat_online.php" class="bg-white text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-lg font-semibold transition">
                    <i class="fas fa-file-alt mr-2"></i>Permohonan Surat
                </a>
            </div>
        </div>
    </section>

    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-8 text-gray-800">Statistik Pengaduan & Pelayanan</h2>
            <p class="text-center text-gray-600 mb-8">Rekapitulasi terkini per <?php echo formatTanggal(date('Y-m-d')); ?></p>
            
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-file-alt text-4xl text-blue-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['total_pengaduan'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">TOTAL PENGADUAN</div>
                </div>
                
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-clock text-4xl text-yellow-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['menunggu_verifikasi'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">MENUNGGU VERIFIKASI</div>
                </div>
                
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-spinner text-4xl text-blue-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['sedang_diproses'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">SEDANG DIPROSES</div>
                </div>
                
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-check-circle text-4xl text-blue-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['selesai'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">SELESAI</div>
                </div>
                
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-envelope text-4xl text-purple-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['surat_diproses'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">SURAT DIPROSES</div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-shopping-bag text-4xl text-orange-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['umkm_terverifikasi'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">UMKM TERVERIFIKASI</div>
                </div>
                
                <div class="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                    <i class="fas fa-newspaper text-4xl text-red-600 mb-3"></i>
                    <div class="text-3xl font-bold text-gray-800"><?php echo $stats['berita_dipublikasi'] ?? 0; ?></div>
                    <div class="text-sm text-gray-600 mt-2">BERITA DIPUBLIKASI</div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-12 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">Pengaduan Terbaru</h2>
            <p class="text-gray-600 mb-6">Pantau progres secara real time</p>
            
            <?php if (empty($latest_pengaduan)): ?>
                <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
                    <i class="fas fa-file-alt text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 text-lg mb-2">Belum ada pengaduan yang masuk.</p>
                    <p class="text-gray-500 mb-6">Jadilah yang pertama untuk mengajukan pengaduan dan membantu membangun desa yang lebih baik.</p>
                    <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition">
                        <i class="fas fa-plus mr-2"></i>Ajukan Pengaduan Pertama
                    </a>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($latest_pengaduan as $pengaduan): ?>
                        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                            <div class="flex items-start justify-between mb-3">
                                <h3 class="font-bold text-lg text-gray-800"><?php echo htmlspecialchars($pengaduan['judul']); ?></h3>
                                <?php echo getStatusBadge($pengaduan['status'], 'pengaduan'); ?>
                            </div>
                            <p class="text-gray-600 text-sm mb-3"><?php echo htmlspecialchars(substr($pengaduan['deskripsi'], 0, 100)) . '...'; ?></p>
                            <div class="flex items-center justify-between text-xs text-gray-500">
                                <span><i class="fas fa-user mr-1"></i><?php echo htmlspecialchars($pengaduan['nama_lengkap']); ?></span>
                                <span><i class="fas fa-calendar mr-1"></i><?php echo formatTanggal($pengaduan['created_at']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">Berita Desa</h2>
            <p class="text-gray-600 mb-6">Informasi resmi dari Pemerintah Desa</p>
            
            <?php if (empty($latest_berita)): ?>
                <div class="bg-gray-50 rounded-lg p-12 text-center border border-gray-200">
                    <i class="fas fa-newspaper text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 text-lg">Belum ada berita dipublikasi.</p>
                    <p class="text-gray-500">Informasi terbaru dari Pemerintah Desa akan ditampilkan di sini.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php foreach ($latest_berita as $berita): ?>
                        <div class="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200">
                            <?php if ($berita['gambar_utama']): ?>
                                <img src="<?php echo upload_url($berita['gambar_utama']); ?>" alt="<?php echo htmlspecialchars($berita['judul']); ?>" class="w-full h-48 object-cover">
                            <?php else: ?>
                                <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                                    <i class="fas fa-image text-4xl text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                            <div class="p-6">
                                <h3 class="font-bold text-lg mb-2 text-gray-800"><?php echo htmlspecialchars($berita['judul']); ?></h3>
                                <p class="text-gray-600 text-sm mb-4"><?php echo htmlspecialchars(substr(strip_tags($berita['konten']), 0, 100)) . '...'; ?></p>
                                <div class="flex items-center justify-between text-xs text-gray-500">
                                    <span><i class="fas fa-calendar mr-1"></i><?php echo formatTanggal($berita['created_at']); ?></span>
                                    <a href="<?php echo BASE_URL; ?>berita_detail.php?id=<?php echo $berita['id']; ?>" class="text-blue-600 hover:text-blue-700">Baca Selengkapnya →</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="py-12 bg-blue-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">UMKM Unggulan</h2>
            <p class="text-gray-600 mb-6">Produk lokal terbaik dari warga Gembong Kulon</p>
            
            <?php if (empty($featured_umkm)): ?>
                <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
                    <i class="fas fa-shopping-bag text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 text-lg">Belum ada UMKM unggulan.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php foreach ($featured_umkm as $umkm): ?>
                        <div class="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200">
                            <div class="relative">
                                <?php if ($umkm['gambar_utama']): ?>
                                    <img src="<?php echo upload_url($umkm['gambar_utama']); ?>" alt="<?php echo htmlspecialchars($umkm['nama_umkm']); ?>" class="w-full h-48 object-cover">
                                <?php else: ?>
                                    <div class="w-full h-48 bg-blue-100 flex items-center justify-center">
                                        <i class="fas fa-store text-6xl text-blue-400"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="absolute top-2 right-2 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                                    <?php echo htmlspecialchars($umkm['nama_kategori']); ?>
                                </span>
                            </div>
                            <div class="p-6">
                                <h3 class="font-bold text-xl mb-2 text-gray-800"><?php echo htmlspecialchars($umkm['nama_umkm']); ?></h3>
                                <p class="text-gray-600 text-sm mb-4"><?php echo htmlspecialchars(substr($umkm['deskripsi'], 0, 100)) . '...'; ?></p>
                                <div class="flex items-center text-sm text-gray-600 mb-4">
                                    <i class="fas fa-user mr-2"></i>
                                    <span>Pemilik: <?php echo htmlspecialchars($umkm['nama_pemilik']); ?></span>
                                </div>
                                <div class="flex items-center text-sm text-gray-600 mb-4">
                                    <i class="fas fa-map-marker-alt mr-2"></i>
                                    <span><?php echo htmlspecialchars($umkm['alamat']); ?></span>
                                </div>
                                <a href="<?php echo BASE_URL; ?>umkm_detail.php?id=<?php echo $umkm['id']; ?>" class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded-lg transition">
                                    Lihat Detail
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php if (!empty($upcoming_events)): ?>
    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">Kalender Desa (Realtime)</h2>
            <p class="text-gray-600 mb-6">Agenda rapat, kegiatan warga, dan hari penting desa</p>
            
            <div class="bg-white rounded-lg p-6 border border-gray-200">
                <div class="space-y-4">
                    <?php foreach ($upcoming_events as $event): ?>
                        <div class="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                            <div class="flex-shrink-0 w-16 h-16 bg-blue-600 text-white rounded-lg flex items-center justify-center">
                                <div class="text-center">
                                    <div class="text-xs font-semibold"><?php echo date('d', strtotime($event['tanggal_mulai'])); ?></div>
                                    <div class="text-xs"><?php echo date('M', strtotime($event['tanggal_mulai'])); ?></div>
                                </div>
                            </div>
                            <div class="flex-1">
                                <h3 class="font-bold text-lg text-gray-800"><?php echo htmlspecialchars($event['judul_acara']); ?></h3>
                                <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($event['deskripsi']); ?></p>
                                <div class="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                                    <span><i class="fas fa-clock mr-1"></i><?php echo date('H:i', strtotime($event['waktu_mulai'])); ?></span>
                                    <span><i class="fas fa-map-marker-alt mr-1"></i><?php echo htmlspecialchars($event['lokasi']); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <section class="py-12 bg-blue-600 text-white">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold mb-4 text-center">Cara Mengakses Layanan</h2>
            <p class="text-center mb-8 text-blue-100">Ikuti langkah-langkah berikut untuk menggunakan layanan desa</p>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="w-16 h-16 bg-white text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">1</div>
                    <h3 class="font-bold text-xl mb-2">Buat Akun / Login</h3>
                    <p class="text-blue-100">Gunakan NIK untuk membuat akun warga dan akses dashboard pribadi.</p>
                </div>
                
                <div class="text-center">
                    <div class="w-16 h-16 bg-white text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">2</div>
                    <h3 class="font-bold text-xl mb-2">Ajukan Pengaduan / Surat</h3>
                    <p class="text-blue-100">Lengkapi formulir pengaduan atau surat online dengan bukti pendukung.</p>
                </div>
                
                <div class="text-center">
                    <div class="w-16 h-16 bg-white text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">3</div>
                    <h3 class="font-bold text-xl mb-2">Pantau Status Realtime</h3>
                    <p class="text-blue-100">Administrator dan kepala desa menindaklanjuti, Anda bisa memantau progres kapan saja.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="py-12 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4 text-gray-800">Berpartisipasi Membangun Desa</h2>
            <p class="text-gray-600 mb-8">Laporkan aspirasi, ikuti agenda desa, dan dukung UMKM lokal</p>
            <div class="flex justify-center space-x-4">
                <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition">
                    <i class="fas fa-paper-plane mr-2"></i>Laporkan Sekarang
                </a>
                <?php if (!isLoggedIn()): ?>
                    <a href="<?php echo BASE_URL; ?>login.php" class="bg-white border-2 border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-lg font-semibold transition">
                        <i class="fas fa-arrow-right mr-2"></i>Masuk Dashboard
                    </a>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>warga/dashboard.php" class="bg-white border-2 border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-lg font-semibold transition">
                        <i class="fas fa-arrow-right mr-2"></i>Masuk Dashboard
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>

