<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = !is_readonly_admin();

$pdo = getConnection();
$page_title = 'Kelola Halaman Tentang';
$message = '';
$message_type = '';

$tentang = [
    'judul_hero' => 'Tentang Aplikasi',
    'deskripsi_hero' => 'Sistem Pengaduan dan Pelayanan Publik Terpadu Desa Gembong Kulon',
    'konten_aplikasi' => '',
    'fitur_1_judul' => '', 'fitur_1_deskripsi' => '', 'fitur_1_icon' => 'fa-check-circle',
    'fitur_2_judul' => '', 'fitur_2_deskripsi' => '', 'fitur_2_icon' => 'fa-search',
    'fitur_3_judul' => '', 'fitur_3_deskripsi' => '', 'fitur_3_icon' => 'fa-file-alt',
    'fitur_4_judul' => '', 'fitur_4_deskripsi' => '', 'fitur_4_icon' => 'fa-newspaper',
    'fitur_5_judul' => '', 'fitur_5_deskripsi' => '', 'fitur_5_icon' => 'fa-shield-alt',
    'fitur_6_judul' => '', 'fitur_6_deskripsi' => '', 'fitur_6_icon' => 'fa-chart-line'
];

try {
    $stmt = $pdo->query("SELECT * FROM tentang_aplikasi ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) $tentang = array_merge($tentang, $row);
} catch (PDOException $e) {
    if (strpos($e->getMessage(), "doesn't exist") !== false) {
        try {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS tentang_aplikasi (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    judul_hero VARCHAR(255) NOT NULL DEFAULT 'Tentang Aplikasi',
                    deskripsi_hero TEXT,
                    konten_aplikasi TEXT,
                    fitur_1_judul VARCHAR(255),
                    fitur_1_deskripsi TEXT,
                    fitur_1_icon VARCHAR(50),
                    fitur_2_judul VARCHAR(255),
                    fitur_2_deskripsi TEXT,
                    fitur_2_icon VARCHAR(50),
                    fitur_3_judul VARCHAR(255),
                    fitur_3_deskripsi TEXT,
                    fitur_3_icon VARCHAR(50),
                    fitur_4_judul VARCHAR(255),
                    fitur_4_deskripsi TEXT,
                    fitur_4_icon VARCHAR(50),
                    fitur_5_judul VARCHAR(255),
                    fitur_5_deskripsi TEXT,
                    fitur_5_icon VARCHAR(50),
                    fitur_6_judul VARCHAR(255),
                    fitur_6_deskripsi TEXT,
                    fitur_6_icon VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
        } catch (PDOException $e2) {
            error_log('Create table error: ' . $e2->getMessage());
        }
    } else {
        error_log('Tentang aplikasi error: ' . $e->getMessage());
    }
}

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($tentang['id'])) {
            $stmt = $pdo->prepare("
                UPDATE tentang_aplikasi SET 
                judul_hero=:judul_hero, deskripsi_hero=:deskripsi_hero, konten_aplikasi=:konten,
                fitur_1_judul=:f1j, fitur_1_deskripsi=:f1d, fitur_1_icon=:f1i,
                fitur_2_judul=:f2j, fitur_2_deskripsi=:f2d, fitur_2_icon=:f2i,
                fitur_3_judul=:f3j, fitur_3_deskripsi=:f3d, fitur_3_icon=:f3i,
                fitur_4_judul=:f4j, fitur_4_deskripsi=:f4d, fitur_4_icon=:f4i,
                fitur_5_judul=:f5j, fitur_5_deskripsi=:f5d, fitur_5_icon=:f5i,
                fitur_6_judul=:f6j, fitur_6_deskripsi=:f6d, fitur_6_icon=:f6i
                WHERE id = :id
            ");
            $stmt->execute([
                'judul_hero' => $_POST['judul_hero'],
                'deskripsi_hero' => $_POST['deskripsi_hero'],
                'konten' => $_POST['konten_aplikasi'],
                'f1j' => $_POST['fitur_1_judul'] ?? '',
                'f1d' => $_POST['fitur_1_deskripsi'] ?? '',
                'f1i' => $_POST['fitur_1_icon'] ?? 'fa-check-circle',
                'f2j' => $_POST['fitur_2_judul'] ?? '',
                'f2d' => $_POST['fitur_2_deskripsi'] ?? '',
                'f2i' => $_POST['fitur_2_icon'] ?? 'fa-search',
                'f3j' => $_POST['fitur_3_judul'] ?? '',
                'f3d' => $_POST['fitur_3_deskripsi'] ?? '',
                'f3i' => $_POST['fitur_3_icon'] ?? 'fa-file-alt',
                'f4j' => $_POST['fitur_4_judul'] ?? '',
                'f4d' => $_POST['fitur_4_deskripsi'] ?? '',
                'f4i' => $_POST['fitur_4_icon'] ?? 'fa-newspaper',
                'f5j' => $_POST['fitur_5_judul'] ?? '',
                'f5d' => $_POST['fitur_5_deskripsi'] ?? '',
                'f5i' => $_POST['fitur_5_icon'] ?? 'fa-shield-alt',
                'f6j' => $_POST['fitur_6_judul'] ?? '',
                'f6d' => $_POST['fitur_6_deskripsi'] ?? '',
                'f6i' => $_POST['fitur_6_icon'] ?? 'fa-chart-line',
                'id' => $tentang['id']
            ]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO tentang_aplikasi (
                    judul_hero, deskripsi_hero, konten_aplikasi,
                    fitur_1_judul, fitur_1_deskripsi, fitur_1_icon,
                    fitur_2_judul, fitur_2_deskripsi, fitur_2_icon,
                    fitur_3_judul, fitur_3_deskripsi, fitur_3_icon,
                    fitur_4_judul, fitur_4_deskripsi, fitur_4_icon,
                    fitur_5_judul, fitur_5_deskripsi, fitur_5_icon,
                    fitur_6_judul, fitur_6_deskripsi, fitur_6_icon
                ) VALUES (
                    :judul_hero, :deskripsi_hero, :konten,
                    :f1j, :f1d, :f1i, :f2j, :f2d, :f2i,
                    :f3j, :f3d, :f3i, :f4j, :f4d, :f4i,
                    :f5j, :f5d, :f5i, :f6j, :f6d, :f6i
                )
            ");
            $stmt->execute([
                'judul_hero' => $_POST['judul_hero'],
                'deskripsi_hero' => $_POST['deskripsi_hero'],
                'konten' => $_POST['konten_aplikasi'],
                'f1j' => $_POST['fitur_1_judul'] ?? '',
                'f1d' => $_POST['fitur_1_deskripsi'] ?? '',
                'f1i' => $_POST['fitur_1_icon'] ?? 'fa-check-circle',
                'f2j' => $_POST['fitur_2_judul'] ?? '',
                'f2d' => $_POST['fitur_2_deskripsi'] ?? '',
                'f2i' => $_POST['fitur_2_icon'] ?? 'fa-search',
                'f3j' => $_POST['fitur_3_judul'] ?? '',
                'f3d' => $_POST['fitur_3_deskripsi'] ?? '',
                'f3i' => $_POST['fitur_3_icon'] ?? 'fa-file-alt',
                'f4j' => $_POST['fitur_4_judul'] ?? '',
                'f4d' => $_POST['fitur_4_deskripsi'] ?? '',
                'f4i' => $_POST['fitur_4_icon'] ?? 'fa-newspaper',
                'f5j' => $_POST['fitur_5_judul'] ?? '',
                'f5d' => $_POST['fitur_5_deskripsi'] ?? '',
                'f5i' => $_POST['fitur_5_icon'] ?? 'fa-shield-alt',
                'f6j' => $_POST['fitur_6_judul'] ?? '',
                'f6d' => $_POST['fitur_6_deskripsi'] ?? '',
                'f6i' => $_POST['fitur_6_icon'] ?? 'fa-chart-line'
            ]);
        }
        $message = 'Halaman tentang berhasil disimpan.';
        $message_type = 'success';
        header('Location: tentang.php');
        exit;
    } catch (PDOException $e) {
        error_log('Update tentang error: ' . $e->getMessage());
        $message = 'Gagal menyimpan halaman tentang.';
        $message_type = 'danger';
    }
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Kelola Halaman Tentang Aplikasi</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="tentang.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Judul Hero</label>
                    <input type="text" name="judul_hero" class="form-control" value="<?php echo esc($tentang['judul_hero']); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                </div>
                <div class="mb-3">
                    <label class="form-label">Deskripsi Hero</label>
                    <input type="text" name="deskripsi_hero" class="form-control" value="<?php echo esc($tentang['deskripsi_hero']); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                </div>
                <div class="mb-3">
                    <label class="form-label">Konten Aplikasi</label>
                    <textarea name="konten_aplikasi" class="form-control" rows="6" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($tentang['konten_aplikasi']); ?></textarea>
                </div>

                <h4 class="mt-4 mb-3">Fitur Unggulan</h4>
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5>Fitur <?php echo $i; ?></h5>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Judul</label>
                                    <input type="text" name="fitur_<?php echo $i; ?>_judul" class="form-control" value="<?php echo esc($tentang["fitur_{$i}_judul"]); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Icon (Font Awesome)</label>
                                    <input type="text" name="fitur_<?php echo $i; ?>_icon" class="form-control" value="<?php echo esc($tentang["fitur_{$i}_icon"]); ?>" placeholder="fa-check-circle" <?php echo $can_update ? '' : 'readonly'; ?>>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea name="fitur_<?php echo $i; ?>_deskripsi" class="form-control" rows="2" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($tentang["fitur_{$i}_deskripsi"]); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>

                <?php if ($can_update): ?>
                    <button class="btn btn-primary">Simpan</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>




