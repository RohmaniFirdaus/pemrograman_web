<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();

$action = $_POST['action'] ?? '';
$status = $_POST['status'] ?? 'draft';
$krs_id = intval($_POST['krs_id'] ?? 0);
$courses = json_decode($_POST['courses'] ?? '[]', true);
$schedules = json_decode($_POST['schedules'] ?? '[]', true);

// Calculate total SKS
$total_sks = 0;
if (!empty($courses)) {
    $ids = implode(',', array_map('intval', $courses));
    $result = $conn->query("SELECT SUM(sks) as total FROM mata_kuliah WHERE id IN ($ids)");
    $total_sks = $result->fetch_assoc()['total'] ?? 0;
}

$tahun_akademik = date('Y') . '/' . (date('Y') + 1);
$semester = $mahasiswa['semester'];

if ($krs_id > 0) {
    // Update existing KRS
    $tanggal_kirim = $status === 'menunggu_approval' ? date('Y-m-d H:i:s') : null;
    if ($tanggal_kirim) {
        $stmt = $conn->prepare("UPDATE krs SET sks_diambil = ?, status = ?, tanggal_kirim = ? WHERE id = ? AND mahasiswa_id = ?");
        $stmt->bind_param("isssi", $total_sks, $status, $tanggal_kirim, $krs_id, $mahasiswa['id']);
    } else {
        $stmt = $conn->prepare("UPDATE krs SET sks_diambil = ?, status = ? WHERE id = ? AND mahasiswa_id = ?");
        $stmt->bind_param("isii", $total_sks, $status, $krs_id, $mahasiswa['id']);
    }
    $stmt->execute();
    $stmt->close();
    
    // Delete old details
    $conn->query("DELETE FROM krs_detail WHERE krs_id = $krs_id");
} else {
    // Create new KRS
    $tanggal_kirim = $status === 'menunggu_approval' ? date('Y-m-d H:i:s') : null;
    $stmt = $conn->prepare("INSERT INTO krs (mahasiswa_id, semester, tahun_akademik, sks_diambil, status, tanggal_kirim) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $mahasiswa['id'], $semester, $tahun_akademik, $total_sks, $status, $tanggal_kirim);
    $stmt->execute();
    $krs_id = $conn->insert_id;
    $stmt->close();
}

// Insert KRS details
if (!empty($courses)) {
    foreach ($courses as $mk_id) {
        $jadwal_id = isset($schedules[$mk_id]) && $schedules[$mk_id] > 0 ? intval($schedules[$mk_id]) : null;
        if ($jadwal_id) {
            $stmt = $conn->prepare("INSERT INTO krs_detail (krs_id, mk_id, jadwal_id) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $krs_id, $mk_id, $jadwal_id);
        } else {
            $stmt = $conn->prepare("INSERT INTO krs_detail (krs_id, mk_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $krs_id, $mk_id);
        }
        $stmt->execute();
        $stmt->close();
    }
}

$conn->close();

echo json_encode(['success' => true, 'krs_id' => $krs_id]);
?>

