<?php
// General Helper Functions

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

function formatTanggal($tanggal) {
    return date('d M Y', strtotime($tanggal));
}

function formatTanggalWaktu($tanggal) {
    return date('d M Y H:i', strtotime($tanggal));
}

function generateKode($prefix, $id) {
    return $prefix . str_pad($id, 6, '0', STR_PAD_LEFT);
}

function uploadFile($file, $destination, $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf']) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Error uploading file'];
    }
    
    $fileName = $file['name'];
    $fileTmp = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    
    if (!in_array($fileExt, $allowedTypes)) {
        return ['success' => false, 'message' => 'File type not allowed'];
    }
    
    $newFileName = uniqid() . '_' . time() . '.' . $fileExt;
    $uploadPath = $destination . $newFileName;
    
    if (move_uploaded_file($fileTmp, $uploadPath)) {
        return [
            'success' => true,
            'filename' => $newFileName,
            'path' => $uploadPath,
            'size' => $fileSize
        ];
    }
    
    return ['success' => false, 'message' => 'Failed to upload file'];
}

function getNilaiAngka($nilaiHuruf) {
    $nilai = [
        'A' => 4.00,
        'B+' => 3.50,
        'B' => 3.00,
        'C+' => 2.50,
        'C' => 2.00,
        'D' => 1.00,
        'E' => 0.00
    ];
    return $nilai[$nilaiHuruf] ?? 0.00;
}

function calculateIPK($mahasiswa_id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("
        SELECT SUM(n.nilai_angka * mk.sks) as total_bobot, SUM(mk.sks) as total_sks
        FROM nilai n
        JOIN mata_kuliah mk ON n.mk_id = mk.id
        WHERE n.mahasiswa_id = ? AND n.status = 'final'
    ");
    $stmt->bind_param("i", $mahasiswa_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    if ($result['total_sks'] > 0) {
        return round($result['total_bobot'] / $result['total_sks'], 2);
    }
    return 0.00;
}

function getStatusBadge($status) {
    $badges = [
        'draft' => 'bg-gray-500',
        'menunggu' => 'bg-yellow-500',
        'menunggu_approval' => 'bg-yellow-500',
        'diproses' => 'bg-blue-500',
        'approved' => 'bg-green-500',
        'ditolak' => 'bg-red-500',
        'final' => 'bg-green-600',
        'open' => 'bg-yellow-500',
        'pending' => 'bg-yellow-500',
        'paid' => 'bg-green-500',
        'lunas' => 'bg-green-600',
        'success' => 'bg-green-500',
        'failed' => 'bg-red-500',
        'selesai' => 'bg-green-500',
        'escalated' => 'bg-purple-500',
        'active' => 'bg-green-500',
        'inactive' => 'bg-gray-500'
    ];
    
    $color = $badges[$status] ?? 'bg-gray-500';
    $statusText = ucfirst(str_replace('_', ' ', $status));
    
    return "<span class='px-2 py-1 rounded text-white text-xs font-semibold {$color}'>{$statusText}</span>";
}
?>



