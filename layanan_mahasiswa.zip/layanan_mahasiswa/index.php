<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

// Get latest announcements
$conn = getDBConnection();
$pengumuman = $conn->query("SELECT * FROM pengumuman WHERE status = 'published' ORDER BY created_at DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);
$berita = $conn->query("SELECT * FROM berita WHERE status = 'published' ORDER BY created_at DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);
$faq = $conn->query("SELECT * FROM faq WHERE status = 'active' ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pelayanan Mahasiswa - Politeknik Purbaya</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @keyframes counter {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .counter-animate {
            animation: counter 0.6s ease-out;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-graduation-cap text-green-600 text-2xl"></i>
                    <span class="text-xl font-bold text-gray-800">Politeknik Purbaya</span>
                </div>
                <a href="auth/login.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
                    <i class="fas fa-sign-in-alt mr-2"></i>Login
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-green-600 to-green-700 text-white py-20">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-5xl font-bold mb-4">Satu Platform, Segala Kemudahan Akademik</h1>
            <p class="text-xl mb-8">Sistem Pelayanan Mahasiswa Terintegrasi untuk Masa Depan yang Lebih Baik</p>
            <a href="auth/login.php" class="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition inline-block">
                <i class="fas fa-rocket mr-2"></i>Mulai Sekarang
            </a>
        </div>
    </section>

    <!-- Counter Animated -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
                <div class="counter-animate">
                    <div class="text-4xl font-bold text-green-600 mb-2" id="counter-mhs">0</div>
                    <div class="text-gray-600">Mahasiswa Aktif</div>
                </div>
                <div class="counter-animate">
                    <div class="text-4xl font-bold text-green-600 mb-2" id="counter-dosen">0</div>
                    <div class="text-gray-600">Dosen</div>
                </div>
                <div class="counter-animate">
                    <div class="text-4xl font-bold text-green-600 mb-2" id="counter-mk">0</div>
                    <div class="text-gray-600">Mata Kuliah</div>
                </div>
                <div class="counter-animate">
                    <div class="text-4xl font-bold text-green-600 mb-2" id="counter-prodi">0</div>
                    <div class="text-gray-600">Program Studi</div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Pertanyaan Umum (FAQ)</h2>
            <div class="max-w-3xl mx-auto space-y-4">
                <?php foreach ($faq as $index => $item): ?>
                <div class="bg-white rounded-lg shadow p-6">
                    <h3 class="font-semibold text-lg text-gray-800 mb-2">
                        <i class="fas fa-question-circle text-green-600 mr-2"></i><?= htmlspecialchars($item['pertanyaan']) ?>
                    </h3>
                    <p class="text-gray-600"><?= htmlspecialchars($item['jawaban']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- News Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Berita Terbaru</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php foreach ($berita as $item): ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                    <?php if ($item['gambar']): ?>
                    <img src="<?= BASE_URL . htmlspecialchars($item['gambar']) ?>" alt="<?= htmlspecialchars($item['judul']) ?>" class="w-full h-48 object-cover">
                    <?php endif; ?>
                    <div class="p-6">
                        <h3 class="font-semibold text-lg mb-2 text-gray-800"><?= htmlspecialchars($item['judul']) ?></h3>
                        <p class="text-gray-600 text-sm mb-4"><?= substr(strip_tags($item['isi']), 0, 100) ?>...</p>
                        <span class="text-sm text-gray-500">
                            <i class="far fa-calendar mr-1"></i><?= date('d M Y', strtotime($item['created_at'])) ?>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Pengumuman Section -->
    <section class="py-16 bg-green-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Pengumuman Kampus</h2>
            <div class="max-w-3xl mx-auto space-y-4">
                <?php foreach ($pengumuman as $item): ?>
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-green-600">
                    <h3 class="font-semibold text-lg text-gray-800 mb-2">
                        <i class="fas fa-bullhorn text-green-600 mr-2"></i><?= htmlspecialchars($item['judul']) ?>
                    </h3>
                    <p class="text-gray-600 mb-2"><?= htmlspecialchars($item['isi']) ?></p>
                    <span class="text-sm text-gray-500">
                        <i class="far fa-calendar mr-1"></i><?= date('d M Y', strtotime($item['created_at'])) ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h2 class="text-3xl font-bold mb-6 text-gray-800">Tentang Sistem</h2>
                <p class="text-gray-600 text-lg leading-relaxed">
                    Sistem Pelayanan Mahasiswa Politeknik Purbaya adalah platform terintegrasi yang menyediakan 
                    berbagai layanan akademik dalam satu tempat. Dari pengisian KRS, pengecekan nilai, pengelolaan 
                    tugas akhir, hingga pembayaran tagihan - semua dapat diakses dengan mudah dan cepat.
                </p>
            </div>
        </div>
    </section>

    <!-- Contact Info -->
    <section class="py-16 bg-gray-800 text-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                    <i class="fas fa-map-marker-alt text-3xl text-green-400 mb-4"></i>
                    <h3 class="font-semibold mb-2">Alamat Kampus</h3>
                    <p class="text-gray-300">Jl. Raya Purbaya No. 123<br>Kota Purbaya, 12345</p>
                </div>
                <div>
                    <i class="fas fa-envelope text-3xl text-green-400 mb-4"></i>
                    <h3 class="font-semibold mb-2">Email Support</h3>
                    <p class="text-gray-300">support@poltekpurbaya.ac.id</p>
                </div>
                <div>
                    <i class="fas fa-phone text-3xl text-green-400 mb-4"></i>
                    <h3 class="font-semibold mb-2">Helpdesk</h3>
                    <p class="text-gray-300">(021) 1234-5678</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="font-bold text-lg mb-4">Politeknik Purbaya</h3>
                    <p class="text-gray-400 text-sm">Platform terintegrasi untuk kemudahan akademik</p>
                </div>
                <div>
                    <h3 class="font-bold mb-4">Quick Links</h3>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="#" class="hover:text-white">Beranda</a></li>
                        <li><a href="#" class="hover:text-white">Tentang</a></li>
                        <li><a href="#" class="hover:text-white">Kontak</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-bold mb-4">Layanan</h3>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="#" class="hover:text-white">KRS</a></li>
                        <li><a href="#" class="hover:text-white">Nilai</a></li>
                        <li><a href="#" class="hover:text-white">Tagihan</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-bold mb-4">Ikuti Kami</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white text-xl"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white text-xl"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white text-xl"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white text-xl"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
                <p>&copy; <?= date('Y') ?> Politeknik Purbaya. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Counter Animation
        function animateCounter(element, target) {
            let current = 0;
            const increment = target / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    element.textContent = target;
                    clearInterval(timer);
                } else {
                    element.textContent = Math.floor(current);
                }
            }, 30);
        }

        // Fetch and animate counters
        fetch('<?= BASE_URL ?>api/counters.php')
            .then(res => res.json())
            .then(data => {
                animateCounter(document.getElementById('counter-mhs'), data.mahasiswa);
                animateCounter(document.getElementById('counter-dosen'), data.dosen);
                animateCounter(document.getElementById('counter-mk'), data.mata_kuliah);
                animateCounter(document.getElementById('counter-prodi'), data.prodi);
            });
    </script>
</body>
</html>



