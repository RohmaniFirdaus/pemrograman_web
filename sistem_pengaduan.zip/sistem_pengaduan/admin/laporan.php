<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

$bulan = isset($_GET['bulan']) ? intval($_GET['bulan']) : date('n');
$tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');

$prev_bulan = $bulan - 1;
$prev_tahun = $tahun;
if ($prev_bulan < 1) {
    $prev_bulan = 12;
    $prev_tahun--;
}

$stats_sekarang = calculateStatistics($bulan, $tahun);

$stats_sebelumnya = calculateStatistics($prev_bulan, $prev_tahun);

$stmt = $pdo->prepare("SELECT * FROM laporan_statistik WHERE periode_bulan = ? AND periode_tahun = ?");
$stmt->execute([$bulan, $tahun]);
$stat_sekarang = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM laporan_statistik WHERE periode_bulan = ? AND periode_tahun = ?");
$stmt->execute([$prev_bulan, $prev_tahun]);
$stat_sebelumnya = $stmt->fetch();

$pageTitle = 'Laporan Per Periode - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Laporan Per Periode</h1>
            <p class="text-gray-600">Laporan UMKM, Pengaduan, dan Surat Menyurat</p>
        </div>
    </div>

    <div class="bg-white rounded-lg p-6 mb-6 shadow-sm border border-gray-200">
        <form method="GET" class="flex items-center gap-4">
            <select name="bulan" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <?php
                $bulan_nama = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                for ($i = 1; $i <= 12; $i++):
                ?>
                    <option value="<?php echo $i; ?>" <?php echo $bulan == $i ? 'selected' : ''; ?>>
                        <?php echo $bulan_nama[$i]; ?>
                    </option>
                <?php endfor; ?>
            </select>
            <select name="tahun" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <?php for ($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                    <option value="<?php echo $i; ?>" <?php echo $tahun == $i ? 'selected' : ''; ?>>
                        <?php echo $i; ?>
                    </option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                <i class="fas fa-search mr-2"></i>Tampilkan Laporan
            </button>
        </form>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">Pengaduan</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang (<?php echo $bulan_nama[$bulan]; ?> <?php echo $tahun; ?>):</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_pengaduan'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya (<?php echo $bulan_nama[$prev_bulan]; ?> <?php echo $prev_tahun; ?>):</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_pengaduan'] ?? 0; ?></span>
                </div>
                <?php
                $perubahan = 0;
                if ($stat_sebelumnya && $stat_sebelumnya['total_pengaduan'] > 0) {
                    $perubahan = (($stat_sekarang['total_pengaduan'] - $stat_sebelumnya['total_pengaduan']) / $stat_sebelumnya['total_pengaduan']) * 100;
                }
                ?>
                <div class="flex justify-between pt-2 border-t">
                    <span>Perubahan:</span>
                    <span class="font-bold <?php echo $perubahan >= 0 ? 'text-blue-600' : 'text-red-600'; ?>">
                        <?php echo $perubahan >= 0 ? '+' : ''; ?><?php echo number_format($perubahan, 0); ?>%
                    </span>
                </div>
            </div>
            <div class="mt-4">
                <table class="w-full text-sm">
                    <tr>
                        <td>Menunggu</td>
                        <td class="text-right"><?php echo $stat_sekarang['pengaduan_menunggu'] ?? 0; ?></td>
                        <td class="text-right text-gray-500"><?php echo $stat_sebelumnya['pengaduan_menunggu'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td>Diproses</td>
                        <td class="text-right"><?php echo $stat_sekarang['pengaduan_diproses'] ?? 0; ?></td>
                        <td class="text-right text-gray-500"><?php echo $stat_sebelumnya['pengaduan_diproses'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td>Selesai</td>
                        <td class="text-right"><?php echo $stat_sekarang['pengaduan_selesai'] ?? 0; ?></td>
                        <td class="text-right text-gray-500"><?php echo $stat_sebelumnya['pengaduan_selesai'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td>Ditolak</td>
                        <td class="text-right"><?php echo $stat_sekarang['pengaduan_ditolak'] ?? 0; ?></td>
                        <td class="text-right text-gray-500"><?php echo $stat_sebelumnya['pengaduan_ditolak'] ?? 0; ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">Surat Menyurat</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang:</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_surat'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya:</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_surat'] ?? 0; ?></span>
                </div>
                <?php
                $perubahan_surat = 0;
                if ($stat_sebelumnya && $stat_sebelumnya['total_surat'] > 0) {
                    $perubahan_surat = (($stat_sekarang['total_surat'] - $stat_sebelumnya['total_surat']) / $stat_sebelumnya['total_surat']) * 100;
                }
                ?>
                <div class="flex justify-between pt-2 border-t">
                    <span>Perubahan:</span>
                    <span class="font-bold <?php echo $perubahan_surat >= 0 ? 'text-blue-600' : 'text-red-600'; ?>">
                        <?php echo $perubahan_surat >= 0 ? '+' : ''; ?><?php echo number_format($perubahan_surat, 0); ?>%
                    </span>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h3 class="text-xl font-bold mb-4 text-gray-800">UMKM</h3>
            <div class="space-y-2">
                <div class="flex justify-between">
                    <span>Periode Sekarang:</span>
                    <span class="font-bold"><?php echo $stat_sekarang['total_umkm'] ?? 0; ?></span>
                </div>
                <div class="flex justify-between">
                    <span>Periode Sebelumnya:</span>
                    <span class="font-bold"><?php echo $stat_sebelumnya['total_umkm'] ?? 0; ?></span>
                </div>
                <div class="pt-2 border-t">
                    <div class="text-sm">Terverifikasi (Sekarang): <?php echo $stat_sekarang['umkm_terverifikasi'] ?? 0; ?></div>
                    <div class="text-sm text-gray-500">Terverifikasi (Sebelumnya): <?php echo $stat_sebelumnya['umkm_terverifikasi'] ?? 0; ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
        <h2 class="text-2xl font-bold mb-4 text-gray-800">Detail Data Periode Sekarang (<?php echo $bulan_nama[$bulan]; ?> <?php echo $tahun; ?>)</h2>
        
        <div class="space-y-6">
            <div>
                <h3 class="font-bold text-lg mb-2">Pengaduan (<?php echo $stat_sekarang['total_pengaduan'] ?? 0; ?> data)</h3>
                <?php if (($stat_sekarang['total_pengaduan'] ?? 0) == 0): ?>
                    <p class="text-gray-500">Tidak ada data pengaduan pada periode ini.</p>
                <?php endif; ?>
            </div>

            <div>
                <h3 class="font-bold text-lg mb-2">Surat Menyurat (<?php echo $stat_sekarang['total_surat'] ?? 0; ?> data)</h3>
                <?php if (($stat_sekarang['total_surat'] ?? 0) == 0): ?>
                    <p class="text-gray-500">Tidak ada data surat pada periode ini.</p>
                <?php endif; ?>
            </div>

            <div>
                <h3 class="font-bold text-lg mb-2">UMKM (<?php echo $stat_sekarang['total_umkm'] ?? 0; ?> data)</h3>
                <?php if (($stat_sekarang['total_umkm'] ?? 0) == 0): ?>
                    <p class="text-gray-500">Tidak ada data UMKM pada periode ini.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="mt-6 text-center">
        <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition">
            <i class="fas fa-print mr-2"></i>Cetak Laporan
        </button>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

