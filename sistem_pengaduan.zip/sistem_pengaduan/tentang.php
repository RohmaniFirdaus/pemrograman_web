<?php
require_once 'includes/auth.php';

$page_title = 'Tentang Aplikasi';
$hide_dashboard_nav = !is_user_logged_in() && !is_admin_logged_in();
$pdo = getConnection();

$tentang = [
    'judul_hero' => 'Tentang Aplikasi',
    'deskripsi_hero' => 'Sistem Pengaduan dan Pelayanan Publik Terpadu Desa Gembong Kulon',
    'konten_aplikasi' => 'Sistem Pengaduan dan Pelayanan Publik Terpadu Desa Gembong Kulon adalah platform berbasis web yang dirancang untuk mempermudah warga dalam menyampaikan aspirasi, keluhan, atau laporan terkait berbagai isu di lingkungan Desa Gembong Kulon.',
    'fitur_1_judul' => 'Pengajuan Pengaduan Mudah', 'fitur_1_deskripsi' => 'Formulir yang intuitif untuk melaporkan masalah dengan cepat dan mudah.', 'fitur_1_icon' => 'fa-check-circle',
    'fitur_2_judul' => 'Pelacakan Status Real-time', 'fitur_2_deskripsi' => 'Pantau perkembangan pengaduan Anda dari "Menunggu" hingga "Selesai" secara real-time.', 'fitur_2_icon' => 'fa-search',
    'fitur_3_judul' => 'Surat Online', 'fitur_3_deskripsi' => 'Ajukan berbagai jenis surat secara online tanpa perlu datang ke kantor desa.', 'fitur_3_icon' => 'fa-file-alt',
    'fitur_4_judul' => 'Informasi Terkini', 'fitur_4_deskripsi' => 'Akses berita desa, informasi UMKM lokal, dan kalender kegiatan desa.', 'fitur_4_icon' => 'fa-newspaper',
    'fitur_5_judul' => 'Keamanan Data', 'fitur_5_deskripsi' => 'Data pribadi Anda terlindungi dengan sistem keamanan yang terjamin.', 'fitur_5_icon' => 'fa-shield-alt',
    'fitur_6_judul' => 'Transparansi Publik', 'fitur_6_deskripsi' => 'Lihat statistik pengaduan dan layanan yang telah diproses.', 'fitur_6_icon' => 'fa-chart-line'
];

try {
    $stmt = $pdo->query("SELECT * FROM tentang_aplikasi ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $tentang = array_merge($tentang, $row);
    }
} catch (PDOException $e) {
    error_log('Tentang aplikasi error: ' . $e->getMessage());
}

$extra_styles = <<<CSS
.tentang-hero {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: #fff;
    padding: 80px 20px;
    text-align: center;
    margin-bottom: 50px;
}

.tentang-hero h1 {
    font-size: 2.8rem;
    margin: 0 0 20px 0;
    color: #fff;
}

.tentang-hero p {
    font-size: 1.3rem;
    opacity: 0.95;
    margin: 0;
}

.tentang-section {
    background: #fff;
    border-radius: 12px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}

.tentang-section h2 {
    color: var(--primary-color);
    font-size: 2rem;
    margin-bottom: 25px;
    text-align: center;
    padding-bottom: 15px;
    border-bottom: 3px solid var(--primary-color);
}

.tentang-section h3 {
    color: var(--primary-color);
    font-size: 1.8rem;
    margin-bottom: 25px;
    text-align: center;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
}

.feature-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.feature-item {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    padding: 25px;
    margin-bottom: 20px;
    background: #f8f9fa;
    border-radius: 10px;
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.feature-item:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.feature-item i {
    font-size: 2.5rem;
    margin-top: 5px;
}

.feature-item.success i { color: var(--success-color); }
.feature-item.primary i { color: var(--primary-color); }
.feature-item.info i { color: var(--info-color); }
.feature-item.warning i { color: var(--warning-color); }

.feature-content h5 {
    font-size: 1.3rem;
    margin: 0 0 10px 0;
    color: var(--primary-color);
}

.feature-content p {
    margin: 0;
    color: #666;
    line-height: 1.7;
}

@media (max-width: 768px) {
    .tentang-hero h1 {
        font-size: 2rem;
    }
    
    .tentang-hero p {
        font-size: 1.1rem;
    }
    
    .tentang-section {
        padding: 25px;
    }
    
    .feature-item {
        flex-direction: column;
        text-align: center;
    }
}
CSS;

include 'includes/header.php';
?>

    <style>
        /* --- CSS Variables & Global Styles --- */
        :root {
            --primary-color: #007bff; /* Biru terang */
            --secondary-color: #6c757d; /* Abu-abu */
            --success-color: #0288d1; /* Biru */
            --danger-color: #dc3545; /* Merah */
            --info-color: #17a2b8; /* Biru muda */
            --warning-color: #ffc107; /* Kuning */
            --light-bg: #f8f9fa; /* Latar belakang abu-abu muda */
            --dark-bg: #343a40; /* Latar belakang abu-abu gelap */
            --text-color: #333; /* Warna teks utama */
            --border-color: #dee2e6; /* Warna border default */
            --box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Bayangan default */
            --transition-speed: 0.3s; /* Kecepatan transisi default */
        }

        /* --- Base Styles --- */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--light-bg);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh; 
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            box-sizing: border-box; 
        }

        .text-center { text-align: center; }
        .text-muted { color: #6c757d; }
        .text-primary { color: var(--primary-color) !important; }
        .text-success { color: var(--success-color) !important; }
        .text-warning { color: var(--warning-color) !important; }
        .text-info { color: var(--info-color) !important; }
        .text-dark { color: var(--dark-bg) !important; }
        .text-white { color: #fff !important; }

        .mb-0 { margin-bottom: 0 !important; }
        .mb-2 { margin-bottom: 0.5rem !important; }
        .mb-3 { margin-bottom: 1rem !important; }
        .mb-4 { margin-bottom: 1.5rem !important; }
        .mb-5 { margin-bottom: 3rem !important; }

        .mt-3 { margin-top: 1rem !important; }
        .mt-4 { margin-top: 1.5rem !important; }
        .mt-5 { margin-top: 3rem !important; }

        .ms-3 { margin-left: 1rem !important; }
        .me-1 { margin-right: 0.25rem !important; }
        .me-2 { margin-right: 0.5rem !important; }

        .py-3 { padding-top: 1rem; padding-bottom: 1rem; }
        .py-4 { padding-top: 1.5rem; padding-bottom: 1.5rem; }
        .py-5 { padding-top: 3rem; padding-bottom: 3rem; }

        .px-4 { padding-left: 1.5rem; padding-right: 1.5rem; }

        .d-flex { display: flex !important; }
        .d-inline-flex { display: inline-flex !important; }
        .justify-content-between { justify-content: space-between !important; }
        .justify-content-center { justify-content: center !important; }
        .align-items-center { align-items: center !important; }
        .align-items-start { align-items: flex-start !important; }
        .flex-wrap { flex-wrap: wrap !important; }
        .gap-3 { gap: 1rem !important; } 

        .fw-bold { font-weight: 700 !important; }
        .fs-4 { font-size: 1.5rem !important; }
        .display-4 { font-size: 2.5rem; } 
        .lead { font-size: 1.25rem; font-weight: 300; } 
        .small { font-size: 0.875em !important; } 
        .text-decoration-none { text-decoration: none !important; }

        .border { border: 1px solid var(--border-color) !important; }
        .border-0 { border: 0 !important; }
        .shadow-sm { box-shadow: 0 .125rem .25rem rgba(0,0,0,.075) !important; }
        .rounded-circle { border-radius: 50% !important; }

        .h-100 { height: 100% !important; } 
        .w-100 { width: 100% !important; }

        .bg-light { background-color: var(--light-bg) !important; }
        .bg-white { background-color: #fff !important; }
        .bg-primary { background-color: var(--primary-color) !important; }
        .bg-warning { background-color: var(--warning-color) !important; }
        .bg-success { background-color: var(--success-color) !important; }


        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 1.1rem;
            font-weight: bold;
            transition: background-color var(--transition-speed) ease, color var(--transition-speed) ease, border-color var(--transition-speed) ease;
            text-align: center;
            white-space: nowrap;
        }

        .btn-primary { background-color: var(--primary-color); color: #fff; }
        .btn-primary:hover { background-color: #0056b3; }

        .btn-secondary { background-color: var(--secondary-color); color: #fff; }
        .btn-secondary:hover { background-color: #5a6268; }

        .btn-success { background-color: var(--success-color); color: #fff; }
        .btn-success:hover { background-color: #0277bd; }

        .btn-danger { background-color: var(--danger-color); color: #fff; }
        .btn-danger:hover { background-color: #c82333; }

        .btn-info { background-color: var(--info-color); color: #fff; }
        .btn-info:hover { background-color: #117a8b; }

        .btn-warning { background-color: var(--warning-color); color: var(--text-color); }
        .btn-warning:hover { background-color: #e0a800; }

        .btn-light { background-color: var(--light-bg); color: var(--text-color); border: 1px solid var(--border-color); }
        .btn-light:hover { background-color: #e2e6ea; }

        .btn-outline-primary {
            background-color: transparent;
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            color: #fff;
        }
        .btn-outline-light {
            background-color: transparent;
            color: #fff;
            border: 1px solid #fff;
        }
        .btn-outline-light:hover {
            background-color: #fff;
            color: var(--primary-color);
        }

        .btn-lg {
            padding: 15px 30px;
            font-size: 1.2rem;
        }

        .btn-sm {
            padding: 8px 15px;
            font-size: 0.9rem;
        }

        .btn-block { 
            display: block;
            width: 100%;
        }

        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
            border: none;
        }

        .card-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
            text-align: center;
        }

        .card-header h2, .card-header h3 {
            color: var(--primary-color);
            font-size: 2rem;
            margin: 0;
        }

        .card-custom {
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
            height: 100%; 
        }
        .card-custom:hover {
            transform: translateY(-5px); 
            box-shadow: 0 8px 16px rgba(0,0,0,0.2); 
        }
        .card-custom .card-body i { 
            margin-bottom: 1rem; 
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: bold;
            color: #fff;
            text-transform: capitalize;
            text-align: center;
            line-height: 1; 
        }
        .status-badge.status-pending { background-color: var(--warning-color); color: var(--text-color); }
        .status-badge.status-diproses { background-color: var(--info-color); }
        .status-badge.status-selesai { background-color: var(--success-color); }
        .status-badge.status-ditolak { background-color: var(--danger-color); }


        .row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px; 
        }
        .row > [class*="col-"] {
            padding-right: 15px;
            padding-left: 15px;
            box-sizing: border-box;
        }

        .col-12 { flex: 0 0 100%; max-width: 100%; }
        .col-6 { flex: 0 0 50%; max-width: 50%; } 

        .hero-section {
            background-color: var(--primary-color);
            color: #fff;
            padding: 80px 0;
            text-align: center;
            margin-bottom: 40px;
        }
        .hero-section h1 {
            font-size: 3.5rem;
            margin-bottom: 15px;
        }
        .hero-section p {
            font-size: 1.4rem;
            opacity: 0.9;
        }
        .hero-section .btn-custom { 
            min-width: 200px;
            font-size: 1.2rem;
            padding: 15px 30px;
        }

        .bg-primary.rounded-circle { background-color: var(--primary-color) !important; color: #fff; }
        .bg-warning.rounded-circle { background-color: var(--warning-color) !important; color: var(--text-color); }
        .bg-success.rounded-circle { background-color: var(--success-color) !important; color: #fff; }

        .cta-section {
            background-color: var(--primary-color);
            color: #fff;
            padding: 50px 0;
            text-align: center;
        }
        .cta-section h3 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        .cta-section p.lead {
            margin-bottom: 1.5rem;
        }
        .cta-section .btn {
            font-size: 1.1rem;
        }
        .cta-section .btn-light {
            color: var(--primary-color);
        }

        .main-header {
            background-color: var(--dark-bg); 
            color: #fff;
            padding: 15px 0;
            box-shadow: var(--box-shadow);
        }

        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .main-header .logo a {
            color: #fff;
            text-decoration: none;
            font-size: 1.8rem;
            font-weight: bold;
        }

        .main-header .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 25px; 
        }

        .main-header .main-nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .main-header .main-nav ul li a:hover,
        .main-header .main-nav ul li a.active {
            background-color: rgba(255, 255, 255, 0.2); 
        }


        @media (min-width: 576px) {
            .col-sm-6 { flex: 0 0 50%; max-width: 50%; }
        }

        @media (min-width: 768px) {
            .col-md-3 { flex: 0 0 25%; max-width: 25%; }
            .col-md-4 { flex: 0 0 33.33333%; max-width: 33.33333%; } 
            .col-md-6 { flex: 0 0 50%; max-width: 50%; }
            .col-md-8 { flex: 0 0 66.66667%; max-width: 66.66667%; }
            .col-md-10 { flex: 0 0 83.33333%; max-width: 83.33333%; }

            .hero-section h1 { font-size: 3.5rem; }
            .hero-section p { font-size: 1.4rem; }
            .cta-section h3 { font-size: 2.5rem; }
        }

        @media (min-width: 992px) {
            .col-lg-3 { flex: 0 0 25%; max-width: 25%; }
            .col-lg-4 { flex: 0 0 33.33333%; max-width: 33.33333%; }
            .col-lg-6 { flex: 0 0 50%; max-width: 50%; }
        }

        @media (max-width: 767.98px) {
            .hero-section {
                padding: 50px 0;
                margin-bottom: 30px;
            }
            .hero-section h1 {
                font-size: 2.2rem;
            }
            .hero-section p {
                font-size: 1rem;
                margin-bottom: 2rem;
            }
            .hero-section .btn-custom {
                width: 100%;
                margin-bottom: 10px;
            }
            .cta-section {
                padding: 40px 0;
            }
            .cta-section h3 {
                font-size: 1.8rem;
            }
            .cta-section .btn {
                width: 100%;
                margin-bottom: 10px;
            }
            .row > [class*="col-"].mb-4 {
                margin-bottom: 15px !important;
            }

            .main-header .main-nav ul {
                flex-direction: column; 
                width: 100%;
                text-align: center;
                gap: 10px; 
                margin-top: 15px; 
            }
            .main-header .main-nav ul li a {
                display: block; 
                padding: 10px 0;
            }
            .main-header .container {
                flex-direction: column; 
            }
        }
    </style>
</head>
<body>
<div class="container my-4">
    <!-- Hero Section -->
    <section class="tentang-hero">
        <div class="container">
            <h1><i class="fas fa-info-circle"></i> <?php echo esc($tentang['judul_hero']); ?></h1>
            <p><?php echo esc($tentang['deskripsi_hero']); ?></p>
        </div>
    </section>

    <!-- Aplikasi Ini Section -->
    <?php if (!empty($tentang['konten_aplikasi'])): ?>
    <div class="tentang-section">
        <h2>Aplikasi Ini</h2>
        <div style="line-height: 1.8; color: #555; font-size: 1.05rem;">
            <?php echo nl2br(esc($tentang['konten_aplikasi'])); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Fitur Unggulan Section -->
    <div class="tentang-section">
        <h3>Fitur Unggulan</h3>
        <ul class="feature-list">
            <?php 
            $feature_classes = ['success', 'primary', 'info', 'warning', 'success', 'primary'];
            for ($i = 1; $i <= 6; $i++): 
                if (!empty($tentang["fitur_{$i}_judul"])):
            ?>
            <li class="feature-item <?php echo $feature_classes[$i-1]; ?>">
                <i class="fas <?php echo esc($tentang["fitur_{$i}_icon"]); ?>"></i>
                <div class="feature-content">
                    <h5><?php echo esc($tentang["fitur_{$i}_judul"]); ?></h5>
                    <p><?php echo esc($tentang["fitur_{$i}_deskripsi"]); ?></p>
                </div>
            </li>
            <?php 
                endif;
            endfor; 
            ?>
        </ul>
    </div>

    <!-- Call to Action -->
    <div style="text-align: center; margin-top: 40px; margin-bottom: 30px;">
        <a href="index.php" class="btn btn-primary btn-lg">
            <i class="fas fa-home"></i> Kembali ke Beranda
        </a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>