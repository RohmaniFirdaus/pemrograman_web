<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

$id = intval($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT p.*, u.nama_lengkap, u.email, u.no_hp, u.alamat, k.nama_kategori 
    FROM pengaduan p 
    LEFT JOIN users u ON p.user_id = u.id 
    LEFT JOIN kategori_pengaduan k ON p.kategori_id = k.id
    WHERE p.id = ?
");
$stmt->execute([$id]);
$pengaduan = $stmt->fetch();

if (!$pengaduan) {
    setFlashMessage('error', 'Pengaduan tidak ditemukan');
    header('Location: ' . BASE_URL . 'admin/pengaduan.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $status = sanitize($_POST['status']);
    $stmt = $pdo->prepare("UPDATE pengaduan SET status = ?, updated_at = NOW() WHERE id = ?");
    if ($stmt->execute([$status, $id])) {
        setFlashMessage('success', 'Status pengaduan berhasil diperbarui');
        header('Location: ' . $_SERVER['PHP_SELF'] . '?id=' . $id);
        exit;
    } else {
        setFlashMessage('error', 'Gagal memperbarui status');
    }
}

$flash = getFlashMessage();
$pageTitle = 'Detail Pengaduan - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-6">
        <a href="<?php echo BASE_URL; ?>admin/pengaduan.php" class="text-blue-600 hover:text-blue-700 mb-4 inline-block">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>

    <?php if ($flash): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $flash['type'] === 'success' ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-500' : 'bg-red-50 text-red-700 border-l-4 border-red-500'; ?>">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-6">
                <div class="flex items-center justify-between mb-4">
                    <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($pengaduan['judul']); ?></h1>
                    <?php echo getStatusBadge($pengaduan['status'], 'pengaduan'); ?>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Kategori</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['nama_kategori'] ?? '-'); ?></p>
                    </div>

                    <div>
                        <label class="text-sm font-semibold text-gray-600">Deskripsi</label>
                        <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($pengaduan['deskripsi']); ?></p>
                    </div>

                    <?php if ($pengaduan['saran']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Saran</label>
                        <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($pengaduan['saran']); ?></p>
                    </div>
                    <?php endif; ?>

                    <?php if ($pengaduan['lokasi_kejadian']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Lokasi Kejadian</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['lokasi_kejadian']); ?></p>
                    </div>
                    <?php endif; ?>

                    <div>
                        <label class="text-sm font-semibold text-gray-600">Prioritas</label>
                        <p class="text-gray-800">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold 
                                <?php 
                                echo $pengaduan['prioritas'] === 'tinggi' ? 'bg-red-100 text-red-800' : 
                                    ($pengaduan['prioritas'] === 'sedang' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'); 
                                ?>">
                                <?php echo ucfirst($pengaduan['prioritas']); ?>
                            </span>
                        </p>
                    </div>

                    <?php if ($pengaduan['bukti_file']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Bukti</label>
                        <div class="mt-2">
                            <?php if ($pengaduan['tipe_bukti'] === 'foto'): ?>
                                <img src="<?php echo upload_url($pengaduan['bukti_file']); ?>" alt="Bukti" class="max-w-full h-auto rounded-lg">
                            <?php elseif ($pengaduan['tipe_bukti'] === 'video'): ?>
                                <video controls class="max-w-full rounded-lg">
                                    <source src="<?php echo upload_url($pengaduan['bukti_file']); ?>" type="video/mp4">
                                </video>
                            <?php else: ?>
                                <a href="<?php echo upload_url($pengaduan['bukti_file']); ?>" target="_blank" class="text-blue-600 hover:text-blue-700">
                                    <i class="fas fa-file-pdf mr-2"></i>Download Dokumen
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div>
            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-6">
                <h2 class="text-xl font-bold mb-4 text-gray-800">Update Status</h2>
                <form method="POST">
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-green-500">
                        <option value="menunggu" <?php echo $pengaduan['status'] === 'menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                        <option value="diproses" <?php echo $pengaduan['status'] === 'diproses' ? 'selected' : ''; ?>>Diproses</option>
                        <option value="selesai" <?php echo $pengaduan['status'] === 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                        <option value="ditolak" <?php echo $pengaduan['status'] === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                    </select>
                    <button type="submit" name="update_status" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition">
                        Update Status
                    </button>
                </form>
            </div>

            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h2 class="text-xl font-bold mb-4 text-gray-800">Informasi Pengadu</h2>
                <div class="space-y-3">
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Nama</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['nama_lengkap']); ?></p>
                    </div>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Email</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['email']); ?></p>
                    </div>
                    <?php if ($pengaduan['no_hp']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">No. HP</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['no_hp']); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ($pengaduan['alamat']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Alamat</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($pengaduan['alamat']); ?></p>
                    </div>
                    <?php endif; ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Tanggal</label>
                        <p class="text-gray-800"><?php echo formatTanggal($pengaduan['created_at'], true); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

