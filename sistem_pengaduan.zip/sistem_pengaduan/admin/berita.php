<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;

$pdo = getConnection();
$page_title = 'Kelola Berita Desa';
$message = '';
$message_type = '';
$can_update = !is_readonly_admin();

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $judul = trim($_POST['judul'] ?? '');
            $konten = $_POST['konten'] ?? '';
            if ($judul && $konten) {
                $gambar = null;
                if (!empty($_FILES['gambar']['name'])) {
                    $dir = dirname(__DIR__) . '/uploads/berita/';
                    if (!is_dir($dir)) mkdir($dir, 0777, true);
                    $ext = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));
                    if (in_array($ext, ['jpg','jpeg','png'], true)) {
                        $filename = uniqid('berita_') . '.' . $ext;
                        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $dir . $filename)) {
                            $gambar = 'berita/' . $filename;
                        }
                    }
                }
                $stmt = $pdo->prepare("
                    INSERT INTO berita_desa (id_user, judul, konten, gambar_utama, is_published, tanggal_publish)
                    VALUES (:user, :judul, :konten, :gambar, :publish, :tanggal)
                ");
                $stmt->execute([
                    'user' => $_SESSION['user_id'],
                    'judul' => $judul,
                    'konten' => $konten,
                    'gambar' => $gambar,
                    'publish' => isset($_POST['publish']) ? 1 : 0,
                    'tanggal' => isset($_POST['publish']) ? date('Y-m-d') : null
                ]);
                $message = 'Berita berhasil disimpan.';
                $message_type = 'success';
            } else {
                $message = 'Judul dan konten wajib diisi.';
                $message_type = 'danger';
            }
        } elseif (in_array($action, ['publish','unpublish','delete'], true)) {
            $id = $_POST['id'] ?? 0;
            if ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM berita_desa WHERE id = :id");
                $stmt->execute(['id' => $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE berita_desa SET is_published = :pub, tanggal_publish = :tgl WHERE id = :id");
                $stmt->execute([
                    'pub' => $action === 'publish' ? 1 : 0,
                    'tgl' => $action === 'publish' ? date('Y-m-d') : null,
                    'id' => $id
                ]);
            }
            $message = 'Perubahan berita berhasil.';
            $message_type = 'success';
        }
    } catch (PDOException $e) {
        error_log('Crud berita error: ' . $e->getMessage());
        $message = 'Terjadi kesalahan.';
        $message_type = 'danger';
    }
}

$berita_list = [];
try {
    $stmt = $pdo->query("
        SELECT b.*, u.nama AS penulis
        FROM berita_desa b
        LEFT JOIN users u ON u.id = b.id_user
        ORDER BY b.created_at DESC
    ");
    $berita_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch berita error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Kelola Berita Desa</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <?php if ($can_update): ?>
        <div class="card mb-4">
            <div class="card-header">Tambah Berita</div>
            <div class="card-body">
                <form action="berita.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label for="judul" class="form-label">Judul</label>
                        <input type="text" id="judul" name="judul" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="konten" class="form-label">Konten</label>
                        <textarea id="konten" name="konten" class="form-control" rows="5" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="gambar" class="form-label">Gambar Utama</label>
                        <input type="file" id="gambar" name="gambar" class="form-control">
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="publish" name="publish">
                        <label class="form-check-label" for="publish">Publikasikan langsung</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Daftar Berita</div>
        <div class="card-body table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <?php if ($can_update): ?><th>Aksi</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($berita_list)): ?>
                        <tr><td colspan="<?php echo $can_update ? 5 : 4; ?>" class="text-center text-muted">Belum ada berita.</td></tr>
                    <?php else: ?>
                        <?php foreach ($berita_list as $item): ?>
                            <tr>
                                <td><?php echo esc($item['judul']); ?></td>
                                <td><?php echo esc($item['penulis'] ?? 'Admin Desa'); ?></td>
                                <td><span class="status-badge status-<?php echo $item['is_published'] ? 'selesai' : 'menunggu'; ?>">
                                    <?php echo $item['is_published'] ? 'Dipublikasi' : 'Draft'; ?>
                                </span></td>
                                <td><?php echo $item['tanggal_publish'] ? date('d M Y', strtotime($item['tanggal_publish'])) : '-'; ?></td>
                                <?php if ($can_update): ?>
                                    <td class="d-flex gap-2">
                                        <form action="berita.php" method="POST" onsubmit="return confirm('Yakin?');">
                                            <input type="hidden" name="id" value="<?php echo esc($item['id']); ?>">
                                            <input type="hidden" name="action" value="<?php echo $item['is_published'] ? 'unpublish' : 'publish'; ?>">
                                            <button class="btn btn-sm btn-outline-primary"><?php echo $item['is_published'] ? 'Draft' : 'Publish'; ?></button>
                                        </form>
                                        <form action="berita.php" method="POST" onsubmit="return confirm('Hapus berita ini?');">
                                            <input type="hidden" name="id" value="<?php echo esc($item['id']); ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>











