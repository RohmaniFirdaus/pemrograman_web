<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Statistik Mahasiswa';
$currentModule = 'laporan';

$conn = getDBConnection();

// Statistik umum
$total_mhs = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'active'")->fetch_assoc()['total'];
$total_cuti = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'cuti'")->fetch_assoc()['total'];
$total_do = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'do'")->fetch_assoc()['total'];
$total_lulus = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'lulus'")->fetch_assoc()['total'];

// Distribusi IPK per Prodi
$distribusi_ipk = $conn->query("
    SELECT p.nama_prodi,
           COUNT(*) as jumlah,
           AVG(m.ipk) as rata_ipk,
           MAX(m.ipk) as max_ipk,
           MIN(m.ipk) as min_ipk
    FROM mahasiswa m
    JOIN program_studi p ON m.prodi_id = p.id
    WHERE m.status = 'active'
    GROUP BY p.id
    ORDER BY rata_ipk DESC
")->fetch_all(MYSQLI_ASSOC);

// Top 10 Mahasiswa by IPK
$top_mahasiswa = $conn->query("
    SELECT m.*, p.nama_prodi
    FROM mahasiswa m
    JOIN program_studi p ON m.prodi_id = p.id
    WHERE m.status = 'active' AND m.ipk > 0
    ORDER BY m.ipk DESC
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Statistik Mahasiswa</h1>
        <a href="export.php?type=mahasiswa" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
    </div>
    
    <!-- Statistik Umum -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Total Mahasiswa Aktif</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= $total_mhs ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Cuti</p>
            <p class="text-3xl font-bold text-yellow-600 mt-2"><?= $total_cuti ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">DO</p>
            <p class="text-3xl font-bold text-red-600 mt-2"><?= $total_do ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Lulus</p>
            <p class="text-3xl font-bold text-blue-600 mt-2"><?= $total_lulus ?></p>
        </div>
    </div>
    
    <!-- Distribusi IPK per Prodi -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Distribusi IPK per Prodi</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Program Studi</th>
                        <th class="px-4 py-2 text-left">Jumlah</th>
                        <th class="px-4 py-2 text-left">Rata-rata IPK</th>
                        <th class="px-4 py-2 text-left">Max IPK</th>
                        <th class="px-4 py-2 text-left">Min IPK</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($distribusi_ipk as $d): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($d['nama_prodi']) ?></td>
                        <td class="px-4 py-2"><?= $d['jumlah'] ?></td>
                        <td class="px-4 py-2"><?= number_format($d['rata_ipk'], 2) ?></td>
                        <td class="px-4 py-2"><?= number_format($d['max_ipk'], 2) ?></td>
                        <td class="px-4 py-2"><?= number_format($d['min_ipk'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Top 10 Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Top 10 Mahasiswa (by IPK)</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Prodi</th>
                        <th class="px-4 py-2 text-left">IPK</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_mahasiswa as $index => $m): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $index + 1 ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($m['nim']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($m['nama_mahasiswa']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($m['nama_prodi']) ?></td>
                        <td class="px-4 py-2 font-semibold text-green-600"><?= number_format($m['ipk'], 2) ?></td>
                        <td class="px-4 py-2"><?= $m['sks_tempuh'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



