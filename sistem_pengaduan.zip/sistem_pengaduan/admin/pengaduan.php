<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;

$page_title = 'Daftar Pengaduan';
$pdo = getConnection();
$status_filter = $_GET['status'] ?? '';
$search_query = trim($_GET['search'] ?? '');

$sql = "
    SELECT p.id, p.kode_pengaduan, p.judul, p.status, p.tanggal_pengaduan,
           kp.nama_kategori, u.nama AS pelapor
    FROM pengaduan p
    LEFT JOIN kategori_pengaduan kp ON kp.id = p.id_kategori
    LEFT JOIN users u ON u.id = p.id_user
    WHERE 1=1
";
$params = [];

if ($status_filter) {
    $sql .= " AND p.status = :status";
    $params['status'] = $status_filter;
}
if ($search_query) {
    $sql .= " AND (p.judul LIKE :search OR p.kode_pengaduan LIKE :search OR kp.nama_kategori LIKE :search)";
    $params['search'] = '%' . $search_query . '%';
}
$sql .= " ORDER BY p.updated_at DESC";

$pengaduan_list = [];
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $pengaduan_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Admin pengaduan error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
        <h2>Pengelolaan Pengaduan</h2>
        <form action="pengaduan.php" method="GET" class="d-flex gap-2">
            <select name="status" class="form-control">
                <option value="">Semua Status</option>
                <?php foreach (['menunggu','diproses','selesai','ditolak'] as $status): ?>
                    <option value="<?php echo $status; ?>" <?php echo ($status_filter === $status ? 'selected' : ''); ?>><?php echo ucfirst($status); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="search" class="form-control" placeholder="Cari..." value="<?php echo esc($search_query); ?>">
            <button class="btn btn-primary">Filter</button>
        </form>
    </div>

    <?php if (empty($pengaduan_list)): ?>
        <div class="alert alert-info">Tidak ada pengaduan.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Pelapor</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pengaduan_list as $p): ?>
                        <tr>
                            <td><?php echo esc($p['kode_pengaduan']); ?></td>
                            <td><?php echo esc($p['judul']); ?></td>
                            <td><?php echo esc($p['nama_kategori'] ?? '-'); ?></td>
                            <td><?php echo esc($p['pelapor'] ?? 'Anonim'); ?></td>
                            <td><span class="status-badge status-<?php echo esc(strtolower($p['status'])); ?>"><?php echo esc(ucfirst($p['status'])); ?></span></td>
                            <td><?php echo date('d M Y', strtotime($p['tanggal_pengaduan'])); ?></td>
                            <td><a href="detail_pengaduan.php?id=<?php echo esc($p['id']); ?>" class="btn btn-outline-primary btn-sm">Detail</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>











