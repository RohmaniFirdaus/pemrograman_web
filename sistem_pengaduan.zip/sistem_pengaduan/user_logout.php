<?php
require_once 'includes/auth.php';

user_logout();
header('Location: user_login.php');
exit;