<?php
require_once '../../config/config.php';
requireRole(['admin']);

$pageTitle = 'Edit Mahasiswa';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mahasiswa = $conn->query("SELECT m.*, u.username FROM mahasiswa m LEFT JOIN users u ON m.user_id = u.id WHERE m.id = $id")->fetch_assoc();
$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);

if (!$mahasiswa) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nim = sanitize($_POST['nim'] ?? '');
    $nama = sanitize($_POST['nama_mahasiswa'] ?? '');
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $dosen_wali_id = intval($_POST['dosen_wali_id'] ?? 0);
    $angkatan = intval($_POST['angkatan'] ?? date('Y'));
    $semester = intval($_POST['semester'] ?? 1);
    $status = $_POST['status'] ?? 'active';
    
    if (empty($nim) || empty($nama) || !$prodi_id) {
        $error = 'Field yang wajib diisi tidak boleh kosong';
    } else {
        // Check if NIM exists for other mahasiswa
        $check = $conn->prepare("SELECT id FROM mahasiswa WHERE nim = ? AND id != ?");
        $check->bind_param("si", $nim, $id);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = 'NIM sudah digunakan';
        } else {
            $stmt = $conn->prepare("UPDATE mahasiswa SET nim = ?, nama_mahasiswa = ?, prodi_id = ?, dosen_wali_id = ?, angkatan = ?, semester = ?, status = ? WHERE id = ?");
            $stmt->bind_param("ssiiissi", $nim, $nama, $prodi_id, $dosen_wali_id, $angkatan, $semester, $status, $id);
            
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Data mahasiswa berhasil diupdate';
                header('Location: index.php?success=1');
                exit;
            } else {
                $error = 'Gagal mengupdate data mahasiswa';
            }
            $stmt->close();
        }
        $check->close();
    }
    $conn->close();
}

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Edit Mahasiswa</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">NIM *</label>
                    <input type="text" name="nim" required value="<?= htmlspecialchars($mahasiswa['nim']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama Mahasiswa *</label>
                    <input type="text" name="nama_mahasiswa" required value="<?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi *</label>
                    <select name="prodi_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= $mahasiswa['prodi_id'] == $p['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($p['nama_prodi']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Dosen Wali</label>
                    <select name="dosen_wali_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Dosen Wali</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= $mahasiswa['dosen_wali_id'] == $d['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($d['nama_dosen']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Angkatan</label>
                    <input type="number" name="angkatan" value="<?= $mahasiswa['angkatan'] ?>" min="2000" max="<?= date('Y') + 1 ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester</label>
                    <input type="number" name="semester" value="<?= $mahasiswa['semester'] ?>" min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">IPK</label>
                    <input type="number" step="0.01" value="<?= $mahasiswa['ipk'] ?>" disabled
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100">
                    <p class="text-xs text-gray-500 mt-1">IPK dihitung otomatis dari nilai</p>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="active" <?= $mahasiswa['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="cuti" <?= $mahasiswa['status'] === 'cuti' ? 'selected' : '' ?>>Cuti</option>
                        <option value="do" <?= $mahasiswa['status'] === 'do' ? 'selected' : '' ?>>DO</option>
                        <option value="lulus" <?= $mahasiswa['status'] === 'lulus' ? 'selected' : '' ?>>Lulus</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Username</label>
                    <input type="text" value="<?= htmlspecialchars($mahasiswa['username'] ?? '') ?>" disabled
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100">
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Update
                </button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



