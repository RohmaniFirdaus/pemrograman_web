<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Prasyarat Mata Kuliah';
$currentModule = 'data-akademik';

$mk_id = intval($_GET['id'] ?? 0);
if (!$mk_id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$mk = $conn->query("SELECT * FROM mata_kuliah WHERE id = $mk_id")->fetch_assoc();
$prasyarat_list = $conn->query("
    SELECT pm.*, mk2.kode_mk, mk2.nama_mk 
    FROM prasyarat_mk pm 
    JOIN mata_kuliah mk2 ON pm.mk_prasyarat_id = mk2.id 
    WHERE pm.mk_id = $mk_id
")->fetch_all(MYSQLI_ASSOC);

// Get all mata kuliah except current
$all_mk = $conn->query("
    SELECT * FROM mata_kuliah 
    WHERE id != $mk_id AND prodi_id = " . $mk['prodi_id'] . " 
    ORDER BY semester, kode_mk
")->fetch_all(MYSQLI_ASSOC);

if (!$mk) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'tambah') {
        $mk_prasyarat_id = intval($_POST['mk_prasyarat_id'] ?? 0);
        if ($mk_prasyarat_id && $mk_prasyarat_id != $mk_id) {
            // Check if already exists
            $check = $conn->query("SELECT id FROM prasyarat_mk WHERE mk_id = $mk_id AND mk_prasyarat_id = $mk_prasyarat_id")->fetch_assoc();
            if (!$check) {
                $conn->query("INSERT INTO prasyarat_mk (mk_id, mk_prasyarat_id) VALUES ($mk_id, $mk_prasyarat_id)");
                $success = 'Prasyarat berhasil ditambahkan';
                header('Location: prasyarat.php?id=' . $mk_id);
                exit;
            } else {
                $error = 'Prasyarat sudah ada';
            }
        }
    } elseif ($action === 'hapus') {
        $prasyarat_id = intval($_POST['prasyarat_id'] ?? 0);
        $conn->query("DELETE FROM prasyarat_mk WHERE id = $prasyarat_id AND mk_id = $mk_id");
        $success = 'Prasyarat berhasil dihapus';
        header('Location: prasyarat.php?id=' . $mk_id);
        exit;
    }
}

$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Prasyarat - <?= htmlspecialchars($mk['nama_mk']) ?></h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- Form Tambah Prasyarat -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Tambah Prasyarat</h2>
        <form method="POST">
            <input type="hidden" name="action" value="tambah">
            <div class="flex gap-4">
                <select name="mk_prasyarat_id" required class="flex-1 px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih Mata Kuliah Prasyarat</option>
                    <?php foreach ($all_mk as $m): ?>
                        <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['kode_mk']) ?> - <?= htmlspecialchars($m['nama_mk']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-plus mr-2"></i>Tambah
                </button>
            </div>
        </form>
    </div>
    
    <!-- List Prasyarat -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Kode MK</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama MK</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($prasyarat_list)): ?>
                        <tr>
                            <td colspan="3" class="px-6 py-4 text-center text-gray-500">Belum ada prasyarat</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($prasyarat_list as $p): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($p['kode_mk']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($p['nama_mk']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <form method="POST" class="inline" onsubmit="return confirm('Hapus prasyarat ini?')">
                                    <input type="hidden" name="action" value="hapus">
                                    <input type="hidden" name="prasyarat_id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



