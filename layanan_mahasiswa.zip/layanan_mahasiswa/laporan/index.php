<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Laporan';
$currentModule = 'laporan';

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Laporan & Statistik</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="dosen.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-chalkboard-teacher text-blue-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Statistik Kinerja Dosen</h2>
                    <p class="text-gray-600 text-sm mt-2">Lihat statistik kinerja dosen</p>
                </div>
            </div>
        </a>
        
        <a href="mahasiswa.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-users text-green-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Statistik Mahasiswa</h2>
                    <p class="text-gray-600 text-sm mt-2">Lihat statistik mahasiswa</p>
                </div>
            </div>
        </a>
        
        <a href="krs-khs.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-clipboard-list text-purple-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Laporan KRS & KHS</h2>
                    <p class="text-gray-600 text-sm mt-2">Laporan KRS dan KHS mahasiswa</p>
                </div>
            </div>
        </a>
        
        <a href="surat.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-envelope text-orange-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Laporan Surat</h2>
                    <p class="text-gray-600 text-sm mt-2">Jumlah arsip surat</p>
                </div>
            </div>
        </a>
        
        <a href="pengaduan.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-exclamation-triangle text-red-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Laporan Pengaduan</h2>
                    <p class="text-gray-600 text-sm mt-2">Statistik pengaduan</p>
                </div>
            </div>
        </a>
        
        <a href="keuangan.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-money-bill-wave text-yellow-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Laporan Keuangan</h2>
                    <p class="text-gray-600 text-sm mt-2">Laporan keuangan dan tagihan</p>
                </div>
            </div>
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



