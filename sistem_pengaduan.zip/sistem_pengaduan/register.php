<?php
require_once 'includes/auth.php';

$page_title = 'Daftar Akun Warga';
$message = '';
$message_type = '';
$form = [
    'nik' => '',
    'nama' => '',
    'email' => '',
    'telepon' => '',
    'alamat' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['nik'] = trim($_POST['nik'] ?? '');
    $form['nama'] = trim($_POST['nama'] ?? '');
    $form['email'] = trim($_POST['email'] ?? '');
    $form['telepon'] = trim($_POST['telepon'] ?? '');
    $form['alamat'] = trim($_POST['alamat'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($form['nik']) || empty($form['nama']) || empty($password) || empty($confirm_password)) {
        $message = 'NIK, Nama, dan Password wajib diisi.';
        $message_type = 'danger';
    } elseif ($password !== $confirm_password) {
        $message = 'Konfirmasi password tidak cocok.';
        $message_type = 'danger';
    } elseif (strlen($password) < 6) {
        $message = 'Password minimal 6 karakter.';
        $message_type = 'danger';
    } else {
        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE nik = :nik OR email = :email");
            $stmt->execute(['nik' => $form['nik'], 'email' => $form['email'] ?: null]);
            if ($stmt->fetchColumn() > 0) {
                $message = 'NIK atau Email sudah terdaftar.';
                $message_type = 'danger';
            } else {
                $foto = null;
                if (!empty($_FILES['foto_profil']['name'])) {
                    $upload_dir = __DIR__ . '/uploads/profil/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    $ext = strtolower(pathinfo($_FILES['foto_profil']['name'], PATHINFO_EXTENSION));
                    $allowed = ['jpg', 'jpeg', 'png'];
                    if (in_array($ext, $allowed, true) && $_FILES['foto_profil']['size'] <= 2 * 1024 * 1024) {
                        $filename = uniqid('profil_') . '.' . $ext;
                        if (move_uploaded_file($_FILES['foto_profil']['tmp_name'], $upload_dir . $filename)) {
                            $foto = 'profil/' . $filename;
                        }
                    }
                }
                $saved = user_register([
                    'nik' => $form['nik'],
                    'nama' => $form['nama'],
                    'email' => $form['email'],
                    'telepon' => $form['telepon'],
                    'alamat' => $form['alamat'],
                    'password' => $password,
                    'role' => 'warga',
                    'foto_profil' => $foto
                ]);

                if ($saved) {
                    $message = 'Registrasi berhasil! Silakan login.';
                    $message_type = 'success';
                    $form = ['nik' => '', 'nama' => '', 'email' => '', 'telepon' => '', 'alamat' => ''];
                } else {
                    $message = 'Registrasi gagal. Silakan coba lagi.';
                    $message_type = 'danger';
                }
            }
        } catch (PDOException $e) {
            error_log('Register error: ' . $e->getMessage());
            $message = 'Terjadi kesalahan pada server.';
            $message_type = 'danger';
        }
    }
}

include 'includes/header.php';
?>

<div class="container card" style="max-width: 600px; margin-top: 40px;">
    <div class="card-header text-center">
        <h2>Buat Akun Sistem Desa</h2>
        <p class="small mb-0">Akses pengaduan dan surat online Desa Gembong Kulon</p>
    </div>
    <form action="register.php" method="POST" enctype="multipart/form-data" class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="form-group mb-3">
            <label for="nik">NIK</label>
            <input type="text" id="nik" name="nik" maxlength="20" required value="<?php echo esc($form['nik']); ?>">
        </div>
        <div class="form-group mb-3">
            <label for="nama">Nama Lengkap</label>
            <input type="text" id="nama" name="nama" required value="<?php echo esc($form['nama']); ?>">
        </div>
        <div class="form-group mb-3">
            <label for="email">Email (opsional)</label>
            <input type="email" id="email" name="email" value="<?php echo esc($form['email']); ?>">
        </div>
        <div class="form-group mb-3">
            <label for="telepon">No. Telepon</label>
            <input type="tel" id="telepon" name="telepon" value="<?php echo esc($form['telepon']); ?>">
        </div>
        <div class="form-group mb-3">
            <label for="alamat">Alamat</label>
            <textarea id="alamat" name="alamat" rows="2"><?php echo esc($form['alamat']); ?></textarea>
        </div>
        <div class="form-group mb-3">
            <label for="foto_profil">Foto Profil (maks 2MB)</label>
            <input type="file" id="foto_profil" name="foto_profil" accept=".jpg,.jpeg,.png">
        </div>
        <div class="form-group mb-3">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group mb-4">
            <label for="confirm_password">Konfirmasi Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block w-100">Daftar Sekarang</button>
        <p class="text-center mt-3">Sudah terdaftar? <a href="user_login.php">Login di sini</a></p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>