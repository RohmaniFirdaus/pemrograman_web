<?php
require_once 'includes/auth.php';

$page_title = 'Cek Status Pengaduan';
$pengaduan = null;
$lampiran = [];
$riwayat_status = [];
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = trim($_POST['tiket'] ?? '');
    if ($kode) {
        header('Location: cek_status.php?tiket=' . urlencode($kode));
        exit;
    }
    $error_message = 'Nomor tiket tidak boleh kosong.';
}

if (!empty($_GET['tiket'])) {
    $kode = $_GET['tiket'];
    $pdo = getConnection();

    try {
        $stmt = $pdo->prepare("
            SELECT p.*, u.nama AS nama_pelapor, k.nama_kategori
            FROM pengaduan p
            LEFT JOIN users u ON u.id = p.id_user
            LEFT JOIN kategori_pengaduan k ON k.id = p.id_kategori
            WHERE p.kode_pengaduan = :kode
        ");
        $stmt->execute(['kode' => $kode]);
        $pengaduan = $stmt->fetch();

        if ($pengaduan) {
            $stmtLampiran = $pdo->prepare("SELECT * FROM lampiran_pengaduan WHERE id_pengaduan = :id");
            $stmtLampiran->execute(['id' => $pengaduan['id']]);
            $lampiran = $stmtLampiran->fetchAll();

            $stmtTanggapan = $pdo->prepare("
                SELECT t.isi_tanggapan, t.created_at, u.nama AS petugas
                FROM tanggapan t
                LEFT JOIN users u ON u.id = t.id_user
                WHERE t.id_pengaduan = :id
                ORDER BY t.created_at ASC
            ");
            $stmtTanggapan->execute(['id' => $pengaduan['id']]);
            $riwayat_status = $stmtTanggapan->fetchAll();
        } else {
            $error_message = 'Pengaduan dengan nomor tiket tersebut tidak ditemukan.';
        }
    } catch (PDOException $e) {
        error_log('Cek status error: ' . $e->getMessage());
        $error_message = 'Terjadi kesalahan saat mencari data.';
    }
}

include 'includes/header.php';
?>

<div class="container card mt-4">
    <div class="card-header text-center">
        <h2>Cek Status Pengaduan</h2>
    </div>
    <div class="card-body">
        <form action="cek_status.php" method="POST" class="mb-3">
            <div class="form-group">
                <label for="tiket">Masukkan Nomor Tiket</label>
                <input type="text" id="tiket" name="tiket" class="form-control" required value="<?php echo esc($_GET['tiket'] ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-primary mt-2">Cek Status</button>
        </form>

        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo esc($error_message); ?></div>
        <?php endif; ?>

        <?php if ($pengaduan): ?>
            <hr>
            <h3><?php echo esc($pengaduan['judul']); ?></h3>
            <p><strong>Nomor Tiket:</strong> <?php echo esc($pengaduan['kode_pengaduan']); ?></p>
            <p><strong>Status:</strong> <span class="status-badge status-<?php echo esc(strtolower($pengaduan['status'])); ?>"><?php echo esc(ucfirst($pengaduan['status'])); ?></span></p>
            <p><strong>Kategori:</strong> <?php echo esc($pengaduan['nama_kategori'] ?? '-'); ?></p>
            <p><strong>Diajukan oleh:</strong> <?php echo esc($pengaduan['nama_pelapor'] ?? 'Anonim'); ?></p>
            <p><strong>Tanggal Pengajuan:</strong> <?php echo date('d M Y', strtotime($pengaduan['tanggal_pengaduan'])); ?></p>
            <p><strong>Deskripsi:</strong><br><?php echo nl2br(esc($pengaduan['deskripsi'])); ?></p>

            <?php if ($lampiran): ?>
                <h5>Lampiran</h5>
                <ul>
                    <?php foreach ($lampiran as $file): ?>
                        <li><a href="uploads/<?php echo esc($file['path_file']); ?>" target="_blank"><?php echo esc($file['nama_file']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <h4>Riwayat Tanggapan</h4>
            <?php if (empty($riwayat_status)): ?>
                <p class="text-muted">Belum ada tanggapan dari petugas.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php foreach ($riwayat_status as $tanggapan): ?>
                        <li class="list-group-item">
                            <strong><?php echo esc($tanggapan['petugas'] ?? 'Petugas Desa'); ?></strong>
                            <small class="text-muted d-block"><?php echo date('d M Y H:i', strtotime($tanggapan['created_at'])); ?></small>
                            <p class="mb-0"><?php echo nl2br(esc($tanggapan['isi_tanggapan'])); ?></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>