<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa']);

$pageTitle = 'Pengaduan';
$currentModule = 'pengaduan';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $pengaduan_list = $conn->query("
        SELECT * FROM pengaduan 
        WHERE mahasiswa_id = " . $mahasiswa['id'] . " 
        ORDER BY created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin view
    $filter_status = $_GET['status'] ?? '';
    $filter_prioritas = $_GET['prioritas'] ?? '';
    $search = $_GET['search'] ?? '';
    
    $query = "SELECT p.*, m.nim, m.nama_mahasiswa FROM pengaduan p JOIN mahasiswa m ON p.mahasiswa_id = m.id WHERE 1=1";
    
    if ($filter_status) {
        $query .= " AND p.status = '" . $conn->real_escape_string($filter_status) . "'";
    }
    if ($filter_prioritas) {
        $query .= " AND p.prioritas = '" . $conn->real_escape_string($filter_prioritas) . "'";
    }
    if ($search) {
        $query .= " AND (p.judul_pengaduan LIKE '%" . $conn->real_escape_string($search) . "%' OR m.nim LIKE '%" . $conn->real_escape_string($search) . "%')";
    }
    
    $query .= " ORDER BY p.created_at DESC";
    $pengaduan_list = $conn->query($query)->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Pengaduan</h1>
        <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
        <a href="buat.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Buat Pengaduan
        </a>
        <?php endif; ?>
    </div>
    
    <!-- Filter (Admin) -->
    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Status</option>
                <option value="menunggu" <?= ($_GET['status'] ?? '') === 'menunggu' ? 'selected' : '' ?>>Menunggu</option>
                <option value="diproses" <?= ($_GET['status'] ?? '') === 'diproses' ? 'selected' : '' ?>>Diproses</option>
                <option value="selesai" <?= ($_GET['status'] ?? '') === 'selesai' ? 'selected' : '' ?>>Selesai</option>
                <option value="escalated" <?= ($_GET['status'] ?? '') === 'escalated' ? 'selected' : '' ?>>Escalated</option>
            </select>
            <select name="prioritas" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Prioritas</option>
                <option value="high" <?= ($_GET['prioritas'] ?? '') === 'high' ? 'selected' : '' ?>>High</option>
                <option value="medium" <?= ($_GET['prioritas'] ?? '') === 'medium' ? 'selected' : '' ?>>Medium</option>
                <option value="low" <?= ($_GET['prioritas'] ?? '') === 'low' ? 'selected' : '' ?>>Low</option>
            </select>
            <input type="text" name="search" placeholder="Cari judul/NIM..." 
                   value="<?= htmlspecialchars($_GET['search'] ?? '') ?>"
                   class="px-4 py-2 border border-gray-300 rounded-lg">
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- Pengaduan List -->
    <div class="space-y-4">
        <?php if (empty($pengaduan_list)): ?>
            <div class="bg-white rounded-lg shadow p-8 text-center text-gray-500">
                Tidak ada pengaduan
            </div>
        <?php else: ?>
            <?php foreach ($pengaduan_list as $p): ?>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex justify-between items-start mb-4">
                    <div class="flex-1">
                        <div class="flex items-center space-x-3 mb-2">
                            <h3 class="text-lg font-bold text-gray-800">
                                #<?= htmlspecialchars($p['kode_pengaduan']) ?> - <?= htmlspecialchars($p['judul_pengaduan']) ?>
                            </h3>
                            <?= getStatusBadge($p['status']) ?>
                            <span class="px-2 py-1 rounded text-xs font-semibold <?= 
                                $p['prioritas'] === 'high' ? 'bg-red-100 text-red-700' : 
                                ($p['prioritas'] === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700')
                            ?>">
                                <?= strtoupper($p['prioritas']) ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-600 mb-2">
                            <i class="fas fa-tag mr-1"></i><?= htmlspecialchars($p['kategori']) ?>
                            <?php if ($p['sub_kategori']): ?>
                                - <?= htmlspecialchars($p['sub_kategori']) ?>
                            <?php endif; ?>
                        </p>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <p class="text-sm text-gray-600">
                            <i class="fas fa-user mr-1"></i><?= htmlspecialchars($p['nim']) ?> - <?= htmlspecialchars($p['nama_mahasiswa']) ?>
                        </p>
                        <?php endif; ?>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="far fa-calendar mr-1"></i>Dibuat: <?= formatTanggalWaktu($p['created_at']) ?>
                        </p>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="detail.php?id=<?= $p['id'] ?>" class="text-green-600 hover:text-green-700">
                        <i class="fas fa-eye mr-1"></i>Lihat Detail
                    </a>
                    <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
                    <a href="track.php?id=<?= $p['id'] ?>" class="ml-4 text-blue-600 hover:text-blue-700">
                        <i class="fas fa-map-marked-alt mr-1"></i>Track
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



