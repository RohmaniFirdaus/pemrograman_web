<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen', 'pimpinan']);

$pageTitle = 'Surat';
$currentModule = 'surat';

$user = getCurrentUser();
$conn = getDBConnection();

$filter_jenis = $_GET['jenis'] ?? '';
$filter_status = $_GET['status'] ?? '';
$filter_tujuan = $_GET['tujuan'] ?? '';

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $query = "SELECT s.* FROM surat s WHERE s.mahasiswa_id = " . $mahasiswa['id'];
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    $query = "SELECT s.*, m.nim, m.nama_mahasiswa FROM surat s 
              JOIN mahasiswa m ON s.mahasiswa_id = m.id 
              WHERE s.tujuan = 'dosen' AND s.tujuan_id = " . $dosen['id'];
} elseif ($_SESSION['role'] === 'pimpinan') {
    $pimpinan = $conn->query("SELECT id FROM pimpinan WHERE user_id = " . $user['id'])->fetch_assoc();
    $query = "SELECT s.*, m.nim, m.nama_mahasiswa FROM surat s 
              JOIN mahasiswa m ON s.mahasiswa_id = m.id 
              WHERE s.tujuan = 'pimpinan' AND s.tujuan_id = " . $pimpinan['id'];
} else {
    // Admin
    $query = "SELECT s.*, m.nim, m.nama_mahasiswa FROM surat s 
              LEFT JOIN mahasiswa m ON s.mahasiswa_id = m.id 
              WHERE 1=1";
}

if ($filter_jenis) {
    $query .= " AND s.jenis = '" . $conn->real_escape_string($filter_jenis) . "'";
}
if ($filter_status) {
    $query .= " AND s.status = '" . $conn->real_escape_string($filter_status) . "'";
}
if ($filter_tujuan && $_SESSION['role'] === 'admin') {
    $query .= " AND s.tujuan = '" . $conn->real_escape_string($filter_tujuan) . "'";
}

$query .= " ORDER BY s.created_at DESC";
$surat_list = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Surat</h1>
        <?php if ($_SESSION['role'] === 'mahasiswa'): ?>
        <a href="buat.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-plus mr-2"></i>Buat Surat
        </a>
        <?php endif; ?>
    </div>
    
    <!-- Filter (Admin) -->
    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="jenis" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Jenis</option>
                <option value="masuk" <?= $filter_jenis === 'masuk' ? 'selected' : '' ?>>Masuk</option>
                <option value="keluar" <?= $filter_jenis === 'keluar' ? 'selected' : '' ?>>Keluar</option>
            </select>
            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Status</option>
                <option value="menunggu" <?= $filter_status === 'menunggu' ? 'selected' : '' ?>>Menunggu</option>
                <option value="diproses" <?= $filter_status === 'diproses' ? 'selected' : '' ?>>Diproses</option>
                <option value="approved" <?= $filter_status === 'approved' ? 'selected' : '' ?>>Approved</option>
                <option value="ditolak" <?= $filter_status === 'ditolak' ? 'selected' : '' ?>>Ditolak</option>
            </select>
            <select name="tujuan" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Tujuan</option>
                <option value="admin" <?= $filter_tujuan === 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="dosen" <?= $filter_tujuan === 'dosen' ? 'selected' : '' ?>>Dosen</option>
                <option value="pimpinan" <?= $filter_tujuan === 'pimpinan' ? 'selected' : '' ?>>Pimpinan</option>
            </select>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- List Surat -->
    <div class="space-y-4">
        <?php if (empty($surat_list)): ?>
            <div class="bg-white rounded-lg shadow p-8 text-center text-gray-500">
                Tidak ada surat
            </div>
        <?php else: ?>
            <?php foreach ($surat_list as $s): ?>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex justify-between items-start mb-4">
                    <div class="flex-1">
                        <div class="flex items-center space-x-3 mb-2">
                            <h3 class="text-lg font-bold text-gray-800">
                                <?= htmlspecialchars($s['nomor_surat'] ?? 'Belum ada nomor') ?>
                            </h3>
                            <?= getStatusBadge($s['status']) ?>
                            <span class="px-2 py-1 rounded text-xs <?= $s['jenis'] === 'masuk' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700' ?>">
                                <?= ucfirst($s['jenis']) ?>
                            </span>
                        </div>
                        <p class="font-semibold text-gray-800 mb-2"><?= htmlspecialchars($s['perihal']) ?></p>
                        <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
                        <p class="text-sm text-gray-600">
                            <i class="fas fa-user mr-1"></i><?= htmlspecialchars($s['nim'] ?? '') ?> - <?= htmlspecialchars($s['nama_mahasiswa'] ?? '') ?>
                        </p>
                        <?php endif; ?>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="far fa-calendar mr-1"></i><?= formatTanggalWaktu($s['created_at']) ?>
                            <?php if ($s['tujuan']): ?>
                            | Tujuan: <?= ucfirst($s['tujuan']) ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="detail.php?id=<?= $s['id'] ?>" class="text-green-600 hover:text-green-700">
                        <i class="fas fa-eye mr-1"></i>Lihat Detail
                    </a>
                    <?php if (in_array($_SESSION['role'], ['admin', 'dosen', 'pimpinan']) && $s['status'] === 'menunggu'): ?>
                    <a href="review.php?id=<?= $s['id'] ?>" class="ml-4 text-blue-600 hover:text-blue-700">
                        <i class="fas fa-check mr-1"></i>Review
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



