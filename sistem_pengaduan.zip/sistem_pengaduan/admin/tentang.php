<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = sanitize($_POST['judul'] ?? '');
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');
    $versi = sanitize($_POST['versi'] ?? '');
    $pengembang = sanitize($_POST['pengembang'] ?? '');
    
    $logo_aplikasi = null;
    if (isset($_FILES['logo_aplikasi']) && $_FILES['logo_aplikasi']['error'] === UPLOAD_ERR_OK) {
        $upload = uploadFile($_FILES['logo_aplikasi'], 'profil', ALLOWED_IMAGE_TYPES);
        if ($upload['success']) {
            $logo_aplikasi = $upload['path'];
        }
    }
    
    $stmt = $pdo->query("SELECT id FROM tentang_aplikasi LIMIT 1");
    $exists = $stmt->fetch();
    
    if ($exists) {
        if ($logo_aplikasi) {
            $stmt = $pdo->prepare("UPDATE tentang_aplikasi SET judul = ?, deskripsi = ?, versi = ?, pengembang = ?, logo_aplikasi = ? WHERE id = ?");
            $stmt->execute([$judul, $deskripsi, $versi, $pengembang, $logo_aplikasi, $exists['id']]);
        } else {
            $stmt = $pdo->prepare("UPDATE tentang_aplikasi SET judul = ?, deskripsi = ?, versi = ?, pengembang = ? WHERE id = ?");
            $stmt->execute([$judul, $deskripsi, $versi, $pengembang, $exists['id']]);
        }
        setFlashMessage('success', 'Informasi aplikasi berhasil diperbarui.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO tentang_aplikasi (judul, deskripsi, versi, pengembang, logo_aplikasi) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$judul, $deskripsi, $versi, $pengembang, $logo_aplikasi]);
        setFlashMessage('success', 'Informasi aplikasi berhasil ditambahkan.');
    }
    
    header('Location: tentang.php');
    exit;
}

$stmt = $pdo->query("SELECT * FROM tentang_aplikasi LIMIT 1");
$tentang = $stmt->fetch();

$pageTitle = 'Kelola Tentang Aplikasi - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Kelola Tentang Aplikasi</h1>

    <form method="POST" enctype="multipart/form-data" class="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Judul</label>
            <input type="text" name="judul" value="<?php echo htmlspecialchars($tentang['judul'] ?? ''); ?>" 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
            <textarea name="deskripsi" rows="6" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($tentang['deskripsi'] ?? ''); ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Versi</label>
                <input type="text" name="versi" value="<?php echo htmlspecialchars($tentang['versi'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Pengembang</label>
                <input type="text" name="pengembang" value="<?php echo htmlspecialchars($tentang['pengembang'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Logo Aplikasi</label>
            <?php if ($tentang && $tentang['logo_aplikasi']): ?>
                <img src="<?php echo upload_url($tentang['logo_aplikasi']); ?>" alt="Logo" class="w-32 h-32 object-cover rounded mb-2">
            <?php endif; ?>
            <input type="file" name="logo_aplikasi" accept="image/*" 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
            Simpan
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>



