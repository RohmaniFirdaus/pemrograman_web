<?php
require_once 'includes/auth.php';

$page_title = 'Profil Desa';
$pdo = getConnection();

// Ambil data profil desa dari database
$profil = [
    'nama_desa' => 'Desa Gembong Kulon',
    'alamat_desa' => 'Kecamatan Talang, Kabupaten Tegal',
    'telepon_desa' => '0283-123456',
    'email_desa' => 'info@desagembongkulon.id',
    'deskripsi_desa' => 'Portal pelayanan publik terpadu untuk pengaduan, surat online, berita, UMKM, dan kalender kegiatan Desa Gembong Kulon.',
    'visi_misi' => 'Visi: Desa maju, mandiri, dan sejahtera. Misi: Pelayanan prima, transparansi data, dan partisipasi aktif masyarakat.',
    'sejarah_desa' => ''
];

try {
    $stmt = $pdo->query("SELECT * FROM profil_desa ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $profil = array_merge($profil, $row);
    }
} catch (PDOException $e) {
    error_log('Profil desa error: ' . $e->getMessage());
}

$extra_styles = <<<CSS
.profil-desa-container {
    max-width: 1000px;
    margin: 0 auto;
}

.profil-hero {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: #fff;
    padding: 60px 20px;
    text-align: center;
    border-radius: 15px;
    margin-bottom: 40px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.profil-hero h1 {
    font-size: 2.5rem;
    margin: 0 0 15px 0;
    color: #fff;
}

.profil-hero p {
    font-size: 1.2rem;
    opacity: 0.95;
    margin: 0;
}

.profil-section {
    background: #fff;
    border-radius: 12px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}

.profil-section-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 3px solid var(--primary-color);
}

.profil-section-header i {
    font-size: 2rem;
    color: var(--primary-color);
}

.profil-section-header h2 {
    color: var(--primary-color);
    font-size: 1.8rem;
    margin: 0;
}

.profil-content {
    line-height: 1.8;
    color: #555;
    font-size: 1.05rem;
}

.profil-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 25px;
}

.profil-info-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 10px;
    border-left: 4px solid var(--primary-color);
}

.profil-info-item i {
    font-size: 1.5rem;
    color: var(--primary-color);
    margin-top: 5px;
}

.profil-info-item-content h4 {
    margin: 0 0 8px 0;
    color: var(--primary-color);
    font-size: 1rem;
}

.profil-info-item-content p {
    margin: 0;
    color: #666;
    font-size: 0.95rem;
}

.visi-misi-box {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 25px;
    border-radius: 10px;
    border-left: 5px solid var(--accent-color);
    margin-top: 20px;
}

.visi-misi-box h3 {
    color: var(--primary-color);
    margin-bottom: 15px;
    font-size: 1.3rem;
}

.visi-misi-box p {
    margin: 10px 0;
    line-height: 1.8;
    color: #555;
}

@media (max-width: 768px) {
    .profil-hero h1 {
        font-size: 1.8rem;
    }
    
    .profil-hero p {
        font-size: 1rem;
    }
    
    .profil-section {
        padding: 25px;
    }
    
    .profil-info-grid {
        grid-template-columns: 1fr;
    }
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4 profil-desa-container">
    <!-- Hero Section -->
    <div class="profil-hero">
        <h1><i class="fas fa-village"></i> <?php echo esc($profil['nama_desa']); ?></h1>
        <p><?php echo esc($profil['alamat_desa']); ?></p>
    </div>

    <!-- Deskripsi Desa -->
    <?php if (!empty($profil['deskripsi_desa'])): ?>
    <div class="profil-section">
        <div class="profil-section-header">
            <i class="fas fa-info-circle"></i>
            <h2>Tentang Desa</h2>
        </div>
        <div class="profil-content">
            <?php echo nl2br(esc($profil['deskripsi_desa'])); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Visi & Misi -->
    <?php if (!empty($profil['visi_misi'])): ?>
    <div class="profil-section">
        <div class="profil-section-header">
            <i class="fas fa-bullseye"></i>
            <h2>Visi & Misi</h2>
        </div>
        <div class="visi-misi-box">
            <?php 
            $visi_misi = $profil['visi_misi'];
            if (stripos($visi_misi, 'Visi:') !== false || stripos($visi_misi, 'Misi:') !== false) {
                $parts = preg_split('/(Visi:|Misi:)/i', $visi_misi, -1, PREG_SPLIT_DELIM_CAPTURE);
                foreach ($parts as $part) {
                    $part = trim($part);
                    if (empty($part)) continue;
                    if (stripos($part, 'Visi') === 0 || stripos($part, 'Misi') === 0) {
                        echo '<h3>' . esc($part) . '</h3>';
                    } else {
                        echo '<p>' . nl2br(esc($part)) . '</p>';
                    }
                }
            } else {
                echo '<p>' . nl2br(esc($visi_misi)) . '</p>';
            }
            ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Informasi Kontak -->
    <div class="profil-section">
        <div class="profil-section-header">
            <i class="fas fa-address-card"></i>
            <h2>Informasi Kontak</h2>
        </div>
        <div class="profil-info-grid">
            <?php if (!empty($profil['alamat_desa'])): ?>
            <div class="profil-info-item">
                <i class="fas fa-map-marker-alt"></i>
                <div class="profil-info-item-content">
                    <h4>Alamat</h4>
                    <p><?php echo esc($profil['alamat_desa']); ?></p>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($profil['telepon_desa'])): ?>
            <div class="profil-info-item">
                <i class="fas fa-phone"></i>
                <div class="profil-info-item-content">
                    <h4>Telepon</h4>
                    <p><?php echo esc($profil['telepon_desa']); ?></p>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($profil['email_desa'])): ?>
            <div class="profil-info-item">
                <i class="fas fa-envelope"></i>
                <div class="profil-info-item-content">
                    <h4>Email</h4>
                    <p><a href="mailto:<?php echo esc($profil['email_desa']); ?>" style="color: var(--primary-color); text-decoration: none;"><?php echo esc($profil['email_desa']); ?></a></p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sejarah Desa -->
    <?php if (!empty($profil['sejarah_desa'])): ?>
    <div class="profil-section">
        <div class="profil-section-header">
            <i class="fas fa-book"></i>
            <h2>Sejarah Desa</h2>
        </div>
        <div class="profil-content">
            <?php echo nl2br(esc($profil['sejarah_desa'])); ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>




