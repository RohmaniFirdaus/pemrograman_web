<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $judul_acara = sanitize($_POST['judul_acara'] ?? '');
        $deskripsi = sanitize($_POST['deskripsi'] ?? '');
        $jenis_acara = sanitize($_POST['jenis_acara'] ?? 'kegiatan');
        $tanggal_mulai = sanitize($_POST['tanggal_mulai'] ?? '');
        $tanggal_selesai = sanitize($_POST['tanggal_selesai'] ?? '');
        $waktu_mulai = sanitize($_POST['waktu_mulai'] ?? '');
        $waktu_selesai = sanitize($_POST['waktu_selesai'] ?? '');
        $lokasi = sanitize($_POST['lokasi'] ?? '');
        
        if (empty($judul_acara) || empty($tanggal_mulai)) {
            setFlashMessage('error', 'Judul acara dan tanggal mulai harus diisi.');
        } else {
            if ($action === 'create') {
                $stmt = $pdo->prepare("
                    INSERT INTO kalender_kegiatan (judul_acara, deskripsi, jenis_acara, tanggal_mulai, tanggal_selesai, waktu_mulai, waktu_selesai, lokasi) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$judul_acara, $deskripsi, $jenis_acara, $tanggal_mulai, $tanggal_selesai ?: null, $waktu_mulai ?: null, $waktu_selesai ?: null, $lokasi]);
                setFlashMessage('success', 'Kegiatan berhasil ditambahkan.');
            } else {
                $stmt = $pdo->prepare("
                    UPDATE kalender_kegiatan SET judul_acara = ?, deskripsi = ?, jenis_acara = ?, tanggal_mulai = ?, tanggal_selesai = ?, waktu_mulai = ?, waktu_selesai = ?, lokasi = ? 
                    WHERE id = ?
                ");
                $stmt->execute([$judul_acara, $deskripsi, $jenis_acara, $tanggal_mulai, $tanggal_selesai ?: null, $waktu_mulai ?: null, $waktu_selesai ?: null, $lokasi, $id]);
                setFlashMessage('success', 'Kegiatan berhasil diperbarui.');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM kalender_kegiatan WHERE id = ?");
        $stmt->execute([$id]);
        setFlashMessage('success', 'Kegiatan berhasil dihapus.');
    }
    header('Location: kalender.php');
    exit;
}

$stmt = $pdo->query("SELECT * FROM kalender_kegiatan ORDER BY tanggal_mulai DESC, waktu_mulai DESC");
$events = $stmt->fetchAll();

$edit_event = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM kalender_kegiatan WHERE id = ?");
    $stmt->execute([$id]);
    $edit_event = $stmt->fetch();
}

$pageTitle = 'Kelola Kalender - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Kelola Kalender Kegiatan</h1>
            <p class="text-gray-600">Manajemen agenda desa</p>
        </div>
        <button onclick="document.getElementById('formModal').classList.remove('hidden')" 
                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
            <i class="fas fa-plus mr-2"></i>Tambah Kegiatan
        </button>
    </div>

    <div class="space-y-4">
        <?php foreach ($events as $event): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <h3 class="text-xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($event['judul_acara']); ?></h3>
                        <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($event['deskripsi']); ?></p>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                            <div><i class="fas fa-calendar mr-2"></i><?php echo formatTanggal($event['tanggal_mulai']); ?></div>
                            <?php if ($event['waktu_mulai']): ?>
                                <div><i class="fas fa-clock mr-2"></i><?php echo date('H:i', strtotime($event['waktu_mulai'])); ?></div>
                            <?php endif; ?>
                            <?php if ($event['lokasi']): ?>
                                <div><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($event['lokasi']); ?></div>
                            <?php endif; ?>
                            <div><i class="fas fa-tag mr-2"></i><?php echo ucfirst($event['jenis_acara']); ?></div>
                        </div>
                    </div>
                    <div class="flex gap-2 ml-4">
                        <a href="?edit=<?php echo $event['id']; ?>" class="text-blue-600 hover:text-blue-700">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form method="POST" class="inline" onsubmit="return confirm('Yakin hapus kegiatan ini?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $event['id']; ?>">
                            <button type="submit" class="text-red-600 hover:text-red-700">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div id="formModal" class="<?php echo $edit_event ? '' : 'hidden'; ?> fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800"><?php echo $edit_event ? 'Edit' : 'Tambah'; ?> Kegiatan</h2>
            <button onclick="document.getElementById('formModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="<?php echo $edit_event ? 'update' : 'create'; ?>">
            <?php if ($edit_event): ?>
                <input type="hidden" name="id" value="<?php echo $edit_event['id']; ?>">
            <?php endif; ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Judul Acara *</label>
                <input type="text" name="judul_acara" value="<?php echo htmlspecialchars($edit_event['judul_acara'] ?? ''); ?>" required 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
                <textarea name="deskripsi" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($edit_event['deskripsi'] ?? ''); ?></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Jenis Acara</label>
                    <select name="jenis_acara" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="rapat" <?php echo ($edit_event['jenis_acara'] ?? '') === 'rapat' ? 'selected' : ''; ?>>Rapat</option>
                        <option value="kegiatan" <?php echo ($edit_event['jenis_acara'] ?? '') === 'kegiatan' ? 'selected' : ''; ?>>Kegiatan</option>
                        <option value="hari_penting" <?php echo ($edit_event['jenis_acara'] ?? '') === 'hari_penting' ? 'selected' : ''; ?>>Hari Penting</option>
                        <option value="lainnya" <?php echo ($edit_event['jenis_acara'] ?? '') === 'lainnya' ? 'selected' : ''; ?>>Lainnya</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Mulai *</label>
                    <input type="date" name="tanggal_mulai" value="<?php echo $edit_event['tanggal_mulai'] ?? ''; ?>" required 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" value="<?php echo $edit_event['tanggal_selesai'] ?? ''; ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Lokasi</label>
                    <input type="text" name="lokasi" value="<?php echo htmlspecialchars($edit_event['lokasi'] ?? ''); ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Waktu Mulai</label>
                    <input type="time" name="waktu_mulai" value="<?php echo $edit_event['waktu_mulai'] ?? ''; ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Waktu Selesai</label>
                    <input type="time" name="waktu_selesai" value="<?php echo $edit_event['waktu_selesai'] ?? ''; ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">Simpan</button>
                <button type="button" onclick="document.getElementById('formModal').classList.add('hidden')" 
                        class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition">Batal</button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>



