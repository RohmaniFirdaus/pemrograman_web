<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'pimpinan']);

$pageTitle = 'Detail Tagihan';
$currentModule = 'tagihan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$tagihan = $conn->query("
    SELECT t.*, m.nim, m.nama_mahasiswa, m.prodi_id, p.nama_prodi
    FROM tagihan t 
    JOIN mahasiswa m ON t.mahasiswa_id = m.id 
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    WHERE t.id = $id
")->fetch_assoc();

if (!$tagihan) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($tagihan['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get detail tagihan
$detail_tagihan = $conn->query("
    SELECT * FROM detail_tagihan 
    WHERE tagihan_id = $id
")->fetch_all(MYSQLI_ASSOC);

// Get riwayat pembayaran
$riwayat = $conn->query("
    SELECT * FROM pembayaran 
    WHERE tagihan_id = $id 
    ORDER BY created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Tagihan</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Tagihan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Tagihan</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($tagihan['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama Mahasiswa</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($tagihan['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($tagihan['nama_prodi']) ?></p>
            </div>
            <?php endif; ?>
            <div>
                <p class="text-gray-600 text-sm">Nomor Tagihan</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($tagihan['nomor_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jenis Tagihan</p>
                <p class="font-semibold text-gray-800">
                    <?php
                    $jenis = [
                        'ukt_reguler' => 'UKT Reguler',
                        'beasiswa_penuh' => 'Beasiswa Penuh',
                        'beasiswa_50' => 'Beasiswa 50%'
                    ];
                    echo $jenis[$tagihan['jenis_tagihan']] ?? $tagihan['jenis_tagihan'];
                    ?>
                </p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $tagihan['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Tahun Akademik</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($tagihan['tahun_akademik']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Total Tagihan</p>
                <p class="font-semibold text-gray-800 text-xl"><?= formatRupiah($tagihan['total_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Total Bayar</p>
                <p class="font-semibold text-gray-800 text-xl text-green-600"><?= formatRupiah($tagihan['total_bayar']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Sisa Tagihan</p>
                <p class="font-semibold text-gray-800 text-xl text-red-600"><?= formatRupiah($tagihan['sisa_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jatuh Tempo</p>
                <p class="font-semibold text-gray-800"><?= formatTanggal($tagihan['jatuh_tempo']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Denda</p>
                <p class="font-semibold text-gray-800"><?= formatRupiah($tagihan['denda']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($tagihan['status']) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Detail Komponen -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Detail Komponen</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Komponen</th>
                        <th class="px-4 py-2 text-left">Nominal</th>
                        <th class="px-4 py-2 text-left">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($detail_tagihan)): ?>
                        <tr>
                            <td colspan="3" class="px-4 py-4 text-center text-gray-500">Tidak ada detail komponen</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($detail_tagihan as $d): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($d['komponen']) ?></td>
                            <td class="px-4 py-2"><?= formatRupiah($d['nominal']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($d['keterangan'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Riwayat Pembayaran -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Riwayat Pembayaran</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                        <th class="px-4 py-2 text-left">Nomor Pembayaran</th>
                        <th class="px-4 py-2 text-left">Metode</th>
                        <th class="px-4 py-2 text-left">Nominal</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($riwayat)): ?>
                        <tr>
                            <td colspan="6" class="px-4 py-4 text-center text-gray-500">Belum ada pembayaran</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($riwayat as $r): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= formatTanggalWaktu($r['created_at']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($r['nomor_pembayaran']) ?></td>
                            <td class="px-4 py-2">
                                <?php
                                $metode = [
                                    'transfer_bank' => 'Transfer Bank',
                                    'e_wallet' => 'E-Wallet',
                                    'qris' => 'QRIS',
                                    'credit_card' => 'Credit Card'
                                ];
                                echo $metode[$r['metode_pembayaran']] ?? $r['metode_pembayaran'];
                                ?>
                            </td>
                            <td class="px-4 py-2"><?= formatRupiah($r['nominal']) ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($r['status']) ?></td>
                            <td class="px-4 py-2">
                                <?php if ($r['status'] === 'success' && $r['e_receipt']): ?>
                                <a href="<?= BASE_URL . htmlspecialchars($r['e_receipt']) ?>" target="_blank" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-download"></i> Receipt
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Action -->
    <?php if ($_SESSION['role'] === 'mahasiswa' && in_array($tagihan['status'], ['open', 'pending'])): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex space-x-4">
            <a href="bayar.php?id=<?= $id ?>" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-money-bill-wave mr-2"></i>Bayar Sekarang
            </a>
            <a href="cicilan.php?id=<?= $id ?>" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                <i class="fas fa-calendar-alt mr-2"></i>Ajukan Cicilan
            </a>
            <a href="beasiswa.php?id=<?= $id ?>" class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700">
                <i class="fas fa-graduation-cap mr-2"></i>Beasiswa
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



