<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$stmt = $pdo->query("SELECT * FROM profil_desa LIMIT 1");
$profil = $stmt->fetch();

$pageTitle = 'Profil Desa - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-4xl font-bold text-gray-800 mb-8">Profil Desa Gembong Kulon</h1>

        <?php if (!$profil): ?>
            <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
                <i class="fas fa-info-circle text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-600 text-lg">Profil desa belum tersedia.</p>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
                <?php if ($profil['foto_desa']): ?>
                    <img src="<?php echo upload_url($profil['foto_desa']); ?>" 
                         alt="Foto Desa" 
                         class="w-full h-96 object-cover">
                <?php endif; ?>
                
                <div class="p-8">
                    <h2 class="text-3xl font-bold text-gray-800 mb-6"><?php echo htmlspecialchars($profil['nama_desa']); ?></h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <?php if ($profil['kecamatan']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Kecamatan</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($profil['kecamatan']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profil['kabupaten']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Kabupaten</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($profil['kabupaten']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profil['provinsi']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Provinsi</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($profil['provinsi']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profil['kode_pos']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Kode Pos</h3>
                                <p class="text-gray-600"><?php echo htmlspecialchars($profil['kode_pos']); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profil['luas_wilayah']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Luas Wilayah</h3>
                                <p class="text-gray-600"><?php echo number_format($profil['luas_wilayah'], 2); ?> km²</p>
                            </div>
                        <?php endif; ?>
                        <?php if ($profil['jumlah_penduduk']): ?>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-2">Jumlah Penduduk</h3>
                                <p class="text-gray-600"><?php echo number_format($profil['jumlah_penduduk']); ?> jiwa</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($profil['alamat']): ?>
                        <div class="mb-6">
                            <h3 class="font-semibold text-gray-800 mb-2">Alamat</h3>
                            <p class="text-gray-600"><?php echo nl2br(htmlspecialchars($profil['alamat'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if ($profil['sejarah']): ?>
                        <div class="mb-6">
                            <h3 class="font-semibold text-gray-800 mb-2">Sejarah</h3>
                            <p class="text-gray-700 leading-relaxed"><?php echo nl2br(htmlspecialchars($profil['sejarah'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if ($profil['visi']): ?>
                        <div class="mb-6">
                            <h3 class="font-semibold text-gray-800 mb-2">Visi</h3>
                            <p class="text-gray-700 leading-relaxed"><?php echo nl2br(htmlspecialchars($profil['visi'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if ($profil['misi']): ?>
                        <div class="mb-6">
                            <h3 class="font-semibold text-gray-800 mb-2">Misi</h3>
                            <p class="text-gray-700 leading-relaxed"><?php echo nl2br(htmlspecialchars($profil['misi'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if ($profil['struktur_organisasi']): ?>
                        <div class="mb-6">
                            <h3 class="font-semibold text-gray-800 mb-2">Struktur Organisasi</h3>
                            <p class="text-gray-700 leading-relaxed"><?php echo nl2br(htmlspecialchars($profil['struktur_organisasi'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="border-t border-gray-200 pt-6 mt-6">
                        <h3 class="font-semibold text-gray-800 mb-4">Kontak</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <?php if ($profil['kontak_email']): ?>
                                <div>
                                    <i class="fas fa-envelope mr-2 text-blue-600"></i>
                                    <span class="text-gray-600"><?php echo htmlspecialchars($profil['kontak_email']); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($profil['kontak_telepon']): ?>
                                <div>
                                    <i class="fas fa-phone mr-2 text-blue-600"></i>
                                    <span class="text-gray-600"><?php echo htmlspecialchars($profil['kontak_telepon']); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($profil['kontak_alamat']): ?>
                                <div class="md:col-span-2">
                                    <i class="fas fa-map-marker-alt mr-2 text-blue-600"></i>
                                    <span class="text-gray-600"><?php echo htmlspecialchars($profil['kontak_alamat']); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>



