<?php
require_once '../includes/auth.php';

$admin_page = true;
$page_title = 'Login Admin/Petugas';
$message = '';
$message_type = '';

if (is_admin_logged_in()) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($identifier) || empty($password)) {
        $message = 'Masukkan NIK/Email dan Password.';
        $message_type = 'danger';
    } elseif (admin_login($identifier, $password)) {
        header('Location: index.php');
        exit;
    } else {
        $message = 'Hak akses ditolak atau password salah.';
        $message_type = 'danger';
    }
}

include '../includes/header.php';
?>

<div class="container card" style="max-width: 480px; margin-top: 60px;">
    <div class="card-header text-center">
        <h2>Login Admin / Petugas</h2>
        <p class="mb-0 small">Gunakan akun dengan role Admin atau Petugas</p>
    </div>
    <form action="login.php" method="POST" class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="form-group mb-3">
            <label for="identifier">NIK atau Email</label>
            <input type="text" id="identifier" name="identifier" required value="<?php echo esc($_POST['identifier'] ?? ''); ?>">
        </div>
        <div class="form-group mb-4">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block w-100">Masuk Dashboard</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>