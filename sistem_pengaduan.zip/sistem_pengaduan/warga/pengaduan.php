<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('warga');

$pdo = getDBConnection();
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT p.*, k.nama_kategori 
    FROM pengaduan p 
    LEFT JOIN kategori_pengaduan k ON p.kategori_id = k.id
    WHERE p.user_id = ? 
    ORDER BY p.created_at DESC
");
$stmt->execute([$user_id]);
$pengaduan_list = $stmt->fetchAll();

$pageTitle = 'Pengaduan Saya - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Pengaduan Saya</h1>
        <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition">
            <i class="fas fa-plus mr-2"></i>Pengaduan Baru
        </a>
    </div>

    <?php if (empty($pengaduan_list)): ?>
        <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
            <i class="fas fa-file-alt text-6xl text-gray-300 mb-4"></i>
            <p class="text-gray-600 text-lg mb-2">Belum ada pengaduan.</p>
            <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition mt-4">
                Buat Pengaduan Pertama
            </a>
        </div>
    <?php else: ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Judul</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Kategori</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Status</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Tanggal</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($pengaduan_list as $pengaduan): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($pengaduan['judul']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars(substr($pengaduan['deskripsi'], 0, 50)) . '...'; ?></div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo htmlspecialchars($pengaduan['nama_kategori'] ?? '-'); ?></td>
                                <td class="px-6 py-4">
                                    <?php echo getStatusBadge($pengaduan['status'], 'pengaduan'); ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo formatTanggal($pengaduan['created_at']); ?></td>
                                <td class="px-6 py-4">
                                    <a href="<?php echo BASE_URL; ?>warga/pengaduan_detail.php?id=<?php echo $pengaduan['id']; ?>" 
                                        class="text-blue-600 hover:text-blue-700 text-sm">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

