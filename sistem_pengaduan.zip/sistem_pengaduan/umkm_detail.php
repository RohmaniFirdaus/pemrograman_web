<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("
    SELECT u.*, k.nama_kategori 
    FROM umkm u 
    LEFT JOIN kategori_umkm k ON u.kategori_id = k.id 
    WHERE u.id = ? AND u.status_verifikasi = 'terverifikasi'
");
$stmt->execute([$id]);
$umkm = $stmt->fetch();

if (!$umkm) {
    header('Location: umkm.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM galeri_umkm WHERE umkm_id = ? ORDER BY created_at DESC");
$stmt->execute([$id]);
$galeri = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT k.*, u.nama_lengkap, u.foto_profil 
    FROM komentar k 
    LEFT JOIN users u ON k.user_id = u.id 
    WHERE k.tipe_entitas = 'umkm' AND k.entitas_id = ? AND k.status = 'aktif'
    ORDER BY k.created_at DESC
");
$stmt->execute([$id]);
$komentar = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT u.*, k.nama_kategori 
    FROM umkm u 
    LEFT JOIN kategori_umkm k ON u.kategori_id = k.id 
    WHERE u.id != ? AND u.kategori_id = ? AND u.status_verifikasi = 'terverifikasi' 
    ORDER BY u.created_at DESC 
    LIMIT 3
");
$stmt->execute([$id, $umkm['kategori_id']]);
$related_umkm = $stmt->fetchAll();

$pageTitle = htmlspecialchars($umkm['nama_umkm']) . ' - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <nav class="mb-6">
            <a href="index.php" class="text-blue-600 hover:text-blue-700">Beranda</a>
            <span class="mx-2 text-gray-400">/</span>
            <a href="umkm.php" class="text-blue-600 hover:text-blue-700">UMKM</a>
            <span class="mx-2 text-gray-400">/</span>
            <span class="text-gray-600"><?php echo htmlspecialchars($umkm['nama_umkm']); ?></span>
        </nav>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
            <?php if ($umkm['gambar_utama']): ?>
                <img src="<?php echo upload_url($umkm['gambar_utama']); ?>" 
                     alt="<?php echo htmlspecialchars($umkm['nama_umkm']); ?>" 
                     class="w-full h-96 object-cover">
            <?php endif; ?>
            
            <div class="p-8">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($umkm['nama_umkm']); ?></h1>
                        <span class="inline-block bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                            <?php echo htmlspecialchars($umkm['nama_kategori']); ?>
                        </span>
                        <?php if ($umkm['is_unggulan']): ?>
                            <span class="inline-block bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-semibold ml-2">
                                <i class="fas fa-star mr-1"></i>Unggulan
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <h3 class="font-semibold text-gray-800 mb-2">Pemilik</h3>
                        <p class="text-gray-600"><i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($umkm['nama_pemilik']); ?></p>
                    </div>
                    <?php if ($umkm['telepon']): ?>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-2">Kontak</h3>
                            <p class="text-gray-600"><i class="fas fa-phone mr-2"></i><?php echo htmlspecialchars($umkm['telepon']); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if ($umkm['alamat']): ?>
                        <div class="md:col-span-2">
                            <h3 class="font-semibold text-gray-800 mb-2">Alamat</h3>
                            <p class="text-gray-600"><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($umkm['alamat']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($umkm['deskripsi']): ?>
                    <div class="mb-6">
                        <h3 class="font-semibold text-gray-800 mb-2">Deskripsi</h3>
                        <p class="text-gray-700 leading-relaxed"><?php echo nl2br(htmlspecialchars($umkm['deskripsi'])); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($galeri)): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Galeri</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <?php foreach ($galeri as $gambar): ?>
                        <a href="<?php echo upload_url($gambar['gambar']); ?>" target="_blank" class="block">
                            <img src="<?php echo upload_url($gambar['gambar']); ?>" 
                                 alt="Galeri UMKM" 
                                 class="w-full h-32 object-cover rounded-lg hover:opacity-80 transition">
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (isLoggedIn()): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Tulis Komentar</h3>
                <form method="POST" action="komentar_action.php">
                    <input type="hidden" name="tipe_entitas" value="umkm">
                    <input type="hidden" name="entitas_id" value="<?php echo $umkm['id']; ?>">
                    <textarea name="komentar" rows="4" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                              placeholder="Tulis komentar Anda..." required></textarea>
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                        <i class="fas fa-paper-plane mr-2"></i>Kirim Komentar
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="bg-blue-50 rounded-lg p-6 mb-8 text-center">
                <p class="text-gray-700 mb-2">Silakan <a href="login.php" class="text-blue-600 hover:text-blue-700 font-semibold">login</a> untuk menulis komentar.</p>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4">
                Komentar (<?php echo count($komentar); ?>)
            </h3>
            
            <?php if (empty($komentar)): ?>
                <p class="text-gray-600">Belum ada komentar.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($komentar as $k): ?>
                        <div class="border-b border-gray-200 pb-4 last:border-0">
                            <div class="flex items-start gap-4">
                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                                    <?php if ($k['foto_profil']): ?>
                                        <img src="<?php echo upload_url($k['foto_profil']); ?>" 
                                             alt="<?php echo htmlspecialchars($k['nama_lengkap']); ?>" 
                                             class="w-10 h-10 rounded-full object-cover">
                                    <?php else: ?>
                                        <i class="fas fa-user text-blue-600"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1">
                                    <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($k['nama_lengkap']); ?></div>
                                    <div class="text-sm text-gray-500 mb-2"><?php echo formatTanggal($k['created_at'], true); ?></div>
                                    <div class="text-gray-700"><?php echo nl2br(htmlspecialchars($k['komentar'])); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($related_umkm)): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">UMKM Terkait</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <?php foreach ($related_umkm as $ru): ?>
                        <a href="umkm_detail.php?id=<?php echo $ru['id']; ?>" class="block hover:opacity-80 transition">
                            <?php if ($ru['gambar_utama']): ?>
                                <img src="<?php echo upload_url($ru['gambar_utama']); ?>" 
                                     alt="<?php echo htmlspecialchars($ru['nama_umkm']); ?>" 
                                     class="w-full h-32 object-cover rounded-lg mb-2">
                            <?php endif; ?>
                            <h4 class="font-semibold text-gray-800 text-sm"><?php echo htmlspecialchars($ru['nama_umkm']); ?></h4>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>



