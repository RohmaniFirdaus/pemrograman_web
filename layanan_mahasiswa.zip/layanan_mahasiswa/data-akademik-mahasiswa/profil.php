<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Profil Mahasiswa';
$currentModule = 'data-akademik-mahasiswa';

$user = getCurrentUser();
$conn = getDBConnection();

// Get mahasiswa data
$mahasiswa = $conn->query("
    SELECT m.*, p.nama_prodi, f.nama_fakultas, d.nama_dosen as nama_dosen_wali, u.username
    FROM mahasiswa m 
    LEFT JOIN program_studi p ON m.prodi_id = p.id 
    LEFT JOIN fakultas f ON p.fakultas_id = f.id
    LEFT JOIN dosen d ON m.dosen_wali_id = d.id
    LEFT JOIN users u ON m.user_id = u.id
    WHERE m.user_id = " . $user['id']
)->fetch_assoc();

if (!$mahasiswa) {
    header('Location: ../dashboard/mahasiswa.php');
    exit;
}

// Get KRS history
$krs_history = $conn->query("
    SELECT krs.*, COUNT(kd.id) as jumlah_mk 
    FROM krs 
    LEFT JOIN krs_detail kd ON krs.id = kd.krs_id 
    WHERE krs.mahasiswa_id = " . $mahasiswa['id'] . "
    GROUP BY krs.id
    ORDER BY krs.created_at DESC 
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

// Get nilai summary by semester
$nilai_summary = $conn->query("
    SELECT 
        n.semester,
        n.tahun_akademik,
        COUNT(n.id) as jumlah_mk,
        SUM(mk.sks) as total_sks,
        SUM(n.nilai_angka * mk.sks) / SUM(mk.sks) as ip_semester
    FROM nilai n
    JOIN mata_kuliah mk ON n.mk_id = mk.id
    WHERE n.mahasiswa_id = " . $mahasiswa['id'] . " AND n.status = 'final'
    GROUP BY n.semester, n.tahun_akademik
    ORDER BY n.tahun_akademik DESC, n.semester DESC
")->fetch_all(MYSQLI_ASSOC);

// Get latest nilai
$nilai_terbaru = $conn->query("
    SELECT n.*, mk.nama_mk, mk.sks, mk.kode_mk 
    FROM nilai n 
    JOIN mata_kuliah mk ON n.mk_id = mk.id 
    WHERE n.mahasiswa_id = " . $mahasiswa['id'] . " AND n.status = 'final'
    ORDER BY n.created_at DESC 
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Profil Mahasiswa</h1>
        <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Mahasiswa</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold text-gray-800 text-lg"><?= htmlspecialchars($mahasiswa['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold text-gray-800 text-lg"><?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Fakultas</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_fakultas'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Wali</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_dosen_wali'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Angkatan</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['angkatan'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($mahasiswa['status']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">IPK</p>
                <p class="font-semibold text-gray-800 text-2xl"><?= number_format($mahasiswa['ipk'], 2) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS Tempuh</p>
                <p class="font-semibold text-gray-800 text-2xl"><?= $mahasiswa['sks_tempuh'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Username</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['username'] ?? '-') ?></p>
            </div>
        </div>
    </div>
    
    <!-- Riwayat KRS -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Riwayat KRS</h2>
            <a href="<?= BASE_URL ?>krs/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Tahun Akademik</th>
                        <th class="px-4 py-2 text-left">Jumlah MK</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($krs_history)): ?>
                        <tr>
                            <td colspan="6" class="px-4 py-4 text-center text-gray-500">Belum ada KRS</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_history as $k): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= $k['semester'] ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($k['tahun_akademik']) ?></td>
                            <td class="px-4 py-2"><?= $k['jumlah_mk'] ?></td>
                            <td class="px-4 py-2"><?= $k['sks_diambil'] ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($k['status']) ?></td>
                            <td class="px-4 py-2"><?= formatTanggal($k['created_at']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Summary Nilai per Semester -->
    <?php if (!empty($nilai_summary)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Rekapitulasi Nilai per Semester</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Tahun Akademik</th>
                        <th class="px-4 py-2 text-left">Jumlah MK</th>
                        <th class="px-4 py-2 text-left">Total SKS</th>
                        <th class="px-4 py-2 text-left">IP Semester</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nilai_summary as $ns): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= $ns['semester'] ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($ns['tahun_akademik']) ?></td>
                        <td class="px-4 py-2"><?= $ns['jumlah_mk'] ?></td>
                        <td class="px-4 py-2"><?= $ns['total_sks'] ?></td>
                        <td class="px-4 py-2">
                            <span class="font-semibold"><?= number_format($ns['ip_semester'], 2) ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Nilai Terbaru -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Nilai Terbaru</h2>
            <a href="<?= BASE_URL ?>nilai/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Nilai</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($nilai_terbaru)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Belum ada nilai</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($nilai_terbaru as $n): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($n['kode_mk']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $n['sks'] ?></td>
                            <td class="px-4 py-2">
                                <span class="font-semibold"><?= $n['nilai_huruf'] ?></span>
                                <span class="text-gray-600">(<?= number_format($n['nilai_angka'], 2) ?>)</span>
                            </td>
                            <td class="px-4 py-2"><?= $n['semester'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


