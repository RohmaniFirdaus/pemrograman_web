<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 9;
$offset = ($page - 1) * $perPage;

$kategori_id = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$where = "WHERE status_verifikasi = 'terverifikasi'";
$params = [];

if ($kategori_id > 0) {
    $where .= " AND kategori_id = ?";
    $params[] = $kategori_id;
}

if ($search) {
    $where .= " AND (nama_umkm LIKE ? OR nama_pemilik LIKE ? OR deskripsi LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM umkm $where");
$stmt->execute($params);
$total = $stmt->fetch()['total'];
$totalPages = ceil($total / $perPage);

$stmt = $pdo->prepare("
    SELECT u.*, k.nama_kategori 
    FROM umkm u 
    LEFT JOIN kategori_umkm k ON u.kategori_id = k.id 
    $where 
    ORDER BY u.is_unggulan DESC, u.created_at DESC 
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$umkm_list = $stmt->fetchAll();

$stmt = $pdo->query("SELECT * FROM kategori_umkm ORDER BY nama_kategori");
$kategori_list = $stmt->fetchAll();

$pageTitle = 'UMKM Desa - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">UMKM Desa</h1>
        <p class="text-gray-600">Produk dan jasa lokal terbaik dari warga Gembong Kulon</p>
    </div>

    <form method="GET" class="mb-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <select name="kategori" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="0">Semua Kategori</option>
                    <?php foreach ($kategori_list as $kat): ?>
                        <option value="<?php echo $kat['id']; ?>" <?php echo $kategori_id == $kat['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                       placeholder="Cari UMKM..." 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                    <i class="fas fa-search mr-2"></i>Cari
                </button>
                <?php if ($kategori_id > 0 || $search): ?>
                    <a href="umkm.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition">
                        <i class="fas fa-times mr-2"></i>Reset
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <?php if (empty($umkm_list)): ?>
        <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
            <i class="fas fa-store text-6xl text-gray-300 mb-4"></i>
            <p class="text-gray-600 text-lg"><?php echo ($kategori_id > 0 || $search) ? 'Tidak ada UMKM yang ditemukan.' : 'Belum ada UMKM terverifikasi.'; ?></p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <?php foreach ($umkm_list as $umkm): ?>
                <div class="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition">
                    <div class="relative">
                        <?php if ($umkm['gambar_utama']): ?>
                            <img src="<?php echo upload_url($umkm['gambar_utama']); ?>" 
                                 alt="<?php echo htmlspecialchars($umkm['nama_umkm']); ?>" 
                                 class="w-full h-48 object-cover">
                        <?php else: ?>
                            <div class="w-full h-48 bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-store text-6xl text-blue-400"></i>
                            </div>
                        <?php endif; ?>
                        <?php if ($umkm['is_unggulan']): ?>
                            <span class="absolute top-2 left-2 bg-yellow-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                                <i class="fas fa-star mr-1"></i>Unggulan
                            </span>
                        <?php endif; ?>
                        <span class="absolute top-2 right-2 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                            <?php echo htmlspecialchars($umkm['nama_kategori']); ?>
                        </span>
                    </div>
                    <div class="p-6">
                        <h3 class="font-bold text-xl mb-2 text-gray-800"><?php echo htmlspecialchars($umkm['nama_umkm']); ?></h3>
                        <p class="text-gray-600 text-sm mb-4"><?php echo htmlspecialchars(substr($umkm['deskripsi'], 0, 100)) . '...'; ?></p>
                        <div class="space-y-2 text-sm text-gray-600 mb-4">
                            <div><i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($umkm['nama_pemilik']); ?></div>
                            <?php if ($umkm['telepon']): ?>
                                <div><i class="fas fa-phone mr-2"></i><?php echo htmlspecialchars($umkm['telepon']); ?></div>
                            <?php endif; ?>
                            <?php if ($umkm['alamat']): ?>
                                <div><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($umkm['alamat']); ?></div>
                            <?php endif; ?>
                        </div>
                        <a href="umkm_detail.php?id=<?php echo $umkm['id']; ?>" 
                           class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded-lg transition">
                            Lihat Detail
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php echo generatePagination($page, $totalPages, BASE_URL . 'umkm.php'); ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>



