<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    $role = $_SESSION['user_role'];
    if ($role === 'admin') {
        header('Location: ' . BASE_URL . 'admin/index.php');
    } elseif ($role === 'kepala_desa') {
        header('Location: ' . BASE_URL . 'kepala_desa/index.php');
    } else {
        header('Location: ' . BASE_URL . 'warga/dashboard.php');
    }
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik = sanitize($_POST['nik'] ?? '');
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $nama_lengkap = sanitize($_POST['nama_lengkap'] ?? '');
    $no_hp = sanitize($_POST['no_hp'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    
    // Validation
    if (empty($nik) || empty($username) || empty($email) || empty($password) || empty($nama_lengkap)) {
        $error = 'Semua field yang wajib diisi harus diisi';
    } elseif ($password !== $password_confirm) {
        $error = 'Password dan konfirmasi password tidak sama';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } else {
        $pdo = getDBConnection();
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE nik = ?");
        $stmt->execute([$nik]);
        if ($stmt->fetch()) {
            $error = 'NIK sudah terdaftar';
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = 'Username sudah digunakan';
            } else {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = 'Email sudah terdaftar';
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        INSERT INTO users (nik, username, email, password, nama_lengkap, no_hp, alamat, role, status_verifikasi) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'warga', 'menunggu')
                    ");
                    
                    if ($stmt->execute([$nik, $username, $email, $hashed_password, $nama_lengkap, $no_hp, $alamat])) {
                        setFlashMessage('success', 'Registrasi berhasil! Silakan login dan lengkapi profil untuk verifikasi.');
                        header('Location: ' . BASE_URL . 'login.php');
                        exit;
                    } else {
                        $error = 'Terjadi kesalahan saat registrasi';
                    }
                }
            }
        }
    }
}

$flash = getFlashMessage();
if ($flash) {
    if ($flash['type'] === 'success') {
        $success = $flash['message'];
    } else {
        $error = $flash['message'];
    }
}

$pageTitle = 'Registrasi - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 py-12 px-4">
    <div class="max-w-2xl mx-auto bg-white rounded-2xl shadow-2xl p-8">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
                <i class="fas fa-user-plus text-white text-2xl"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-800">Registrasi Warga</h1>
            <p class="text-gray-600 mt-2">Daftar untuk mengakses layanan desa</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
                <div class="flex">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <p><?php echo $error; ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 mb-6 rounded">
                <div class="flex">
                    <i class="fas fa-check-circle mr-2"></i>
                    <p><?php echo $success; ?></p>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-id-card mr-2 text-blue-600"></i>NIK <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="nik" required maxlength="16"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Masukkan NIK">
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-user mr-2 text-blue-600"></i>Username <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="username" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Masukkan username">
                </div>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">
                    <i class="fas fa-envelope mr-2 text-blue-600"></i>Email <span class="text-red-500">*</span>
                </label>
                <input type="email" name="email" required
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                    placeholder="Masukkan email">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-lock mr-2 text-blue-600"></i>Password <span class="text-red-500">*</span>
                    </label>
                    <input type="password" name="password" required minlength="6"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Minimal 6 karakter">
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-lock mr-2 text-blue-600"></i>Konfirmasi Password <span class="text-red-500">*</span>
                    </label>
                    <input type="password" name="password_confirm" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Ulangi password">
                </div>
            </div>

            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">
                    <i class="fas fa-user-tag mr-2 text-blue-600"></i>Nama Lengkap <span class="text-red-500">*</span>
                </label>
                <input type="text" name="nama_lengkap" required
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                    placeholder="Masukkan nama lengkap">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-phone mr-2 text-blue-600"></i>No. HP
                    </label>
                    <input type="tel" name="no_hp"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Masukkan nomor HP">
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">
                        <i class="fas fa-map-marker-alt mr-2 text-blue-600"></i>Alamat
                    </label>
                    <input type="text" name="alamat"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                        placeholder="Masukkan alamat">
                </div>
            </div>

            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200 transform hover:scale-105 shadow-lg">
                <i class="fas fa-user-plus mr-2"></i>Daftar
            </button>
        </form>

        <div class="mt-6 text-center">
            <p class="text-gray-600">
                Sudah punya akun? 
                <a href="<?php echo BASE_URL; ?>login.php" class="text-blue-600 hover:text-blue-700 font-semibold">
                    Login Sekarang
                </a>
            </p>
        </div>

        <div class="mt-4 text-center">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-gray-500 hover:text-gray-700 text-sm">
                <i class="fas fa-arrow-left mr-1"></i>Kembali ke Beranda
            </a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

