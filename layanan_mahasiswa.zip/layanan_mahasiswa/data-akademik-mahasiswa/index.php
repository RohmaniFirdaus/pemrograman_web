<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Data Akademik';
$currentModule = 'data-akademik-mahasiswa';

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Data Akademik</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="mata-kuliah.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-book text-purple-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Data Mata Kuliah</h2>
                    <p class="text-gray-600 text-sm mt-2">Lihat daftar mata kuliah yang tersedia</p>
                </div>
            </div>
        </a>
        
        <a href="dosen.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-chalkboard-teacher text-blue-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Data Dosen</h2>
                    <p class="text-gray-600 text-sm mt-2">Lihat daftar dosen dan informasi dosen</p>
                </div>
            </div>
        </a>
        
        <a href="profil.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <i class="fas fa-user text-green-600 text-4xl mb-3"></i>
                    <h2 class="text-xl font-bold text-gray-800">Profil Mahasiswa</h2>
                    <p class="text-gray-600 text-sm mt-2">Lihat data akademik Anda</p>
                </div>
            </div>
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>




