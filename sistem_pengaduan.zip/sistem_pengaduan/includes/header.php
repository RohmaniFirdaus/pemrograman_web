<?php
// includes/header.php
// Pastikan session_start() sudah dipanggil di auth.php sebelum header ini di-include.
// $page_title harus didefinisikan di setiap file yang meng-include header ini.

// Path assets, sesuaikan jika Anda memindahkan folder assets
$asset_prefix = '';
if (isset($admin_page) && $admin_page) {
    $asset_prefix = '../'; // Jika halaman admin, path ke assets perlu keluar satu folder
}

// Untuk menentukan halaman aktif di navigasi
// Kita tetap pakai ini agar logika active class bisa bekerja.
$current_page_basename = basename($_SERVER['PHP_SELF']);
$current_request_uri = $_SERVER['REQUEST_URI'];

// Dapatkan koneksi database jika diperlukan di header (untuk notifikasi admin)
// Pastikan '../includes/config.php' sudah di-require di halaman yang memanggil header ini
$pdo = null;
if (function_exists('getConnection')) { // Pastikan fungsi getConnection ada
    $pdo = getConnection();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? esc($page_title) . ' | Sistem Pengaduan' : 'Sistem Pengaduan'; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* --- GENERAL STYLES & RESET --- */
        :root {
            --primary-color: #0288d1;
            --secondary-color: #03a9f4;
            --accent-color: #f9a825;
            --danger-color: #d32f2f;
            --info-color: #0288d1;
            --warning-color: #fdd835;
            --success-color: #0288d1;
            --light-bg: #f4f6f8;
            --dark-bg: #01579b;
            --text-color: #2e2e2e;
            --border-color: #e0e0e0;
            --box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--light-bg);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh; /* Ensures footer sticks to bottom */
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* --- HEADER --- */
        .main-header {
            background: linear-gradient(90deg, var(--dark-bg), var(--primary-color));
            color: #fff;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            flex-shrink: 0;
        }

        .main-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            gap: 20px;
        }

        .logo {
            flex-shrink: 0;
            margin-right: 20px;
        }

        .logo a {
            color: #fff;
            text-decoration: none;
            font-size: 1.6rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .logo small {
            display: block;
            font-size: 0.8rem;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--warning-color);
        }

        .main-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex: 1;
            gap: 20px;
        }

        .main-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .main-nav .nav-left {
            flex-wrap: wrap;
        }

        .main-nav .nav-right {
            margin-left: auto;
        }

        .main-nav ul li a {
            color: #fff;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 999px;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-weight: 500;
        }

        .main-nav ul li a:hover,
        .main-nav ul li a.active {
            background-color: rgba(255,255,255,0.2);
            color: #fff;
        }

        /* --- NOTIFICATION BADGE STYLE (BARU DITAMBAHKAN) --- */
        .notification-badge {
            background-color: var(--danger-color); /* Merah untuk notifikasi */
            color: white;
            border-radius: 50%;
            padding: 2px 7px;
            font-size: 0.75em;
            position: relative;
            top: -8px; /* Sesuaikan posisi vertikal */
            left: 5px; /* Sesuaikan posisi horizontal */
            vertical-align: super;
            line-height: 1;
            display: inline-block;
        }
        /* --- AKHIR NOTIFICATION BADGE STYLE --- */

        /* --- MAIN CONTENT AREA --- */
        .main-content {
            flex-grow: 1; /* Allows main content to take available space */
            padding: 40px 0; /* Vertical padding for content */
        }

        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
        }

        .card-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
            text-align: center;
        }

        .card-header h2 {
            color: var(--primary-color);
            font-size: 2rem;
            margin: 0;
        }

        /* --- FORM STYLES --- */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"],
        .form-group input[type="tel"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
            box-sizing: border-box; /* Crucial for padding/width calculation */
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="email"]:focus,
        .form-group input[type="password"]:focus,
        .form-group input[type="tel"]:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .checkbox-group input[type="checkbox"] {
            margin-right: 10px;
            width: auto;
        }

        /* --- BUTTONS --- */
        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 1.1rem;
            font-weight: bold;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
            text-align: center;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: var(--secondary-color);
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .btn-success {
            background-color: var(--success-color);
            color: #fff;
        }

        .btn-success:hover {
            background-color: #0277bd;
        }

        .btn-danger {
            background-color: var(--danger-color);
            color: #fff;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .btn-info {
            background-color: var(--info-color);
            color: #fff;
        }

        .btn-info:hover {
            background-color: #117a8b;
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .btn-sm {
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        .btn-outline-light {
            background-color: transparent;
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.5);
        }

        .btn-outline-light:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-color: #fff;
        }

        .btn-light {
            background-color: #fff;
            color: var(--primary-color);
            border: 2px solid #fff;
        }

        .btn-light:hover {
            background-color: #f8f9fa;
            color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .w-100 {
            width: 100%;
        }

        .bg-warning {
            background-color: var(--warning-color) !important;
        }

        .text-dark {
            color: #212529 !important;
        }

        /* --- ALERTS & MESSAGES --- */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-size: 1rem;
            line-height: 1.5;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        /* --- TABLE STYLES --- */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: var(--box-shadow);
            border-radius: 8px;
            overflow: hidden; /* For rounded corners */
        }

        table thead {
            background-color: var(--primary-color);
            color: #fff;
        }

        table th,
        table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Status Badges in Tables */
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: bold;
            color: #fff;
            text-transform: capitalize;
            text-align: center;
        }

        /* Specific status colors */
        .status-badge.status-menunggu { background-color: var(--warning-color); color: var(--text-color); }
        .status-badge.status-diproses { background-color: var(--info-color); color: #fff; }
        .status-badge.status-ditanggapi { background-color: var(--success-color); color: var(--text-color); }
        .status-badge.status-proses { background-color: var(--success-color); color: var(--text-color); }
        .status-badge.status-selesai { background-color: var(--success-color); color: var(--text-color); }
        .status-badge.status-ditolak { background-color: var(--danger-color);color: var(--text-color);  }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.15rem 0.65rem;
            border-radius: 999px;
            font-size: 0.85rem;
            font-weight: 600;
            background-color: rgba(255,255,255,0.25);
            color: #fff;
        }

        /* --- FOOTER --- */
        .main-footer {
            background-color: var(--dark-bg);
            color: #fff;
            text-align: center;
            padding: 1.2rem 0;
            margin-top: auto; /* Pushes footer to the bottom */
            flex-shrink: 0;
            font-size: 0.9rem;
        }

        /* --- UTILITIES --- */
        .text-center { text-align: center; }
        .my-4 { margin-top: 1.5rem; margin-bottom: 1.5rem; }
        .mb-3 { margin-bottom: 1rem; }
        .mt-3 { margin-top: 1rem; }
        .d-flex { display: flex; }
        .justify-content-between { justify-content: space-between; }
        .align-items-center { align-items: center; }
        .flex-wrap { flex-wrap: wrap; }
        .gap-3 { gap: 1rem; }
        .mb-4 { margin-bottom: 1.5rem; }
        .py-4 { padding-top: 1.5rem; padding-bottom: 1.5rem; }
        .text-dark { color: #212529; }
        .border { border: 1px solid #dee2e6; }
        .fw-bold { font-weight: 700; }
        .display-4 { font-size: 2.5rem; }
        .lead { font-size: 1.25rem; font-weight: 300; }
        .px-4 { padding-left: 1.5rem; padding-right: 1.5rem; }
        .py-3 { padding-top: 1rem; padding-bottom: 1rem; }
        .me-1 { margin-right: 0.25rem; }
        .me-2 { margin-right: 0.5rem; }
        .mb-0 { margin-bottom: 0; }
        .mb-5 { margin-bottom: 3rem; }
        .col-md-10 { width: 83.33333%; }
        .row { display: flex; flex-wrap: wrap; margin-right: -15px; margin-left: -15px; }
        .justify-content-center { justify-content: center; }
        .col-12 { flex: 0 0 100%; max-width: 100%; }
        .col-md-3 { flex: 0 0 25%; max-width: 25%; }
        .col-6 { flex: 0 0 50%; max-width: 50%; }
        .col-md-6 { flex: 0 0 50%; max-width: 50%; }
        .col-lg-4 { flex: 0 0 33.33333%; max-width: 33.33333%; }
        .col-lg-5 { flex: 0 0 41.66667%; max-width: 41.66667%; }
        .col-lg-7 { flex: 0 0 58.33333%; max-width: 58.33333%; }
        .col-md-6 { flex: 0 0 50%; max-width: 50%; }

        /* Table Styles */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 0;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }

        .table th,
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .table thead th {
            background-color: var(--primary-color);
            color: #fff;
            font-weight: 600;
            border-bottom: 2px solid var(--primary-color);
        }

        /* List Group Styles */
        .list-group {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .list-group-item {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            background-color: #fff;
            transition: background-color 0.2s ease;
        }

        .list-group-item:last-child {
            border-bottom: none;
        }

        .list-group-item:hover {
            background-color: #f8f9fa;
        }

        .btn-link {
            color: var(--primary-color);
            text-decoration: none;
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .btn-link:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }

        .mt-3 { margin-top: 1rem; }
        .p-4 { padding: 1.5rem; }
        .shadow-sm { box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .card-title { margin-bottom: 0; }
        .form-label { margin-bottom: 0.5rem; }
        .form-control-file {
            display: block;
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            font-size: 1rem;
        }
        .h-100 { height: 100%; }
        .small { font-size: 0.875em; }

        @media (max-width: 768px) {
            .main-header .container {
                flex-direction: column;
                align-items: flex-start;
                padding: 15px;
            }
            .logo {
                margin-bottom: 15px;
                margin-right: 0;
                width: 100%;
                text-align: center;
            }

            .main-nav {
                flex-direction: column;
                width: 100%;
                margin-top: 10px;
                align-items: center;
                gap: 10px;
            }

            .main-nav ul {
                flex-direction: column;
                width: 100%;
                text-align: center;
                margin-bottom: 10px;
            }

            .main-nav ul li {
                display: block;
                margin: 8px 0;
            }

            .main-nav ul li a {
                display: block;
            }

            .main-nav .nav-right {
                margin-left: 0;
            }

            table, table thead, table tbody, table th, table td, table tr {
                display: block;
            }
            table thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            table tr { border: 1px solid var(--border-color); margin-bottom: 10px; }
            table td {
                border: none;
                border-bottom: 1px solid var(--border-color);
                position: relative;
                padding-left: 50%;
                text-align: right;
            }
            table td:before {
                position: absolute;
                top: 6px;
                left: 6px;
                width: 45%;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: bold;
            }
            table td:nth-of-type(1):before { content: "No Tiket:"; }
            table td:nth-of-type(2):before { content: "Judul:"; }
            table td:nth-of-type(3):before { content: "Status:"; }
            table td:nth-of-type(4):before { content: "Tanggal:"; }
            table td:nth-of-type(5):before { content: "Aksi:"; }

            .col-md-3, .col-md-6, .col-lg-4, .col-lg-5, .col-lg-7 {
                flex: 0 0 100%;
                max-width: 100%;
            }
            .col-6 { 
                flex: 0 0 50%;
                max-width: 50%;
            }
        }
    </style>
    <?php if (!empty($extra_styles ?? '')): ?>
    <style>
        <?php echo $extra_styles; ?>
    </style>
    <?php endif; ?>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo (isset($admin_page) && $admin_page) ? 'index.php' : $asset_prefix . 'index.php'; ?>">
                    Sistem Desa Gembong Kulon
                    <small>Talang · Kabupaten Tegal</small>
                </a>
            </div>
            <nav class="main-nav">
                <?php if (isset($hide_dashboard_nav) && $hide_dashboard_nav && $current_page_basename == 'tentang.php'): ?>
                    <ul class="nav-left">
                        <li><a href="<?php echo $asset_prefix; ?>index.php" <?php echo ($current_page_basename == 'index.php' ? 'class="active"' : ''); ?>>Beranda</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>tentang.php" <?php echo ($current_page_basename == 'tentang.php' ? 'class="active"' : ''); ?>>Tentang</a></li>
                    </ul>
                    <ul class="nav-right">
                        <?php if (is_user_logged_in()): ?>
                            <li><span class="badge bg-warning text-dark">Halo, <?php echo esc(current_user()['nama']); ?></span></li>
                            <li><a href="user_logout.php" class="btn btn-outline-light btn-sm">Logout</a></li>
                        <?php elseif (is_admin_logged_in()): ?>
                            <li><span class="badge bg-warning text-dark">Halo, <?php echo esc(current_user()['nama']); ?></span></li>
                            <li><a href="admin/logout.php" class="btn btn-outline-light btn-sm">Logout</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo $asset_prefix; ?>user_login.php">Login</a></li>
                            <li><a href="<?php echo $asset_prefix; ?>register.php">Daftar</a></li>
                        <?php endif; ?>
                    </ul>
                <?php elseif (is_admin_logged_in()): ?>
                    <ul class="nav-left">
                        <li><a href="index.php" <?php echo ($current_page_basename == 'index.php' ? 'class="active"' : ''); ?>>Dashboard</a></li>
                        <li><a href="pengaduan.php" <?php echo ($current_page_basename == 'pengaduan.php' ? 'class="active"' : ''); ?>>Pengaduan</a></li>
                        <li><a href="surat.php" <?php echo ($current_page_basename == 'surat.php' ? 'class="active"' : ''); ?>>Surat</a></li>
                        <li><a href="berita.php" <?php echo ($current_page_basename == 'berita.php' ? 'class="active"' : ''); ?>>Berita Desa</a></li>
                        <li><a href="umkm.php" <?php echo ($current_page_basename == 'umkm.php' ? 'class="active"' : ''); ?>>UMKM</a></li>
                        <li><a href="kalender.php" <?php echo ($current_page_basename == 'kalender.php' ? 'class="active"' : ''); ?>>Kalender</a></li>
                        <li><a href="profil_desa.php" <?php echo ($current_page_basename == 'profil_desa.php' ? 'class="active"' : ''); ?>>Profil Desa</a></li>
                        <li><a href="tentang.php" <?php echo ($current_page_basename == 'tentang.php' ? 'class="active"' : ''); ?>>Tentang</a></li>
                    </ul>
                    <ul class="nav-right">
                        <li><span class="badge bg-warning text-dark">Halo, <?php echo esc(current_user()['nama']); ?></span></li>
                        <li><a href="logout.php" class="btn btn-outline-light btn-sm">Keluar</a></li>
                    </ul>
                <?php elseif (is_user_logged_in()): ?>
                    <ul class="nav-left">
                        <li><a href="index.php" <?php echo ($current_page_basename == 'index.php' ? 'class="active"' : ''); ?>>Beranda</a></li>
                        <li><a href="user_dashboard.php" <?php echo ($current_page_basename == 'user_dashboard.php' ? 'class="active"' : ''); ?>>Dashboard Warga</a></li>
                        <li><a href="buat_pengaduan.php" <?php echo ($current_page_basename == 'buat_pengaduan.php' ? 'class="active"' : ''); ?>>Pengaduan</a></li>
                        <li><a href="surat_online.php" <?php echo ($current_page_basename == 'surat_online.php' ? 'class="active"' : ''); ?>>Surat Online</a></li>
                        <li><a href="berita.php" <?php echo ($current_page_basename == 'berita.php' ? 'class="active"' : ''); ?>>Berita</a></li>
                        <li><a href="umkm.php" <?php echo ($current_page_basename == 'umkm.php' ? 'class="active"' : ''); ?>>UMKM</a></li>
                        <li><a href="profil_desa.php" <?php echo ($current_page_basename == 'profil_desa.php' ? 'class="active"' : ''); ?>>Profil Desa</a></li>
                        <li><a href="tentang.php" <?php echo ($current_page_basename == 'tentang.php' ? 'class="active"' : ''); ?>>Tentang</a></li>
                    </ul>
                    <ul class="nav-right">
                        <li><span class="badge bg-warning text-dark">Halo, <?php echo esc(current_user()['nama']); ?></span></li>
                        <li><a href="user_logout.php" class="btn btn-outline-light btn-sm">Logout</a></li>
                    </ul>
                <?php else: ?>
                    <ul class="nav-left">
                        <li><a href="<?php echo $asset_prefix; ?>index.php" <?php echo ($current_page_basename == 'index.php' ? 'class="active"' : ''); ?>>Beranda</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>tentang.php" <?php echo ($current_page_basename == 'tentang.php' ? 'class="active"' : ''); ?>>Tentang</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>profil_desa.php" <?php echo ($current_page_basename == 'profil_desa.php' ? 'class="active"' : ''); ?>>Profil Desa</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>berita.php" <?php echo ($current_page_basename == 'berita.php' ? 'class="active"' : ''); ?>>Berita</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>umkm.php" <?php echo ($current_page_basename == 'umkm.php' ? 'class="active"' : ''); ?>>UMKM</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>kalender.php" <?php echo ($current_page_basename == 'kalender.php' ? 'class="active"' : ''); ?>>Kalender</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>cek_status.php" <?php echo ($current_page_basename == 'cek_status.php' ? 'class="active"' : ''); ?>>Cek Status</a></li>
                    </ul>
                    <ul class="nav-right">
                        <li><a href="<?php echo $asset_prefix; ?>user_login.php" <?php echo ($current_page_basename == 'user_login.php' ? 'class="active"' : ''); ?>>Login</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>register.php" <?php echo ($current_page_basename == 'register.php' ? 'class="active"' : ''); ?>>Daftar</a></li>
                        <li><a href="<?php echo $asset_prefix; ?>admin/login.php" <?php echo (strpos($current_request_uri, '/admin/login.php') !== false ? 'class="active"' : ''); ?>>Admin</a></li>
                    </ul>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <div class="main-content">
