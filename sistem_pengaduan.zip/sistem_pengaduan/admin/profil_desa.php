<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_desa = sanitize($_POST['nama_desa'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    $kode_pos = sanitize($_POST['kode_pos'] ?? '');
    $kecamatan = sanitize($_POST['kecamatan'] ?? '');
    $kabupaten = sanitize($_POST['kabupaten'] ?? '');
    $provinsi = sanitize($_POST['provinsi'] ?? '');
    $luas_wilayah = $_POST['luas_wilayah'] ?? null;
    $jumlah_penduduk = isset($_POST['jumlah_penduduk']) ? (int)$_POST['jumlah_penduduk'] : null;
    $sejarah = sanitize($_POST['sejarah'] ?? '');
    $visi = sanitize($_POST['visi'] ?? '');
    $misi = sanitize($_POST['misi'] ?? '');
    $struktur_organisasi = sanitize($_POST['struktur_organisasi'] ?? '');
    $kontak_email = sanitize($_POST['kontak_email'] ?? '');
    $kontak_telepon = sanitize($_POST['kontak_telepon'] ?? '');
    $kontak_alamat = sanitize($_POST['kontak_alamat'] ?? '');
    
    $foto_desa = null;
    $background_homepage = null;
    
    if (isset($_FILES['foto_desa']) && $_FILES['foto_desa']['error'] === UPLOAD_ERR_OK) {
        $upload = uploadFile($_FILES['foto_desa'], 'profil', ALLOWED_IMAGE_TYPES);
        if ($upload['success']) {
            $foto_desa = $upload['path'];
        }
    }
    
    if (isset($_FILES['background_homepage']) && $_FILES['background_homepage']['error'] === UPLOAD_ERR_OK) {
        $upload = uploadFile($_FILES['background_homepage'], 'profil', ALLOWED_IMAGE_TYPES);
        if ($upload['success']) {
            $background_homepage = $upload['path'];
        }
    }
    
    $stmt = $pdo->query("SELECT id FROM profil_desa LIMIT 1");
    $exists = $stmt->fetch();
    
    if ($exists) {
        $sql = "UPDATE profil_desa SET nama_desa = ?, alamat = ?, kode_pos = ?, kecamatan = ?, kabupaten = ?, provinsi = ?, luas_wilayah = ?, jumlah_penduduk = ?, sejarah = ?, visi = ?, misi = ?, struktur_organisasi = ?, kontak_email = ?, kontak_telepon = ?, kontak_alamat = ?";
        $params = [$nama_desa, $alamat, $kode_pos, $kecamatan, $kabupaten, $provinsi, $luas_wilayah, $jumlah_penduduk, $sejarah, $visi, $misi, $struktur_organisasi, $kontak_email, $kontak_telepon, $kontak_alamat];
        
        if ($foto_desa) {
            $sql .= ", foto_desa = ?";
            $params[] = $foto_desa;
        }
        if ($background_homepage) {
            $sql .= ", background_homepage = ?";
            $params[] = $background_homepage;
        }
        
        $sql .= " WHERE id = ?";
        $params[] = $exists['id'];
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        setFlashMessage('success', 'Profil desa berhasil diperbarui.');
    } else {
        // Insert
        $stmt = $pdo->prepare("
            INSERT INTO profil_desa (nama_desa, alamat, kode_pos, kecamatan, kabupaten, provinsi, luas_wilayah, jumlah_penduduk, sejarah, visi, misi, struktur_organisasi, foto_desa, background_homepage, kontak_email, kontak_telepon, kontak_alamat) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$nama_desa, $alamat, $kode_pos, $kecamatan, $kabupaten, $provinsi, $luas_wilayah, $jumlah_penduduk, $sejarah, $visi, $misi, $struktur_organisasi, $foto_desa, $background_homepage, $kontak_email, $kontak_telepon, $kontak_alamat]);
        setFlashMessage('success', 'Profil desa berhasil ditambahkan.');
    }
    
    header('Location: profil_desa.php');
    exit;
}

$stmt = $pdo->query("SELECT * FROM profil_desa LIMIT 1");
$profil = $stmt->fetch();

$pageTitle = 'Kelola Profil Desa - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Kelola Profil Desa</h1>

    <form method="POST" enctype="multipart/form-data" class="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Nama Desa *</label>
                <input type="text" name="nama_desa" value="<?php echo htmlspecialchars($profil['nama_desa'] ?? ''); ?>" required 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Kecamatan</label>
                <input type="text" name="kecamatan" value="<?php echo htmlspecialchars($profil['kecamatan'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Kabupaten</label>
                <input type="text" name="kabupaten" value="<?php echo htmlspecialchars($profil['kabupaten'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Provinsi</label>
                <input type="text" name="provinsi" value="<?php echo htmlspecialchars($profil['provinsi'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Kode Pos</label>
                <input type="text" name="kode_pos" value="<?php echo htmlspecialchars($profil['kode_pos'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Luas Wilayah (km²)</label>
                <input type="number" step="0.01" name="luas_wilayah" value="<?php echo $profil['luas_wilayah'] ?? ''; ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Jumlah Penduduk</label>
                <input type="number" name="jumlah_penduduk" value="<?php echo $profil['jumlah_penduduk'] ?? ''; ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Alamat</label>
            <textarea name="alamat" rows="2" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['alamat'] ?? ''); ?></textarea>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Sejarah</label>
            <textarea name="sejarah" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['sejarah'] ?? ''); ?></textarea>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Visi</label>
            <textarea name="visi" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['visi'] ?? ''); ?></textarea>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Misi</label>
            <textarea name="misi" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['misi'] ?? ''); ?></textarea>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Struktur Organisasi</label>
            <textarea name="struktur_organisasi" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['struktur_organisasi'] ?? ''); ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Foto Desa</label>
                <?php if ($profil && $profil['foto_desa']): ?>
                    <img src="<?php echo upload_url($profil['foto_desa']); ?>" alt="Foto Desa" class="w-32 h-32 object-cover rounded mb-2">
                <?php endif; ?>
                <input type="file" name="foto_desa" accept="image/*" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Background Homepage</label>
                <?php if ($profil && $profil['background_homepage']): ?>
                    <img src="<?php echo upload_url($profil['background_homepage']); ?>" alt="Background" class="w-32 h-32 object-cover rounded mb-2">
                <?php endif; ?>
                <input type="file" name="background_homepage" accept="image/*" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Kontak Email</label>
                <input type="email" name="kontak_email" value="<?php echo htmlspecialchars($profil['kontak_email'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Kontak Telepon</label>
                <input type="text" name="kontak_telepon" value="<?php echo htmlspecialchars($profil['kontak_telepon'] ?? ''); ?>" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Kontak Alamat</label>
            <textarea name="kontak_alamat" rows="2" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($profil['kontak_alamat'] ?? ''); ?></textarea>
        </div>

        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
            Simpan Profil Desa
        </button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>



