<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = !is_readonly_admin();

$pdo = getConnection();
$page_title = 'Profil Desa';
$message = '';
$message_type = '';

$profil = [
    'nama_desa' => '',
    'alamat_desa' => '',
    'telepon_desa' => '',
    'email_desa' => '',
    'deskripsi_desa' => '',
    'visi_misi' => '',
    'sejarah_desa' => ''
];

try {
    $stmt = $pdo->query("SELECT * FROM profil_desa ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch();
    if ($row) $profil = array_merge($profil, $row);
} catch (PDOException $e) {
    error_log('Profil desa error: ' . $e->getMessage());
}

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($profil['id'])) {
            $stmt = $pdo->prepare("
                UPDATE profil_desa SET nama_desa=:nama, alamat_desa=:alamat, telepon_desa=:telepon, email_desa=:email,
                deskripsi_desa=:deskripsi, visi_misi=:visi, sejarah_desa=:sejarah WHERE id = :id
            ");
            $stmt->execute([
                'nama' => $_POST['nama_desa'],
                'alamat' => $_POST['alamat_desa'],
                'telepon' => $_POST['telepon_desa'],
                'email' => $_POST['email_desa'],
                'deskripsi' => $_POST['deskripsi_desa'],
                'visi' => $_POST['visi_misi'],
                'sejarah' => $_POST['sejarah_desa'],
                'id' => $profil['id']
            ]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO profil_desa (nama_desa, alamat_desa, telepon_desa, email_desa, deskripsi_desa, visi_misi, sejarah_desa)
                VALUES (:nama, :alamat, :telepon, :email, :deskripsi, :visi, :sejarah)
            ");
            $stmt->execute([
                'nama' => $_POST['nama_desa'],
                'alamat' => $_POST['alamat_desa'],
                'telepon' => $_POST['telepon_desa'],
                'email' => $_POST['email_desa'],
                'deskripsi' => $_POST['deskripsi_desa'],
                'visi' => $_POST['visi_misi'],
                'sejarah' => $_POST['sejarah_desa']
            ]);
        }
        header('Location: profil_desa.php');
        exit;
    } catch (PDOException $e) {
        error_log('Update profil error: ' . $e->getMessage());
        $message = 'Gagal menyimpan profil.';
        $message_type = 'danger';
    }
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Profil Desa Gembong Kulon</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="profil_desa.php" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Desa</label>
                        <input type="text" name="nama_desa" class="form-control" value="<?php echo esc($profil['nama_desa']); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Desa</label>
                        <input type="email" name="email_desa" class="form-control" value="<?php echo esc($profil['email_desa']); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat_desa" class="form-control" rows="2" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($profil['alamat_desa']); ?></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Telepon</label>
                        <input type="text" name="telepon_desa" class="form-control" value="<?php echo esc($profil['telepon_desa']); ?>" <?php echo $can_update ? '' : 'readonly'; ?>>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi_desa" class="form-control" rows="3" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($profil['deskripsi_desa']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Visi & Misi</label>
                    <textarea name="visi_misi" class="form-control" rows="3" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($profil['visi_misi']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Sejarah</label>
                    <textarea name="sejarah_desa" class="form-control" rows="3" <?php echo $can_update ? '' : 'readonly'; ?>><?php echo esc($profil['sejarah_desa']); ?></textarea>
                </div>
                <?php if ($can_update): ?>
                    <button class="btn btn-primary">Simpan</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>











