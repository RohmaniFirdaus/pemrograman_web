<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

$pdo = getDBConnection();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get berita
$stmt = $pdo->prepare("
    SELECT b.*, u.nama_lengkap as admin_nama 
    FROM berita b 
    LEFT JOIN users u ON b.admin_id = u.id 
    WHERE b.id = ? AND b.status = 'dipublikasi'
");
$stmt->execute([$id]);
$berita = $stmt->fetch();

if (!$berita) {
    header('Location: berita.php');
    exit;
}

// Update views
$stmt = $pdo->prepare("UPDATE berita SET views = views + 1 WHERE id = ?");
$stmt->execute([$id]);

// Get comments
$stmt = $pdo->prepare("
    SELECT k.*, u.nama_lengkap, u.foto_profil 
    FROM komentar k 
    LEFT JOIN users u ON k.user_id = u.id 
    WHERE k.tipe_entitas = 'berita' AND k.entitas_id = ? AND k.status = 'aktif'
    ORDER BY k.created_at DESC
");
$stmt->execute([$id]);
$komentar = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT * FROM berita 
    WHERE id != ? AND status = 'dipublikasi' 
    ORDER BY created_at DESC 
    LIMIT 3
");
$stmt->execute([$id]);
$related_berita = $stmt->fetchAll();

$pageTitle = htmlspecialchars($berita['judul']) . ' - ' . APP_NAME;
include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <nav class="mb-6">
            <a href="index.php" class="text-blue-600 hover:text-blue-700">Beranda</a>
            <span class="mx-2 text-gray-400">/</span>
            <a href="berita.php" class="text-blue-600 hover:text-blue-700">Berita</a>
            <span class="mx-2 text-gray-400">/</span>
            <span class="text-gray-600"><?php echo htmlspecialchars($berita['judul']); ?></span>
        </nav>

        <article class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
            <?php if ($berita['gambar_utama']): ?>
                <img src="<?php echo upload_url($berita['gambar_utama']); ?>" 
                     alt="<?php echo htmlspecialchars($berita['judul']); ?>" 
                     class="w-full h-96 object-cover">
            <?php endif; ?>
            
            <div class="p-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-4"><?php echo htmlspecialchars($berita['judul']); ?></h1>
                
                <div class="flex items-center gap-4 text-sm text-gray-600 mb-6">
                    <span><i class="fas fa-user mr-1"></i><?php echo htmlspecialchars($berita['admin_nama']); ?></span>
                    <span><i class="fas fa-calendar mr-1"></i><?php echo formatTanggal($berita['created_at'], true); ?></span>
                    <span><i class="fas fa-eye mr-1"></i><?php echo $berita['views'] + 1; ?> views</span>
                </div>

                <div class="prose max-w-none text-gray-700 leading-relaxed">
                    <?php echo nl2br(htmlspecialchars($berita['konten'])); ?>
                </div>
            </div>
        </article>

        <?php if (isLoggedIn()): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Tulis Komentar</h3>
                <form method="POST" action="komentar_action.php">
                    <input type="hidden" name="tipe_entitas" value="berita">
                    <input type="hidden" name="entitas_id" value="<?php echo $berita['id']; ?>">
                    <textarea name="komentar" rows="4" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                              placeholder="Tulis komentar Anda..." required></textarea>
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                        <i class="fas fa-paper-plane mr-2"></i>Kirim Komentar
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="bg-blue-50 rounded-lg p-6 mb-8 text-center">
                <p class="text-gray-700 mb-2">Silakan <a href="login.php" class="text-blue-600 hover:text-blue-700 font-semibold">login</a> untuk menulis komentar.</p>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4">
                Komentar (<?php echo count($komentar); ?>)
            </h3>
            
            <?php if (empty($komentar)): ?>
                <p class="text-gray-600">Belum ada komentar.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($komentar as $k): ?>
                        <div class="border-b border-gray-200 pb-4 last:border-0">
                            <div class="flex items-start gap-4">
                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                                    <?php if ($k['foto_profil']): ?>
                                        <img src="<?php echo upload_url($k['foto_profil']); ?>" 
                                             alt="<?php echo htmlspecialchars($k['nama_lengkap']); ?>" 
                                             class="w-10 h-10 rounded-full object-cover">
                                    <?php else: ?>
                                        <i class="fas fa-user text-blue-600"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1">
                                    <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($k['nama_lengkap']); ?></div>
                                    <div class="text-sm text-gray-500 mb-2"><?php echo formatTanggal($k['created_at'], true); ?></div>
                                    <div class="text-gray-700"><?php echo nl2br(htmlspecialchars($k['komentar'])); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($related_berita)): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Berita Terkait</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <?php foreach ($related_berita as $rb): ?>
                        <a href="berita_detail.php?id=<?php echo $rb['id']; ?>" class="block hover:opacity-80 transition">
                            <?php if ($rb['gambar_utama']): ?>
                                <img src="<?php echo upload_url($rb['gambar_utama']); ?>" 
                                     alt="<?php echo htmlspecialchars($rb['judul']); ?>" 
                                     class="w-full h-32 object-cover rounded-lg mb-2">
                            <?php endif; ?>
                            <h4 class="font-semibold text-gray-800 text-sm"><?php echo htmlspecialchars($rb['judul']); ?></h4>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>



