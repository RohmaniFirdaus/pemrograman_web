<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'create' || $action === 'update') {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $judul = sanitize($_POST['judul'] ?? '');
            $konten = sanitize($_POST['konten'] ?? '');
            $status = sanitize($_POST['status'] ?? 'draft');
            
            if (empty($judul) || empty($konten)) {
                setFlashMessage('error', 'Judul dan konten harus diisi.');
            } else {
                $gambar_utama = null;
                if (isset($_FILES['gambar_utama']) && $_FILES['gambar_utama']['error'] === UPLOAD_ERR_OK) {
                    $upload = uploadFile($_FILES['gambar_utama'], 'berita', ALLOWED_IMAGE_TYPES);
                    if ($upload['success']) {
                        $gambar_utama = $upload['path'];
                        
                        if ($action === 'update' && $id > 0) {
                            $stmt = $pdo->prepare("SELECT gambar_utama FROM berita WHERE id = ?");
                            $stmt->execute([$id]);
                            $old = $stmt->fetch();
                            if ($old && $old['gambar_utama']) {
                                deleteFile($old['gambar_utama']);
                            }
                        }
                    }
                }
                
                if ($action === 'create') {
                    $stmt = $pdo->prepare("
                        INSERT INTO berita (admin_id, judul, konten, gambar_utama, status) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$_SESSION['user_id'], $judul, $konten, $gambar_utama, $status]);
                    setFlashMessage('success', 'Berita berhasil ditambahkan.');
                } else {
                    if ($gambar_utama) {
                        $stmt = $pdo->prepare("
                            UPDATE berita SET judul = ?, konten = ?, gambar_utama = ?, status = ? 
                            WHERE id = ?
                        ");
                        $stmt->execute([$judul, $konten, $gambar_utama, $status, $id]);
                    } else {
                        $stmt = $pdo->prepare("
                            UPDATE berita SET judul = ?, konten = ?, status = ? 
                            WHERE id = ?
                        ");
                        $stmt->execute([$judul, $konten, $status, $id]);
                    }
                    setFlashMessage('success', 'Berita berhasil diperbarui.');
                }
            }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $stmt = $pdo->prepare("SELECT gambar_utama FROM berita WHERE id = ?");
                $stmt->execute([$id]);
                $berita = $stmt->fetch();
                if ($berita && $berita['gambar_utama']) {
                    deleteFile($berita['gambar_utama']);
                }
                
                $stmt = $pdo->prepare("DELETE FROM berita WHERE id = ?");
                $stmt->execute([$id]);
                setFlashMessage('success', 'Berita berhasil dihapus.');
            }
        }
    }
    header('Location: berita.php');
    exit;
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (judul LIKE ? OR konten LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM berita WHERE $where");
$stmt->execute($params);
$total = $stmt->fetch()['total'];
$totalPages = ceil($total / $perPage);

$stmt = $pdo->prepare("
    SELECT b.*, u.nama_lengkap as admin_nama 
    FROM berita b 
    LEFT JOIN users u ON b.admin_id = u.id 
    WHERE $where 
    ORDER BY b.created_at DESC 
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$berita_list = $stmt->fetchAll();

$edit_berita = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM berita WHERE id = ?");
    $stmt->execute([$id]);
    $edit_berita = $stmt->fetch();
}

$pageTitle = 'Kelola Berita - ' . APP_NAME;
include '../includes/header.php';

$flash = getFlashMessage();
if ($flash):
?>
    <div class="container mx-auto px-4 pt-4">
        <div class="bg-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-4">
            <?php echo htmlspecialchars($flash['message']); ?>
        </div>
    </div>
<?php endif; ?>

<div class="container mx-auto px-4 py-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Kelola Berita</h1>
            <p class="text-gray-600">Manajemen berita desa</p>
        </div>
        <button onclick="document.getElementById('formModal').classList.remove('hidden')" 
                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
            <i class="fas fa-plus mr-2"></i>Tambah Berita
        </button>
    </div>

    <form method="GET" class="mb-6">
        <div class="flex gap-2">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                   placeholder="Cari berita..." 
                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
            <?php if ($search): ?>
                <a href="berita.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition">
                    Reset
                </a>
            <?php endif; ?>
        </div>
    </form>

    <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Judul</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Views</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php if (empty($berita_list)): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">Tidak ada berita.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($berita_list as $berita): ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="font-medium text-gray-800"><?php echo htmlspecialchars($berita['judul']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars(substr(strip_tags($berita['konten']), 0, 50)) . '...'; ?></div>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded text-xs font-semibold <?php echo $berita['status'] === 'dipublikasi' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'; ?>">
                                    <?php echo ucfirst($berita['status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-gray-600"><?php echo $berita['views']; ?></td>
                            <td class="px-6 py-4 text-gray-600"><?php echo formatTanggal($berita['created_at']); ?></td>
                            <td class="px-6 py-4">
                                <div class="flex gap-2">
                                    <a href="?edit=<?php echo $berita['id']; ?>" class="text-blue-600 hover:text-blue-700">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form method="POST" class="inline" onsubmit="return confirm('Yakin hapus berita ini?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $berita['id']; ?>">
                                        <button type="submit" class="text-red-600 hover:text-red-700">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo generatePagination($page, $totalPages, BASE_URL . 'admin/berita.php'); ?>
</div>

<div id="formModal" class="<?php echo $edit_berita ? '' : 'hidden'; ?> fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800"><?php echo $edit_berita ? 'Edit' : 'Tambah'; ?> Berita</h2>
            <button onclick="document.getElementById('formModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo $edit_berita ? 'update' : 'create'; ?>">
            <?php if ($edit_berita): ?>
                <input type="hidden" name="id" value="<?php echo $edit_berita['id']; ?>">
            <?php endif; ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Judul *</label>
                <input type="text" name="judul" value="<?php echo htmlspecialchars($edit_berita['judul'] ?? ''); ?>" 
                       required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Konten *</label>
                <textarea name="konten" rows="10" required 
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($edit_berita['konten'] ?? ''); ?></textarea>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Gambar Utama</label>
                <?php if ($edit_berita && $edit_berita['gambar_utama']): ?>
                    <img src="<?php echo upload_url($edit_berita['gambar_utama']); ?>" alt="Current" class="w-32 h-32 object-cover rounded mb-2">
                <?php endif; ?>
                <input type="file" name="gambar_utama" accept="image/*" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="draft" <?php echo ($edit_berita['status'] ?? '') === 'draft' ? 'selected' : ''; ?>>Draft</option>
                    <option value="dipublikasi" <?php echo ($edit_berita['status'] ?? '') === 'dipublikasi' ? 'selected' : ''; ?>>Dipublikasi</option>
                </select>
            </div>

            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                    Simpan
                </button>
                <button type="button" onclick="document.getElementById('formModal').classList.add('hidden')" 
                        class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition">
                    Batal
                </button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>


