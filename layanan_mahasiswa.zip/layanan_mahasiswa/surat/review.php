<?php
require_once '../config/config.php';
requireRole(['admin', 'dosen', 'pimpinan']);

$pageTitle = 'Review Surat';
$currentModule = 'surat';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$surat = $conn->query("
    SELECT s.*, m.nim, m.nama_mahasiswa
    FROM surat s 
    LEFT JOIN mahasiswa m ON s.mahasiswa_id = m.id 
    WHERE s.id = $id
")->fetch_assoc();

if (!$surat || $surat['status'] !== 'menunggu') {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($surat['tujuan'] !== 'dosen' || $surat['tujuan_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'pimpinan') {
    $pimpinan = $conn->query("SELECT id FROM pimpinan WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($surat['tujuan'] !== 'pimpinan' || $surat['tujuan_id'] != $pimpinan['id']) {
        header('Location: index.php');
        exit;
    }
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $catatan = sanitize($_POST['catatan'] ?? '');
    
    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE surat SET status = 'approved', catatan = ? WHERE id = ?");
        $stmt->bind_param("si", $catatan, $id);
        if ($stmt->execute()) {
            $success = 'Surat berhasil disetujui';
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    } elseif ($action === 'tolak') {
        $stmt = $conn->prepare("UPDATE surat SET status = 'ditolak', catatan = ? WHERE id = ?");
        $stmt->bind_param("si", $catatan, $id);
        if ($stmt->execute()) {
            $success = 'Surat ditolak';
            header('Location: detail.php?id=' . $id);
            exit;
        }
        $stmt->close();
    } elseif ($action === 'proses' && $_SESSION['role'] === 'admin') {
        $conn->query("UPDATE surat SET status = 'diproses' WHERE id = $id");
        $success = 'Status diupdate menjadi diproses';
        header('Location: detail.php?id=' . $id);
        exit;
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Review Surat</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Surat -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4"><?= htmlspecialchars($surat['perihal']) ?></h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <p class="text-gray-600 text-sm">Nomor Surat</p>
                <p class="font-semibold"><?= htmlspecialchars($surat['nomor_surat'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Mahasiswa</p>
                <p class="font-semibold"><?= htmlspecialchars($surat['nim'] ?? '') ?> - <?= htmlspecialchars($surat['nama_mahasiswa'] ?? '') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jenis</p>
                <p class="font-semibold"><?= ucfirst($surat['jenis']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Tujuan</p>
                <p class="font-semibold"><?= ucfirst($surat['tujuan']) ?></p>
            </div>
        </div>
        
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Isi Surat</p>
            <div class="bg-gray-50 p-4 rounded border">
                <p class="whitespace-pre-wrap"><?= nl2br(htmlspecialchars($surat['isi_surat'])) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Form Review -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Review Surat</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Catatan</label>
                <textarea name="catatan" rows="4" 
                          placeholder="Masukkan catatan atau saran..."
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            
            <div class="flex space-x-4">
                <button type="submit" name="action" value="approve" 
                        class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-check mr-2"></i>Setujui
                </button>
                <button type="submit" name="action" value="tolak" 
                        class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">
                    <i class="fas fa-times mr-2"></i>Tolak
                </button>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <button type="submit" name="action" value="proses" 
                        class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-cog mr-2"></i>Proses
                </button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



