<?php
require_once '../../config/config.php';
requireRole(['admin']);

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$dosen = $conn->query("SELECT * FROM dosen WHERE id = $id")->fetch_assoc();

if ($dosen) {
    // Check if dosen has related data
    $check_mahasiswa = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE dosen_wali_id = $id")->fetch_assoc()['total'];
    $check_krs = $conn->query("SELECT COUNT(*) as total FROM krs k JOIN mahasiswa m ON k.mahasiswa_id = m.id WHERE m.dosen_wali_id = $id")->fetch_assoc()['total'];
    
    if ($check_mahasiswa > 0 || $check_krs > 0) {
        // Set status to inactive instead of delete
        $conn->query("UPDATE dosen SET status = 'inactive' WHERE id = $id");
        if ($dosen['user_id']) {
            $conn->query("UPDATE users SET status = 'inactive' WHERE id = " . $dosen['user_id']);
        }
        $_SESSION['success'] = 'Dosen dinonaktifkan karena memiliki data terkait';
    } else {
        // Safe to delete
        if ($dosen['user_id']) {
            $conn->query("DELETE FROM users WHERE id = " . $dosen['user_id']);
        }
        $conn->query("DELETE FROM dosen WHERE id = $id");
        $_SESSION['success'] = 'Data dosen berhasil dihapus';
    }
}

$conn->close();
header('Location: index.php');
exit;
?>



