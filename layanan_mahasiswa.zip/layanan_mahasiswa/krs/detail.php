<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Detail KRS';
$currentModule = 'krs';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// Get KRS with mahasiswa info
$krs = $conn->query("
    SELECT k.*, m.nim, m.nama_mahasiswa, m.semester as mhs_semester, p.nama_prodi
    FROM krs k 
    JOIN mahasiswa m ON k.mahasiswa_id = m.id 
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    WHERE k.id = $id
")->fetch_assoc();

if (!$krs) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($krs['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    $mhs = $conn->query("SELECT dosen_wali_id FROM mahasiswa WHERE id = " . $krs['mahasiswa_id'])->fetch_assoc();
    if ($mhs['dosen_wali_id'] != $dosen['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get KRS details (mata kuliah)
$krs_detail = $conn->query("
    SELECT kd.*, mk.kode_mk, mk.nama_mk, mk.sks, mk.jenis, j.hari, j.jam_mulai, j.jam_selesai, j.kelas, j.ruangan
    FROM krs_detail kd
    JOIN mata_kuliah mk ON kd.mk_id = mk.id
    LEFT JOIN jadwal_kuliah j ON kd.jadwal_id = j.id
    WHERE kd.krs_id = $id
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail KRS</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info KRS -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi KRS</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if ($_SESSION['role'] !== 'mahasiswa'): ?>
            <div>
                <p class="text-gray-600 text-sm">NIM</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($krs['nim']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama Mahasiswa</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($krs['nama_mahasiswa']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($krs['nama_prodi']) ?></p>
            </div>
            <?php endif; ?>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $krs['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Tahun Akademik</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($krs['tahun_akademik']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Total SKS</p>
                <p class="font-semibold text-gray-800"><?= $krs['sks_diambil'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($krs['status']) ?></p>
            </div>
            <?php if ($krs['catatan_dosen']): ?>
            <div class="md:col-span-2">
                <p class="text-gray-600 text-sm">Catatan Dosen</p>
                <p class="text-gray-800 bg-yellow-50 p-3 rounded"><?= nl2br(htmlspecialchars($krs['catatan_dosen'])) ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Mata Kuliah -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <h2 class="text-xl font-bold text-gray-800 p-6 pb-0">Mata Kuliah</h2>
        <div class="overflow-x-auto p-6">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Nama MK</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Jenis</th>
                        <th class="px-4 py-2 text-left">Jadwal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($krs_detail)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Belum ada mata kuliah</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_detail as $d): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($d['kode_mk']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($d['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $d['sks'] ?></td>
                            <td class="px-4 py-2">
                                <span class="px-2 py-1 rounded text-xs <?= $d['jenis'] === 'wajib' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>">
                                    <?= ucfirst($d['jenis']) ?>
                                </span>
                            </td>
                            <td class="px-4 py-2">
                                <?php if ($d['hari']): ?>
                                    <?= htmlspecialchars($d['hari']) ?>, <?= date('H:i', strtotime($d['jam_mulai'])) ?>-<?= date('H:i', strtotime($d['jam_selesai'])) ?>
                                    <br><small class="text-gray-500"><?= htmlspecialchars($d['kelas']) ?> | <?= htmlspecialchars($d['ruangan'] ?? '-') ?></small>
                                <?php else: ?>
                                    <span class="text-gray-400">Belum ada jadwal</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Actions -->
    <?php if ($_SESSION['role'] === 'dosen' && $krs['status'] === 'menunggu_approval'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex space-x-4">
            <a href="review.php?id=<?= $id ?>" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-check mr-2"></i>Review KRS
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



