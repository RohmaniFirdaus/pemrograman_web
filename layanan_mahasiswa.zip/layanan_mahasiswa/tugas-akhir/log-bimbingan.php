<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen']);

$pageTitle = 'Log Bimbingan';
$currentModule = 'tugas-akhir';

$ta_id = intval($_GET['id'] ?? 0);
if (!$ta_id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$ta = $conn->query("
    SELECT ta.*, m.nim, m.nama_mahasiswa
    FROM tugas_akhir ta
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    WHERE ta.id = $ta_id
")->fetch_assoc();

if (!$ta) {
    header('Location: index.php');
    exit;
}

// Check access
if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    if ($ta['mahasiswa_id'] != $mhs['id']) {
        header('Location: index.php');
        exit;
    }
}

// Get log bimbingan
$logs = $conn->query("
    SELECT lb.*, d.nama_dosen, jb.tanggal, jb.waktu
    FROM log_bimbingan lb
    LEFT JOIN dosen d ON lb.dosen_id = d.id
    LEFT JOIN jadwal_bimbingan jb ON lb.jadwal_id = jb.id
    WHERE lb.ta_id = $ta_id
    ORDER BY lb.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'tambah' && $_SESSION['role'] === 'dosen') {
        $catatan = sanitize($_POST['catatan'] ?? '');
        $jadwal_id = intval($_POST['jadwal_id'] ?? 0);
        
        if ($catatan) {
            $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
            $jadwal_id = $jadwal_id > 0 ? $jadwal_id : null;
            $stmt = $conn->prepare("INSERT INTO log_bimbingan (ta_id, dosen_id, jadwal_id, catatan) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiis", $ta_id, $dosen['id'], $jadwal_id, $catatan);
            if ($stmt->execute()) {
                $success = 'Catatan berhasil ditambahkan';
                header('Location: log-bimbingan.php?id=' . $ta_id);
                exit;
            }
            $stmt->close();
        }
    }
}

// Get jadwal for dropdown
$jadwal_list = [];
if ($_SESSION['role'] === 'dosen') {
    $jadwal_list = $conn->query("
        SELECT * FROM jadwal_bimbingan 
        WHERE ta_id = $ta_id 
        ORDER BY tanggal DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Log Bimbingan</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info TA -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($ta['judul_ta']) ?></h2>
        <p class="text-gray-600"><?= htmlspecialchars($ta['nim']) ?> - <?= htmlspecialchars($ta['nama_mahasiswa']) ?></p>
    </div>
    
    <!-- Form Tambah Catatan (Dosen) -->
    <?php if ($_SESSION['role'] === 'dosen'): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Tambah Catatan</h2>
        <form method="POST">
            <input type="hidden" name="action" value="tambah">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Jadwal Bimbingan (Opsional)</label>
                <select name="jadwal_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih Jadwal</option>
                    <?php foreach ($jadwal_list as $j): ?>
                        <option value="<?= $j['id'] ?>">
                            <?= formatTanggal($j['tanggal']) ?> - <?= date('H:i', strtotime($j['waktu'])) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Catatan *</label>
                <textarea name="catatan" required rows="5"
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-plus mr-2"></i>Tambah Catatan
            </button>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- List Log -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Log Bimbingan</h2>
        <div class="space-y-4">
            <?php if (empty($logs)): ?>
                <p class="text-gray-500 text-center py-8">Belum ada log bimbingan</p>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                <div class="border-l-4 border-green-500 pl-4 py-3 bg-gray-50 rounded">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <p class="font-semibold text-gray-800"><?= htmlspecialchars($log['nama_dosen'] ?? 'Dosen') ?></p>
                            <?php if ($log['tanggal']): ?>
                            <p class="text-sm text-gray-600">
                                <i class="far fa-calendar mr-1"></i><?= formatTanggal($log['tanggal']) ?>
                                <i class="far fa-clock ml-3 mr-1"></i><?= date('H:i', strtotime($log['waktu'])) ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        <p class="text-sm text-gray-500"><?= formatTanggalWaktu($log['created_at']) ?></p>
                    </div>
                    <p class="text-gray-700"><?= nl2br(htmlspecialchars($log['catatan'])) ?></p>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



