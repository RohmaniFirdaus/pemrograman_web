<?php
require_once 'includes/auth.php';

$page_title = 'Login Warga';
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($identifier) || empty($password)) {
        $message = 'Silakan isi NIK/Email dan Password.';
        $message_type = 'danger';
    } elseif (user_login($identifier, $password)) {
        header('Location: user_dashboard.php');
        exit;
    } else {
        $message = 'Data login tidak valid atau akun dinonaktifkan.';
        $message_type = 'danger';
    }
}

include 'includes/header.php';
?>

<div class="container card" style="max-width: 480px; margin-top: 60px;">
    <div class="card-header text-center">
        <h2>Login Sistem Desa</h2>
    </div>
    <form action="user_login.php" method="POST" class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="form-group mb-3">
            <label for="identifier">NIK atau Email</label>
            <input type="text" id="identifier" name="identifier" required value="<?php echo esc($_POST['identifier'] ?? ''); ?>">
        </div>
        <div class="form-group mb-4">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block w-100">Masuk</button>
        <p class="text-center mt-3">Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
    </form>
</div>

<?php include 'includes/footer.php'; ?>