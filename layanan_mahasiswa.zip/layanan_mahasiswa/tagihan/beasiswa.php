<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa']);

$pageTitle = 'Beasiswa';
$currentModule = 'tagihan';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $beasiswa_list = $conn->query("
        SELECT * FROM beasiswa 
        WHERE mahasiswa_id = " . $mahasiswa['id'] . "
        ORDER BY created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin
    $beasiswa_list = $conn->query("
        SELECT b.*, m.nim, m.nama_mahasiswa
        FROM beasiswa b
        JOIN mahasiswa m ON b.mahasiswa_id = m.id
        ORDER BY b.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION['role'] === 'admin') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'tambah') {
        $mahasiswa_id = intval($_POST['mahasiswa_id'] ?? 0);
        $nama_beasiswa = sanitize($_POST['nama_beasiswa'] ?? '');
        $jenis = $_POST['jenis'] ?? '';
        $nominal = floatval($_POST['nominal'] ?? 0);
        $semester = intval($_POST['semester'] ?? 0);
        $tahun_akademik = sanitize($_POST['tahun_akademik'] ?? '');
        
        if ($mahasiswa_id && $nama_beasiswa && $jenis && $nominal > 0) {
            $stmt = $conn->prepare("INSERT INTO beasiswa (mahasiswa_id, nama_beasiswa, jenis, nominal, semester, tahun_akademik, status, tanggal_pengajuan) VALUES (?, ?, ?, ?, ?, ?, 'pending', CURDATE())");
            $jenis_db = $jenis === 'penuh' ? 'penuh' : '50_persen';
            $stmt->bind_param("ississ", $mahasiswa_id, $nama_beasiswa, $jenis_db, $nominal, $semester, $tahun_akademik);
            if ($stmt->execute()) {
                $success = 'Beasiswa berhasil ditambahkan';
                header('Location: beasiswa.php?success=1');
                exit;
            }
            $stmt->close();
        }
    } elseif ($action === 'approve') {
        $beasiswa_id = intval($_POST['beasiswa_id'] ?? 0);
        $conn->query("UPDATE beasiswa SET status = 'approved', tanggal_approve = CURDATE() WHERE id = $beasiswa_id");
        $success = 'Beasiswa disetujui';
        header('Location: beasiswa.php?success=1');
        exit;
    } elseif ($action === 'cairkan') {
        $beasiswa_id = intval($_POST['beasiswa_id'] ?? 0);
        $conn->query("UPDATE beasiswa SET status = 'dicairkan', tanggal_pencairan = CURDATE() WHERE id = $beasiswa_id");
        
        // Update tagihan jika beasiswa dicairkan
        $beasiswa = $conn->query("SELECT * FROM beasiswa WHERE id = $beasiswa_id")->fetch_assoc();
        if ($beasiswa) {
            $conn->query("
                UPDATE tagihan SET 
                    status = 'lunas',
                    total_bayar = total_tagihan,
                    sisa_tagihan = 0
                WHERE mahasiswa_id = " . $beasiswa['mahasiswa_id'] . "
                AND semester = " . $beasiswa['semester'] . "
                AND tahun_akademik = '" . $beasiswa['tahun_akademik'] . "'
            ");
        }
        
        $success = 'Beasiswa dicairkan dan tagihan diupdate';
        header('Location: beasiswa.php?success=1');
        exit;
    }
}

// Get mahasiswa list for admin
$mahasiswa_list = [];
if ($_SESSION['role'] === 'admin') {
    $mahasiswa_list = $conn->query("
        SELECT m.*, p.nama_prodi 
        FROM mahasiswa m 
        LEFT JOIN program_studi p ON m.prodi_id = p.id
        WHERE m.status = 'active'
        ORDER BY m.nim
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Beasiswa</h1>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <button onclick="document.getElementById('modalTambah').classList.remove('hidden')" 
                class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-plus mr-2"></i>Tambah Beasiswa
        </button>
        <?php endif; ?>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <!-- List Beasiswa -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <?php endif; ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama Beasiswa</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Jenis</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nominal</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($beasiswa_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '8' : '6' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada data beasiswa</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($beasiswa_list as $b): ?>
                        <tr class="hover:bg-gray-50">
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($b['nim'] ?? '') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($b['nama_mahasiswa'] ?? '') ?></td>
                            <?php endif; ?>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($b['nama_beasiswa']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?= $b['jenis'] === 'penuh' ? 'Penuh' : '50%' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= formatRupiah($b['nominal']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $b['semester'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($b['status']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if ($b['status'] === 'pending'): ?>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="beasiswa_id" value="<?= $b['id'] ?>">
                                    <button type="submit" class="text-green-600 hover:text-green-700 mr-3">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                </form>
                                <?php elseif ($b['status'] === 'approved'): ?>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="action" value="cairkan">
                                    <input type="hidden" name="beasiswa_id" value="<?= $b['id'] ?>">
                                    <button type="submit" class="text-blue-600 hover:text-blue-700">
                                        <i class="fas fa-money-bill-wave"></i> Cairkan
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Beasiswa (Admin) -->
<?php if ($_SESSION['role'] === 'admin'): ?>
<div id="modalTambah" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-xl font-bold mb-4">Tambah Beasiswa</h3>
        <form method="POST">
            <input type="hidden" name="action" value="tambah">
            <div class="space-y-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Mahasiswa</label>
                    <select name="mahasiswa_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Mahasiswa</option>
                        <?php foreach ($mahasiswa_list as $m): ?>
                            <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['nim']) ?> - <?= htmlspecialchars($m['nama_mahasiswa']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama Beasiswa</label>
                    <input type="text" name="nama_beasiswa" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jenis</label>
                    <select name="jenis" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Jenis</option>
                        <option value="penuh">Penuh</option>
                        <option value="50_persen">50%</option>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nominal</label>
                    <input type="number" name="nominal" required min="0" step="1000"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester</label>
                    <input type="number" name="semester" required min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tahun Akademik</label>
                    <input type="text" name="tahun_akademik" required placeholder="2024/2025"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                </div>
            </div>
            <div class="mt-6 flex justify-end space-x-2">
                <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')" 
                        class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </button>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>



