<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Detail Dosen';
$currentModule = 'data-akademik';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$conn = getDBConnection();
$dosen = $conn->query("
    SELECT d.*, p.nama_prodi, u.username
    FROM dosen d 
    LEFT JOIN program_studi p ON d.prodi_id = p.id
    LEFT JOIN users u ON d.user_id = u.id
    WHERE d.id = $id
")->fetch_assoc();

if (!$dosen) {
    header('Location: index.php');
    exit;
}

// Get mata kuliah yang diajar
$mata_kuliah = $conn->query("
    SELECT DISTINCT mk.*, j.semester as jadwal_semester, j.tahun_akademik, j.kelas
    FROM mata_kuliah mk
    JOIN jadwal_kuliah j ON mk.id = j.mk_id
    WHERE j.dosen_id = $id
    ORDER BY mk.semester, mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

// Get mahasiswa bimbingan (dosen wali)
$mahasiswa_wali = $conn->query("
    SELECT m.*, p.nama_prodi
    FROM mahasiswa m
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    WHERE m.dosen_wali_id = $id
    ORDER BY m.nim
")->fetch_all(MYSQLI_ASSOC);

// Get tugas akhir yang dibimbing
$tugas_akhir = $conn->query("
    SELECT ta.*, m.nim, m.nama_mahasiswa
    FROM tugas_akhir ta
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    WHERE ta.dosen_pembimbing1_id = $id OR ta.dosen_pembimbing2_id = $id
    ORDER BY ta.created_at DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Dosen</h1>
        <div class="flex space-x-2">
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="edit.php?id=<?= $id ?>" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-edit mr-2"></i>Edit
            </a>
            <?php endif; ?>
            <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <!-- Info Dosen -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Dosen</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">NIP</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nip']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nama_dosen']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['nama_prodi'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jabatan</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['jabatan'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Email</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['email'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">No. HP</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['no_hp'] ?? '-') ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($dosen['status']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Username</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($dosen['username'] ?? '-') ?></p>
            </div>
        </div>
    </div>
    
    <!-- Mata Kuliah yang Diajar -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah yang Diajar</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Nama Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Kelas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($mata_kuliah)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Belum ada mata kuliah</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($mata_kuliah as $mk): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($mk['kode_mk']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($mk['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $mk['sks'] ?></td>
                            <td class="px-4 py-2"><?= $mk['semester'] ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($mk['kelas'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Mahasiswa Bimbingan (Dosen Wali) -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Mahasiswa Bimbingan (Dosen Wali)</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Prodi</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($mahasiswa_wali)): ?>
                        <tr>
                            <td colspan="6" class="px-4 py-4 text-center text-gray-500">Belum ada mahasiswa bimbingan</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($mahasiswa_wali as $m): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($m['nim']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($m['nama_mahasiswa']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($m['nama_prodi']) ?></td>
                            <td class="px-4 py-2"><?= $m['semester'] ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($m['status']) ?></td>
                            <td class="px-4 py-2">
                                <a href="../mahasiswa/detail.php?id=<?= $m['id'] ?>" class="text-blue-600 hover:text-blue-700" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Tugas Akhir yang Dibimbing -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Tugas Akhir yang Dibimbing</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama Mahasiswa</th>
                        <th class="px-4 py-2 text-left">Judul TA</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-left">Progress</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($tugas_akhir)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Belum ada tugas akhir</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($tugas_akhir as $ta): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($ta['nim']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($ta['nama_mahasiswa']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars(substr($ta['judul_ta'], 0, 50)) ?><?= strlen($ta['judul_ta']) > 50 ? '...' : '' ?></td>
                            <td class="px-4 py-2"><?= getStatusBadge($ta['status']) ?></td>
                            <td class="px-4 py-2"><?= $ta['progress'] ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>




