<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Dashboard Mahasiswa';
$currentModule = 'dashboard';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT m.*, p.nama_prodi FROM mahasiswa m JOIN program_studi p ON m.prodi_id = p.id WHERE m.user_id = " . $user['id'])->fetch_assoc();

$nilai_terbaru = $conn->query("SELECT n.*, mk.nama_mk, mk.sks FROM nilai n JOIN mata_kuliah mk ON n.mk_id = mk.id WHERE n.mahasiswa_id = " . $mahasiswa['id'] . " ORDER BY n.created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

$tagihan_aktif = $conn->query("SELECT * FROM tagihan WHERE mahasiswa_id = " . $mahasiswa['id'] . " AND status IN ('open', 'pending') ORDER BY created_at DESC LIMIT 1")->fetch_assoc();

$hari_ini = date('N'); 
$hari_map = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu'];
$hari_nama = $hari_map[$hari_ini] ?? '';

$jadwal_hari_ini = [];
if ($hari_nama) {
    $krs_aktif = $conn->query("SELECT id FROM krs WHERE mahasiswa_id = " . $mahasiswa['id'] . " AND status = 'approved' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
    if ($krs_aktif) {
        $jadwal_hari_ini = $conn->query("
            SELECT j.*, mk.nama_mk, mk.kode_mk, d.nama_dosen 
            FROM jadwal_kuliah j
            JOIN mata_kuliah mk ON j.mk_id = mk.id
            JOIN dosen d ON j.dosen_id = d.id
            JOIN krs_detail kd ON j.id = kd.jadwal_id
            WHERE kd.krs_id = " . $krs_aktif['id'] . " AND j.hari = '$hari_nama'
            ORDER BY j.jam_mulai
        ")->fetch_all(MYSQLI_ASSOC);
    }
}

$pengumuman = $conn->query("SELECT * FROM pengumuman WHERE status = 'published' ORDER BY created_at DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);

$krs_status = $conn->query("SELECT status FROM krs WHERE mahasiswa_id = " . $mahasiswa['id'] . " ORDER BY created_at DESC LIMIT 1")->fetch_assoc();

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Dashboard Mahasiswa</h1>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Akademik</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <p class="text-gray-600">Prodi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600">Semester</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600">IPK</p>
                <p class="font-semibold text-gray-800"><?= number_format($mahasiswa['ipk'], 2) ?></p>
            </div>
            <div>
                <p class="text-gray-600">SKS Tempuh</p>
                <p class="font-semibold text-gray-800"><?= $mahasiswa['sks_tempuh'] ?></p>
            </div>
        </div>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-semibold text-gray-800 mb-2">Status KRS</h3>
            <?php if ($krs_status): ?>
                <?= getStatusBadge($krs_status['status']) ?>
            <?php else: ?>
                <span class="text-gray-500">Belum ada KRS</span>
            <?php endif; ?>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-semibold text-gray-800 mb-2">Tagihan Aktif</h3>
            <?php if ($tagihan_aktif): ?>
                <p class="text-2xl font-bold text-gray-800"><?= formatRupiah($tagihan_aktif['sisa_tagihan']) ?></p>
                <p class="text-sm text-gray-600">Jatuh Tempo: <?= formatTanggal($tagihan_aktif['jatuh_tempo']) ?></p>
            <?php else: ?>
                <span class="text-green-600">Tidak ada tagihan</span>
            <?php endif; ?>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="font-semibold text-gray-800 mb-2">Jadwal Hari Ini</h3>
            <?php if (!empty($jadwal_hari_ini)): ?>
                <p class="text-2xl font-bold text-gray-800"><?= count($jadwal_hari_ini) ?></p>
                <p class="text-sm text-gray-600">Mata Kuliah</p>
            <?php else: ?>
                <span class="text-gray-500">Tidak ada jadwal</span>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Nilai Terbaru (Semester)</h2>
            <a href="<?= BASE_URL ?>nilai/khs.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat KHS Lengkap <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($nilai_terbaru)): ?>
                        <tr>
                            <td colspan="3" class="px-4 py-4 text-center text-gray-500">Belum ada nilai</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($nilai_terbaru as $n): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= $n['sks'] ?></td>
                            <td class="px-4 py-2">
                                <span class="font-semibold"><?= $n['nilai_huruf'] ?></span>
                                <span class="text-gray-600">(<?= number_format($n['nilai_angka'], 2) ?>)</span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Pengumuman Terbaru</h2>
            <a href="#" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="space-y-3">
            <?php if (empty($pengumuman)): ?>
                <p class="text-gray-500 text-center py-4">Tidak ada pengumuman</p>
            <?php else: ?>
                <?php foreach ($pengumuman as $p): ?>
                <div class="border-l-4 border-green-600 pl-4 py-2">
                    <p class="font-semibold text-gray-800"><?= htmlspecialchars($p['judul']) ?></p>
                    <p class="text-sm text-gray-600"><?= substr(htmlspecialchars($p['isi']), 0, 100) ?>...</p>
                    <p class="text-xs text-gray-500 mt-1"><?= formatTanggal($p['created_at']) ?></p>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



