<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Buat Pengaduan';
$currentModule = 'pengaduan';

$user = getCurrentUser();
$conn = getDBConnection();
$mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$conn->close();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kategori = sanitize($_POST['kategori'] ?? '');
    $sub_kategori = sanitize($_POST['sub_kategori'] ?? '');
    $judul = sanitize($_POST['judul_pengaduan'] ?? '');
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');
    $saran = sanitize($_POST['saran'] ?? '');
    $prioritas = $_POST['prioritas'] ?? 'medium';
    
    if (empty($kategori) || empty($judul) || empty($deskripsi) || strlen($deskripsi) < 50) {
        $error = 'Kategori, judul, dan deskripsi (min. 50 karakter) wajib diisi';
    } else {
        $conn = getDBConnection();
        
        // Generate kode pengaduan
        $count = $conn->query("SELECT COUNT(*) as total FROM pengaduan")->fetch_assoc()['total'];
        $kode = 'PENG' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        
        $stmt = $conn->prepare("INSERT INTO pengaduan (kode_pengaduan, mahasiswa_id, kategori, sub_kategori, judul_pengaduan, deskripsi, saran, prioritas, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'menunggu')");
        $stmt->bind_param("sissssss", $kode, $mahasiswa['id'], $kategori, $sub_kategori, $judul, $deskripsi, $saran, $prioritas);
        
        if ($stmt->execute()) {
            $pengaduan_id = $conn->insert_id;
            
            // Handle file uploads
            if (!empty($_FILES['lampiran']['name'][0])) {
                $uploaded = 0;
                foreach ($_FILES['lampiran']['name'] as $key => $name) {
                    if ($uploaded >= 3) break; // Max 3 files
                    
                    $file = [
                        'name' => $name,
                        'type' => $_FILES['lampiran']['type'][$key],
                        'tmp_name' => $_FILES['lampiran']['tmp_name'][$key],
                        'error' => $_FILES['lampiran']['error'][$key],
                        'size' => $_FILES['lampiran']['size'][$key]
                    ];
                    
                    $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'svg', 'mp4'];
                    $upload = uploadFile($file, UPLOAD_PENGADUAN, $allowed);
                    
                    if ($upload['success']) {
                        $stmt2 = $conn->prepare("INSERT INTO lampiran_pengaduan (pengaduan_id, nama_file, path_file, tipe_file, ukuran_file) VALUES (?, ?, ?, ?, ?)");
                        $tipe = pathinfo($name, PATHINFO_EXTENSION);
                        $stmt2->bind_param("isssi", $pengaduan_id, $name, $upload['path'], $tipe, $upload['size']);
                        $stmt2->execute();
                        $stmt2->close();
                        $uploaded++;
                    }
                }
            }
            
            // Add timeline
            $conn->query("INSERT INTO timeline_pengaduan (pengaduan_id, status, komentar) VALUES ($pengaduan_id, 'menunggu', 'Pengaduan dibuat')");
            
            $success = 'Pengaduan berhasil dibuat';
            header('Location: detail.php?id=' . $pengaduan_id);
            exit;
        } else {
            $error = 'Gagal membuat pengaduan';
        }
        
        $stmt->close();
        $conn->close();
    }
}

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Buat Pengaduan Baru</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST" enctype="multipart/form-data">
            <!-- Informasi Pengirim -->
            <div class="mb-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Pengirim</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">Nama</label>
                        <input type="text" value="<?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?>" disabled
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100">
                    </div>
                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">NIM</label>
                        <input type="text" value="<?= htmlspecialchars($mahasiswa['nim']) ?>" disabled
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100">
                    </div>
                </div>
            </div>
            
            <!-- Detail Pengaduan -->
            <div class="mb-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Detail Pengaduan</h2>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Kategori *</label>
                    <select name="kategori" required id="kategori"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Kategori</option>
                        <option value="Fasilitas & Infrastruktur">Fasilitas & Infrastruktur</option>
                        <option value="Administrasi Akademik">Administrasi Akademik</option>
                        <option value="Pelayanan Kantor">Pelayanan Kantor</option>
                        <option value="Keamanan Kampus">Keamanan Kampus</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Sub-Kategori</label>
                    <select name="sub_kategori" id="sub_kategori"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Sub-Kategori</option>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">(muncul berdasarkan kategori)</p>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Prioritas</label>
                    <div class="flex space-x-4">
                        <label class="flex items-center">
                            <input type="radio" name="prioritas" value="high" class="mr-2">
                            <span class="w-3 h-3 bg-red-500 rounded-full mr-2"></span>High
                        </label>
                        <label class="flex items-center">
                            <input type="radio" name="prioritas" value="medium" checked class="mr-2">
                            <span class="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>Medium
                        </label>
                        <label class="flex items-center">
                            <input type="radio" name="prioritas" value="low" class="mr-2">
                            <span class="w-3 h-3 bg-green-500 rounded-full mr-2"></span>Low
                        </label>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">[Otomatis berdasarkan kategori]</p>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Judul Pengaduan *</label>
                    <input type="text" name="judul_pengaduan" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Deskripsi Detail *</label>
                    <textarea name="deskripsi" required rows="5" minlength="50"
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                              placeholder="Min. 50 karakter"><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea>
                    <p class="text-xs text-gray-500 mt-1">Minimal 50 karakter</p>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Saran</label>
                    <textarea name="saran" rows="3"
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"></textarea>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Lampiran</label>
                    <input type="file" name="lampiran[]" multiple accept=".jpg,.jpeg,.png,.pdf,.svg,.mp4"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <p class="text-xs text-gray-500 mt-1">Maks. 3 file, @5MB, format: jpg, png, pdf, svg, mp4</p>
                </div>
            </div>
            
            <div class="flex justify-end space-x-4">
                <a href="index.php" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-paper-plane mr-2"></i>Kirim Pengaduan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('kategori').addEventListener('change', function() {
    const subKategori = document.getElementById('sub_kategori');
    subKategori.innerHTML = '<option value="">Pilih Sub-Kategori</option>';
    // Add sub-categories based on main category
    // This can be expanded with actual sub-categories
});
</script>

<?php require_once '../includes/footer.php'; ?>



