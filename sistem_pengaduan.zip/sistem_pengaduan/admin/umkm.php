<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = !is_readonly_admin();

$pdo = getConnection();
$page_title = 'Kelola UMKM Desa';
$message = '';
$message_type = '';

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'verify') {
            $stmt = $pdo->prepare("UPDATE umkm SET is_verified = 1 WHERE id = :id");
            $stmt->execute(['id' => $_POST['id']]);
        } elseif ($action === 'unverify') {
            $stmt = $pdo->prepare("UPDATE umkm SET is_verified = 0 WHERE id = :id");
            $stmt->execute(['id' => $_POST['id']]);
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM umkm WHERE id = :id");
            $stmt->execute(['id' => $_POST['id']]);
        } elseif ($action === 'create') {
            $stmt = $pdo->prepare("
                INSERT INTO umkm (id_user, nama_umkm, deskripsi, alamat, telepon, kategori, is_verified)
                VALUES (:user, :nama, :deskripsi, :alamat, :telepon, :kategori, :verified)
            ");
            $stmt->execute([
                'user' => $_POST['id_user'] ?: null,
                'nama' => $_POST['nama_umkm'],
                'deskripsi' => $_POST['deskripsi'],
                'alamat' => $_POST['alamat'],
                'telepon' => $_POST['telepon'],
                'kategori' => $_POST['kategori'],
                'verified' => isset($_POST['verified']) ? 1 : 0
            ]);
        }
        $message = 'Data UMKM berhasil diperbarui.';
        $message_type = 'success';
    } catch (PDOException $e) {
        error_log('UMKM admin error: ' . $e->getMessage());
        $message = 'Terjadi kesalahan.';
        $message_type = 'danger';
    }
}

$umkm_list = [];
$users = [];
try {
    $umkm_list = $pdo->query("
        SELECT u.*, us.nama AS pemilik
        FROM umkm u
        LEFT JOIN users us ON us.id = u.id_user
        ORDER BY u.updated_at DESC
    ")->fetchAll();
    $users = $pdo->query("SELECT id, nama FROM users ORDER BY nama ASC")->fetchAll();
} catch (PDOException $e) {
    error_log('Load umkm error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>UMKM Desa</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <?php if ($can_update): ?>
        <div class="card mb-4">
            <div class="card-header">Tambah UMKM</div>
            <div class="card-body">
                <form action="umkm.php" method="POST">
                    <input type="hidden" name="action" value="create">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama UMKM</label>
                            <input type="text" name="nama_umkm" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pemilik (opsional)</label>
                            <select name="id_user" class="form-control">
                                <option value="">- pilih pemilik -</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo esc($user['id']); ?>"><?php echo esc($user['nama']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="kategori" class="form-control">
                                <?php foreach (['kuliner','kerajinan','jasa','perdagangan','pertanian','lainnya'] as $cat): ?>
                                    <option value="<?php echo $cat; ?>"><?php echo ucfirst($cat); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Telepon</label>
                            <input type="text" name="telepon" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" name="alamat" class="form-control">
                        </div>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="verified" id="verified">
                        <label class="form-check-label" for="verified">Tandai terverifikasi</label>
                    </div>
                    <button class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Daftar UMKM</div>
        <div class="card-body table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama UMKM</th>
                        <th>Kategori</th>
                        <th>Pemilik</th>
                        <th>Telepon</th>
                        <th>Status</th>
                        <?php if ($can_update): ?><th>Aksi</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($umkm_list)): ?>
                        <tr><td colspan="<?php echo $can_update ? 6 : 5; ?>" class="text-center text-muted">Belum ada data.</td></tr>
                    <?php else: ?>
                        <?php foreach ($umkm_list as $item): ?>
                            <tr>
                                <td><?php echo esc($item['nama_umkm']); ?></td>
                                <td><?php echo esc(ucfirst($item['kategori'])); ?></td>
                                <td><?php echo esc($item['pemilik'] ?? '-'); ?></td>
                                <td><?php echo esc($item['telepon'] ?? '-'); ?></td>
                                <td><span class="status-badge status-<?php echo $item['is_verified'] ? 'selesai' : 'menunggu'; ?>"><?php echo $item['is_verified'] ? 'Terverifikasi' : 'Menunggu'; ?></span></td>
                                <?php if ($can_update): ?>
                                    <td class="d-flex gap-2">
                                        <form action="umkm.php" method="POST">
                                            <input type="hidden" name="id" value="<?php echo esc($item['id']); ?>">
                                            <input type="hidden" name="action" value="<?php echo $item['is_verified'] ? 'unverify' : 'verify'; ?>">
                                            <button class="btn btn-outline-primary btn-sm"><?php echo $item['is_verified'] ? 'Batalkan' : 'Verifikasi'; ?></button>
                                        </form>
                                        <form action="umkm.php" method="POST" onsubmit="return confirm('Hapus UMKM ini?');">
                                            <input type="hidden" name="id" value="<?php echo esc($item['id']); ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button class="btn btn-outline-danger btn-sm">Hapus</button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>











