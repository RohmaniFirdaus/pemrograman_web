<?php
require_once '../../config/config.php';
requireRole(['admin']);

$pageTitle = 'Tambah Mahasiswa';
$currentModule = 'data-akademik';

$conn = getDBConnection();
$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);
$conn->close();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nim = sanitize($_POST['nim'] ?? '');
    $nama = sanitize($_POST['nama_mahasiswa'] ?? '');
    $prodi_id = intval($_POST['prodi_id'] ?? 0);
    $dosen_wali_id = intval($_POST['dosen_wali_id'] ?? 0);
    $angkatan = intval($_POST['angkatan'] ?? date('Y'));
    $semester = intval($_POST['semester'] ?? 1);
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($nim) || empty($nama) || empty($username) || empty($password) || !$prodi_id) {
        $error = 'Field yang wajib diisi tidak boleh kosong';
    } else {
        $conn = getDBConnection();
        
        // Check if NIM exists
        $check_nim = $conn->prepare("SELECT id FROM mahasiswa WHERE nim = ?");
        $check_nim->bind_param("s", $nim);
        $check_nim->execute();
        if ($check_nim->get_result()->num_rows > 0) {
            $error = 'NIM sudah digunakan';
        } else {
            // Check if username exists
            $check_user = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $check_user->bind_param("s", $username);
            $check_user->execute();
            if ($check_user->get_result()->num_rows > 0) {
                $error = 'Username sudah digunakan';
            } else {
                // Create user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, password, role, status) VALUES (?, ?, 'mahasiswa', 'active')");
                $stmt->bind_param("ss", $username, $hashed_password);
                $stmt->execute();
                $user_id = $conn->insert_id;
                
                // Create mahasiswa
                $stmt2 = $conn->prepare("INSERT INTO mahasiswa (user_id, nim, nama_mahasiswa, prodi_id, dosen_wali_id, angkatan, semester, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
                $stmt2->bind_param("issiiii", $user_id, $nim, $nama, $prodi_id, $dosen_wali_id, $angkatan, $semester);
                
                if ($stmt2->execute()) {
                    $success = 'Data mahasiswa berhasil ditambahkan';
                    header('Location: index.php?success=1');
                    exit;
                } else {
                    $error = 'Gagal menambahkan data mahasiswa';
                }
                $stmt2->close();
            }
            $check_user->close();
        }
        $check_nim->close();
        $conn->close();
    }
}

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Tambah Mahasiswa</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">NIM *</label>
                    <input type="text" name="nim" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nama Mahasiswa *</label>
                    <input type="text" name="nama_mahasiswa" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Program Studi *</label>
                    <select name="prodi_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Prodi</option>
                        <?php foreach ($prodi_list as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama_prodi']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Dosen Wali</label>
                    <select name="dosen_wali_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Pilih Dosen Wali</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_dosen']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Angkatan</label>
                    <input type="number" name="angkatan" value="<?= date('Y') ?>" min="2000" max="<?= date('Y') + 1 ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Semester</label>
                    <input type="number" name="semester" value="1" min="1" max="6"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Username *</label>
                    <input type="text" name="username" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Password *</label>
                    <input type="password" name="password" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i>Simpan
                </button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



