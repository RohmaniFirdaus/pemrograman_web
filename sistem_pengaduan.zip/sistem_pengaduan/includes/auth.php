<?php
session_start();

require_once __DIR__ . '/config.php';

const SESSION_USER_KEY = 'auth_user';
const ADMIN_ROLES = ['admin', 'petugas'];
const READONLY_ROLES = ['kepala_desa'];
const CITIZEN_ROLES = ['warga'];

function set_current_user(array $user): void {
    $_SESSION[SESSION_USER_KEY] = [
        'id'    => $user['id'],
        'nik'   => $user['nik'] ?? null,
        'nama'  => $user['nama'] ?? ($user['username'] ?? ''),
        'email' => $user['email'] ?? null,
        'role'  => $user['role'] ?? 'warga'
    ];

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_username'] = $_SESSION[SESSION_USER_KEY]['nama'];
    $_SESSION['user_email'] = $_SESSION[SESSION_USER_KEY]['email'];
    $_SESSION['user_role'] = $_SESSION[SESSION_USER_KEY]['role'];

    if (in_array($_SESSION[SESSION_USER_KEY]['role'], ADMIN_ROLES, true)) {
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_username'] = $_SESSION[SESSION_USER_KEY]['nama'];
    }
}

function current_user(): ?array {
    return $_SESSION[SESSION_USER_KEY] ?? null;
}

function is_user_logged_in(): bool {
    return current_user() !== null;
}

function is_admin_logged_in(): bool {
    $user = current_user();
    return $user && in_array($user['role'], ADMIN_ROLES, true);
}

function has_role(array $roles): bool {
    $user = current_user();
    if (!$user) {
        return false;
    }
    return in_array($user['role'], $roles, true);
}

function require_login(string $redirect = 'user_login.php'): void {
    if (!is_user_logged_in()) {
        header('Location: ' . $redirect);
        exit;
    }
}

function require_role(array $roles, string $redirect = 'user_login.php'): void {
    if (!has_role($roles)) {
        header('Location: ' . $redirect);
        exit;
    }
}

function user_logout(): void {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function find_user_by_identifier(string $identifier): ?array {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (nik = :identifier1 OR email = :identifier2) LIMIT 1");
    $stmt->execute([
        'identifier1' => $identifier,
        'identifier2' => $identifier
    ]);
    return $stmt->fetch() ?: null;
}

function user_register(array $data): bool {
    $pdo = getConnection();

    $stmt = $pdo->prepare("
        INSERT INTO users (nik, nama, email, password, telepon, alamat, role, foto_profil)
        VALUES (:nik, :nama, :email, :password, :telepon, :alamat, :role, :foto)
    ");

    $hashed = password_hash($data['password'], PASSWORD_DEFAULT);

    try {
        return $stmt->execute([
            'nik'      => $data['nik'],
            'nama'     => $data['nama'],
            'email'    => $data['email'] ?: null,
            'password' => $hashed,
            'telepon'  => $data['telepon'] ?? null,
            'alamat'   => $data['alamat'] ?? null,
            'role'     => $data['role'] ?? 'warga',
            'foto'     => $data['foto_profil'] ?? null,
        ]);
    } catch (PDOException $e) {
        error_log('User registration error: ' . $e->getMessage());
        return false;
    }
}

function user_login(string $identifier, string $password): bool {
    $user = find_user_by_identifier($identifier);
    if (!$user) {
        return false;
    }
    
    if (empty($user['is_active'])) {
        return false;
    }

    $password_valid = false;
    if (password_verify($password, $user['password'])) {
        $password_valid = true;
    } elseif ($user['password'] === $password) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("UPDATE users SET password = :hashed WHERE id = :id");
            $stmt->execute(['hashed' => $hashed, 'id' => $user['id']]);
            $password_valid = true;
        } catch (PDOException $e) {
            error_log('Password hash update error: ' . $e->getMessage());
            return false;
        }
    }
    
    if (!$password_valid) {
        return false;
    }

    set_current_user($user);
    return true;
}

function admin_login(string $identifier, string $password): bool {
    $user = find_user_by_identifier($identifier);
    if (!$user) {
        return false;
    }
    
    // Cek apakah user aktif
    if (empty($user['is_active'])) {
        return false;
    }
    
    // Cek role
    if (!in_array($user['role'], array_merge(ADMIN_ROLES, READONLY_ROLES), true)) {
        return false;
    }

    // Cek password - support both hashed and plain text (untuk migrasi)
    $password_valid = false;
    if (password_verify($password, $user['password'])) {
        $password_valid = true;
    } elseif ($user['password'] === $password) {
        // Jika password masih plain text, hash dan update
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("UPDATE users SET password = :hashed WHERE id = :id");
            $stmt->execute(['hashed' => $hashed, 'id' => $user['id']]);
            $password_valid = true;
        } catch (PDOException $e) {
            error_log('Password hash update error: ' . $e->getMessage());
            return false;
        }
    }
    
    if (!$password_valid) {
        return false;
    }

    set_current_user($user);
    return true;
}

function ensure_admin(): void {
    require_role(ADMIN_ROLES, 'admin/login.php');
}

function admin_logout(): void {
    user_logout();
}

function ensure_management_access(): void {
    if (!has_role(array_merge(ADMIN_ROLES, READONLY_ROLES))) {
        header('Location: admin/login.php');
        exit;
    }
}

function is_readonly_admin(): bool {
    return has_role(READONLY_ROLES);
}
