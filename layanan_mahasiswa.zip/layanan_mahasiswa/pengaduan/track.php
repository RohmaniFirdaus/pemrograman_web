<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Track Pengaduan';
$currentModule = 'pengaduan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$pengaduan = $conn->query("
    SELECT * FROM pengaduan 
    WHERE id = $id AND mahasiswa_id = " . $mhs['id']
)->fetch_assoc();

if (!$pengaduan) {
    header('Location: index.php');
    exit;
}

// Get timeline
$timeline = $conn->query("
    SELECT t.*, u.username 
    FROM timeline_pengaduan t 
    LEFT JOIN users u ON t.user_id = u.id 
    WHERE t.pengaduan_id = $id 
    ORDER BY t.created_at ASC
")->fetch_all(MYSQLI_ASSOC);

// Get lampiran
$lampiran = $conn->query("SELECT * FROM lampiran_pengaduan WHERE pengaduan_id = $id")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Track Pengaduan</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Pengaduan -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">#<?= htmlspecialchars($pengaduan['kode_pengaduan']) ?></h2>
                <p class="text-gray-600"><?= htmlspecialchars($pengaduan['judul_pengaduan']) ?></p>
            </div>
            <div class="text-right">
                <?= getStatusBadge($pengaduan['status']) ?>
                <span class="px-2 py-1 rounded text-xs font-semibold ml-2 <?= 
                    $pengaduan['prioritas'] === 'high' ? 'bg-red-100 text-red-700' : 
                    ($pengaduan['prioritas'] === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700')
                ?>">
                    <?= strtoupper($pengaduan['prioritas']) ?>
                </span>
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <p class="text-gray-600 text-sm">Kategori</p>
                <p class="font-semibold"><?= htmlspecialchars($pengaduan['kategori']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dibuat</p>
                <p class="font-semibold"><?= formatTanggalWaktu($pengaduan['created_at']) ?></p>
            </div>
        </div>
        
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Deskripsi</p>
            <p class="text-gray-800 bg-gray-50 p-4 rounded"><?= nl2br(htmlspecialchars($pengaduan['deskripsi'])) ?></p>
        </div>
        
        <?php if (!empty($lampiran)): ?>
        <div class="mb-4">
            <p class="text-gray-600 text-sm mb-2">Lampiran</p>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
                <?php foreach ($lampiran as $l): ?>
                <a href="<?= BASE_URL . htmlspecialchars($l['path_file']) ?>" target="_blank" class="border rounded p-2 hover:bg-gray-50">
                    <i class="fas fa-file mr-1"></i><?= htmlspecialchars($l['nama_file']) ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Timeline -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Timeline</h2>
        <div class="space-y-4">
            <?php foreach ($timeline as $t): ?>
            <div class="border-l-4 border-green-500 pl-4 py-3">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="font-semibold text-gray-800"><?= htmlspecialchars($t['status']) ?></p>
                        <?php if ($t['komentar']): ?>
                        <p class="text-gray-600 text-sm mt-1"><?= htmlspecialchars($t['komentar']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="text-right text-sm text-gray-500">
                        <p><?= htmlspecialchars($t['username'] ?? 'System') ?></p>
                        <p><?= formatTanggalWaktu($t['created_at']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Rating (if selesai) -->
    <?php if ($pengaduan['status'] === 'selesai' && !$pengaduan['rating']): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Rating & Feedback</h2>
        <form method="POST" action="detail.php?id=<?= $id ?>">
            <input type="hidden" name="action" value="rating">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Rating</label>
                <select name="rating" required class="px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih Rating</option>
                    <option value="5">5 - Sangat Baik</option>
                    <option value="4">4 - Baik</option>
                    <option value="3">3 - Cukup</option>
                    <option value="2">2 - Kurang</option>
                    <option value="1">1 - Sangat Kurang</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Feedback</label>
                <textarea name="feedback" rows="3" 
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
            </div>
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                Submit Rating
            </button>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



