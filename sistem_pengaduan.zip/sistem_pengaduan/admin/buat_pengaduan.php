<?php
require_once '../includes/auth.php';

ensure_admin();

$page_title = 'Input Pengaduan Warga';
$message = '';
$message_type = '';

$form = [
    'judul' => '',
    'deskripsi' => '',
    'lokasi' => '',
    'id_kategori' => '',
    'prioritas' => 'sedang',
    'id_user' => 'anonim'
];

$pdo = getConnection();

$users_for_select = [];
$categories_for_select = [];

if ($pdo) {
    try {
        $users_for_select = $pdo->query("SELECT id, nama FROM users ORDER BY nama ASC")->fetchAll();
        $categories_for_select = $pdo->query("SELECT id, nama_kategori FROM kategori_pengaduan WHERE is_active = 1 ORDER BY nama_kategori ASC")->fetchAll();
    } catch (PDOException $e) {
        error_log('Admin form data error: ' . $e->getMessage());
        $message = 'Gagal mengambil data referensi.';
        $message_type = 'danger';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['judul'] = trim($_POST['judul'] ?? '');
    $form['deskripsi'] = trim($_POST['deskripsi'] ?? '');
    $form['lokasi'] = trim($_POST['lokasi'] ?? '');
    $form['prioritas'] = $_POST['prioritas'] ?? 'sedang';
    $form['id_kategori'] = $_POST['id_kategori'] ?? '';
    $form['id_user'] = $_POST['id_user'] ?? 'anonim';

    if (empty($form['judul']) || empty($form['deskripsi']) || empty($form['id_kategori'])) {
        $message = 'Judul, deskripsi, dan kategori wajib diisi.';
        $message_type = 'danger';
    } else {
        try {
            $pdo->beginTransaction();
            $kode = 'PGD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));
            $stmt = $pdo->prepare("
                INSERT INTO pengaduan (kode_pengaduan, id_user, id_kategori, judul, deskripsi, lokasi, prioritas, status, tanggal_pengaduan)
                VALUES (:kode, :user, :kategori, :judul, :deskripsi, :lokasi, :prioritas, :status, :tanggal)
            ");
            $stmt->execute([
                'kode' => $kode,
                'user' => $form['id_user'] === 'anonim' ? null : $form['id_user'],
                'kategori' => $form['id_kategori'],
                'judul' => $form['judul'],
                'deskripsi' => $form['deskripsi'],
                'lokasi' => $form['lokasi'],
                'prioritas' => $form['prioritas'],
                'status' => $_POST['status'] ?? 'menunggu',
                'tanggal' => $_POST['tanggal_pengaduan'] ?? date('Y-m-d')
            ]);
            $pengaduan_id = $pdo->lastInsertId();

            if (isset($_FILES['lampiran']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = dirname(__DIR__) . '/uploads/pengaduan/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                $ext = strtolower(pathinfo($_FILES['lampiran']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','pdf'];
                if (in_array($ext, $allowed, true)) {
                    $filename = uniqid('lampiran_') . '.' . $ext;
                    if (move_uploaded_file($_FILES['lampiran']['tmp_name'], $upload_dir . $filename)) {
                        $stmtLampiran = $pdo->prepare("
                            INSERT INTO lampiran_pengaduan (id_pengaduan, nama_file, tipe_file, path_file)
                            VALUES (:id_pengaduan, :nama_file, :tipe_file, :path_file)
                        ");
                        $stmtLampiran->execute([
                            'id_pengaduan' => $pengaduan_id,
                            'nama_file' => $_FILES['lampiran']['name'],
                            'tipe_file' => $ext,
                            'path_file' => 'pengaduan/' . $filename
                        ]);
                    }
                }
            }

            $pdo->commit();
            $message = 'Pengaduan berhasil dicatat dengan nomor tiket ' . esc($kode);
            $message_type = 'success';
            $form = [
                'judul' => '',
                'deskripsi' => '',
                'lokasi' => '',
                'id_kategori' => '',
                'prioritas' => 'sedang',
                'id_user' => 'anonim'
            ];
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log('Admin create pengaduan error: ' . $e->getMessage());
            $message = 'Terjadi kesalahan saat menyimpan pengaduan.';
            $message_type = 'danger';
        }
    }
}

$admin_page = true;
include '../includes/header.php';
?>

<div class="container my-4">
    <div class="card p-4">
        <h2 class="mb-4 text-center"><?php echo esc($page_title); ?></h2>
        <?php if ($message): ?>
            <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="buat_pengaduan.php" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="id_user" class="form-label">Diajukan oleh</label>
                    <select id="id_user" name="id_user" class="form-control">
                        <option value="anonim" <?php echo ($form['id_user'] === 'anonim' ? 'selected' : ''); ?>>Anonim</option>
                        <?php foreach ($users_for_select as $user): ?>
                            <option value="<?php echo esc($user['id']); ?>" <?php echo ($form['id_user'] == $user['id'] ? 'selected' : ''); ?>>
                                <?php echo esc($user['nama']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="tanggal_pengaduan" class="form-label">Tanggal Pengaduan</label>
                    <input type="date" id="tanggal_pengaduan" name="tanggal_pengaduan" class="form-control" value="<?php echo esc($_POST['tanggal_pengaduan'] ?? date('Y-m-d')); ?>">
                </div>
            </div>
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Pengaduan</label>
                <input type="text" id="judul" name="judul" class="form-control" required value="<?php echo esc($form['judul']); ?>">
            </div>
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Pengaduan</label>
                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="5" required><?php echo esc($form['deskripsi']); ?></textarea>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="id_kategori" class="form-label">Kategori</label>
                    <select id="id_kategori" name="id_kategori" class="form-control" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($categories_for_select as $cat): ?>
                            <option value="<?php echo esc($cat['id']); ?>" <?php echo ($form['id_kategori'] == $cat['id'] ? 'selected' : ''); ?>>
                                <?php echo esc($cat['nama_kategori']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="prioritas" class="form-label">Prioritas</label>
                    <select id="prioritas" name="prioritas" class="form-control">
                        <option value="rendah" <?php echo ($form['prioritas'] === 'rendah' ? 'selected' : ''); ?>>Rendah</option>
                        <option value="sedang" <?php echo ($form['prioritas'] === 'sedang' ? 'selected' : ''); ?>>Sedang</option>
                        <option value="tinggi" <?php echo ($form['prioritas'] === 'tinggi' ? 'selected' : ''); ?>>Tinggi</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="status" class="form-label">Status Awal</label>
                    <select id="status" name="status" class="form-control">
                        <option value="menunggu">Menunggu</option>
                        <option value="diproses">Diproses</option>
                        <option value="selesai">Selesai</option>
                        <option value="ditolak">Ditolak</option>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <label for="lokasi" class="form-label">Lokasi</label>
                <input type="text" id="lokasi" name="lokasi" class="form-control" value="<?php echo esc($form['lokasi']); ?>">
            </div>
            <div class="mb-3">
                <label for="lampiran" class="form-label">Lampiran (opsional)</label>
                <input type="file" id="lampiran" name="lampiran" class="form-control-file">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Pengaduan</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
