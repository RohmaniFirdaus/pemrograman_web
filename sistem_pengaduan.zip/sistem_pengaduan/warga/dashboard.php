<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('warga');

$pdo = getDBConnection();
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'menunggu' THEN 1 ELSE 0 END) as menunggu,
        SUM(CASE WHEN status = 'diproses' THEN 1 ELSE 0 END) as diproses,
        SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as selesai,
        SUM(CASE WHEN status = 'ditolak' THEN 1 ELSE 0 END) as ditolak
    FROM pengaduan 
    WHERE user_id = ?
");
$stmt->execute([$user_id]);
$pengaduan_stats = $stmt->fetch();

$stmt = $pdo->prepare("
    SELECT * FROM pengaduan 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$pengaduan_list = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT * FROM surat_menyurat 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$surat_list = $stmt->fetchAll();

$pageTitle = 'Dashboard Warga - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg p-8 mb-8">
        <h1 class="text-3xl font-bold mb-2">Halo, <?php echo htmlspecialchars($user['nama_lengkap']); ?></h1>
        <p class="text-blue-100 mb-6">Selamat datang di Dashboard Warga Desa Gembong Kulon</p>
        <div class="flex space-x-4">
            <a href="<?php echo BASE_URL; ?>warga/buat_pengaduan.php" class="bg-white text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-lg font-semibold transition">
                <i class="fas fa-plus mr-2"></i>Pengaduan Baru
            </a>
            <a href="<?php echo BASE_URL; ?>warga/surat_online.php" class="bg-blue-800 hover:bg-blue-900 px-6 py-3 rounded-lg font-semibold transition">
                <i class="fas fa-file-alt mr-2"></i>Ajukan Surat
            </a>
        </div>
    </div>

    <?php if ($user['status_verifikasi'] !== 'terverifikasi'): ?>
        <div class="bg-yellow-50 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 rounded">
            <p><strong>Perhatian:</strong> Akun Anda belum terverifikasi. Silakan lengkapi profil dan upload foto KTP untuk verifikasi.</p>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 text-center">
            <i class="fas fa-clock text-4xl text-yellow-600 mb-3"></i>
            <div class="text-3xl font-bold text-gray-800"><?php echo $pengaduan_stats['menunggu'] ?? 0; ?></div>
            <div class="text-sm text-gray-600 mt-2">MENUNGGU</div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 text-center">
            <i class="fas fa-spinner text-4xl text-blue-600 mb-3"></i>
            <div class="text-3xl font-bold text-gray-800"><?php echo $pengaduan_stats['diproses'] ?? 0; ?></div>
            <div class="text-sm text-gray-600 mt-2">DIPROSES</div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 text-center">
            <i class="fas fa-check-circle text-4xl text-blue-600 mb-3"></i>
            <div class="text-3xl font-bold text-gray-800"><?php echo $pengaduan_stats['selesai'] ?? 0; ?></div>
            <div class="text-sm text-gray-600 mt-2">SELESAI</div>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 text-center">
            <i class="fas fa-times-circle text-4xl text-red-600 mb-3"></i>
            <div class="text-3xl font-bold text-gray-800"><?php echo $pengaduan_stats['ditolak'] ?? 0; ?></div>
            <div class="text-sm text-gray-600 mt-2">DITOLAK</div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h2 class="text-xl font-bold mb-4 text-gray-800">
                <i class="fas fa-folder mr-2"></i>Pengaduan Saya
            </h2>
            
            <?php if (empty($pengaduan_list)): ?>
                <div class="text-center py-8">
                    <i class="fas fa-file-alt text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 mb-2">Belum ada pengaduan.</p>
                    <p class="text-gray-500 text-sm">Mulai dengan membuat pengaduan baru di tombol di atas.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($pengaduan_list as $pengaduan): ?>
                        <div class="border-l-4 border-blue-500 pl-4 py-2">
                            <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($pengaduan['judul']); ?></h3>
                            <div class="flex items-center justify-between mt-2">
                                <?php echo getStatusBadge($pengaduan['status'], 'pengaduan'); ?>
                                <span class="text-xs text-gray-500"><?php echo formatTanggal($pengaduan['created_at']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-4">
                    <a href="<?php echo BASE_URL; ?>warga/pengaduan.php" class="text-blue-600 hover:text-blue-700 text-sm font-semibold">
                        Lihat Semua →
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h2 class="text-xl font-bold mb-4 text-gray-800">
                <i class="fas fa-folder mr-2"></i>Permohonan Surat Terakhir
            </h2>
            
            <?php if (empty($surat_list)): ?>
                <div class="text-center py-8">
                    <i class="fas fa-file-alt text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 mb-2">Belum ada permohonan surat.</p>
                    <p class="text-gray-500 text-sm">Ajukan surat online melalui tombol di atas.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($surat_list as $surat): ?>
                        <div class="border-l-4 border-blue-500 pl-4 py-2">
                            <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($surat['jenis_surat']); ?></h3>
                            <div class="flex items-center justify-between mt-2">
                                <?php echo getStatusBadge($surat['status'], 'surat'); ?>
                                <span class="text-xs text-gray-500"><?php echo formatTanggal($surat['created_at']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-4">
                    <a href="<?php echo BASE_URL; ?>warga/surat_online.php" class="text-blue-600 hover:text-blue-700 text-sm font-semibold">
                        Lihat Semua →
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

