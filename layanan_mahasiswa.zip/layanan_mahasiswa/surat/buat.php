<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Buat Surat';
$currentModule = 'surat';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();

// Get dosen list
$dosen_list = $conn->query("SELECT * FROM dosen WHERE status = 'active' ORDER BY nama_dosen")->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis = $_POST['jenis'] ?? '';
    $tujuan = $_POST['tujuan'] ?? '';
    $tujuan_id = intval($_POST['tujuan_id'] ?? 0);
    $perihal = sanitize($_POST['perihal'] ?? '');
    $isi_surat = sanitize($_POST['isi_surat'] ?? '');
    
    if (empty($jenis) || empty($tujuan) || empty($perihal) || empty($isi_surat)) {
        $error = 'Semua field wajib diisi';
    } else {
        // Generate nomor surat
        $count = $conn->query("SELECT COUNT(*) as total FROM surat")->fetch_assoc()['total'];
        $nomor_surat = 'SRT' . date('Y') . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        
        $stmt = $conn->prepare("INSERT INTO surat (nomor_surat, mahasiswa_id, jenis, tujuan, tujuan_id, perihal, isi_surat, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'menunggu')");
        $tujuan_id = $tujuan_id > 0 ? $tujuan_id : null;
        $stmt->bind_param("sisisss", $nomor_surat, $mahasiswa['id'], $jenis, $tujuan, $tujuan_id, $perihal, $isi_surat);
        
        if ($stmt->execute()) {
            $success = 'Surat berhasil dibuat';
            header('Location: index.php?success=1');
            exit;
        } else {
            $error = 'Gagal membuat surat';
        }
        $stmt->close();
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Buat Surat</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Jenis Surat *</label>
                    <select name="jenis" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Jenis</option>
                        <option value="masuk">Surat Masuk</option>
                        <option value="keluar">Surat Keluar</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Tujuan *</label>
                    <select name="tujuan" id="tujuan" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Tujuan</option>
                        <option value="admin">Admin</option>
                        <option value="dosen">Dosen</option>
                        <option value="pimpinan">Pimpinan</option>
                        <option value="kampus">Pihak Kampus</option>
                    </select>
                </div>
                
                <div id="dosen_select" class="hidden">
                    <label class="block text-gray-700 font-semibold mb-2">Pilih Dosen</label>
                    <select name="tujuan_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Dosen</option>
                        <?php foreach ($dosen_list as $d): ?>
                            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama_dosen']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-semibold mb-2">Perihal *</label>
                    <input type="text" name="perihal" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-semibold mb-2">Isi Surat *</label>
                    <textarea name="isi_surat" required rows="10"
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                              placeholder="Masukkan isi surat..."></textarea>
                </div>
            </div>
            
            <div class="mt-6 flex justify-end space-x-4">
                <a href="index.php" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-paper-plane mr-2"></i>Kirim Surat
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('tujuan').addEventListener('change', function() {
    const dosenSelect = document.getElementById('dosen_select');
    if (this.value === 'dosen') {
        dosenSelect.classList.remove('hidden');
    } else {
        dosenSelect.classList.add('hidden');
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>



