<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;

$pdo = getConnection();
$page_title = 'Detail Pengaduan';
$pengaduan = null;
$lampiran = [];
$riwayat = [];
$error_message = '';
$success_message = '';

$pengaduan_id = $_GET['id'] ?? 0;
$can_update = !is_readonly_admin();

if ($pengaduan_id <= 0) {
    $error_message = 'ID pengaduan tidak valid.';
} elseif (!$pdo) {
    $error_message = 'Koneksi database tidak tersedia.';
} else {
    try {
        // Cek apakah kolom kode_pengaduan ada
        $kode_column_exists = false;
        try {
            $stmt_check_col = $pdo->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pengaduan' AND COLUMN_NAME = 'kode_pengaduan'");
            $kode_column_exists = $stmt_check_col->fetch() !== false;
        } catch (PDOException $e) {
            // Fallback: coba dengan SHOW COLUMNS
            try {
                $stmt_check_col = $pdo->query("SHOW COLUMNS FROM pengaduan WHERE Field = 'kode_pengaduan'");
                $kode_column_exists = $stmt_check_col->fetch() !== false;
            } catch (PDOException $e2) {
                error_log("Error checking kode_pengaduan column: " . $e2->getMessage());
            }
        }
        
        // Buat query SELECT yang fleksibel
        if ($kode_column_exists) {
            $stmt = $pdo->prepare("
                SELECT p.*, u.nama AS pelapor, u.email, u.telepon, k.nama_kategori
                FROM pengaduan p
                LEFT JOIN users u ON u.id = p.id_user
                LEFT JOIN kategori_pengaduan k ON k.id = p.id_kategori
                WHERE p.id = :id
            ");
        } else {
            // Query tanpa kolom kode_pengaduan
            $stmt = $pdo->prepare("
                SELECT p.id, p.id_user, p.id_kategori, p.judul, p.deskripsi, p.lokasi, 
                       p.status, p.prioritas, p.tanggal_pengaduan, p.tanggal_selesai, 
                       p.created_at, p.updated_at,
                       u.nama AS pelapor, u.email, u.telepon, k.nama_kategori
                FROM pengaduan p
                LEFT JOIN users u ON u.id = p.id_user
                LEFT JOIN kategori_pengaduan k ON k.id = p.id_kategori
                WHERE p.id = :id
            ");
        }
        
        $stmt->execute(['id' => (int)$pengaduan_id]);
        $pengaduan = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pengaduan) {
            $error_message = 'Pengaduan tidak ditemukan.';
        } else {
            // Simpan info apakah kode_pengaduan ada untuk digunakan di view
            $pengaduan['_has_kode'] = $kode_column_exists;
            
            try {
                $stmtLampiran = $pdo->prepare("SELECT * FROM lampiran_pengaduan WHERE id_pengaduan = :id");
                $stmtLampiran->execute(['id' => $pengaduan_id]);
                $lampiran = $stmtLampiran->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log('Error loading lampiran: ' . $e->getMessage());
                $lampiran = [];
            }

            try {
                $stmtTanggapan = $pdo->prepare("
                    SELECT t.*, u.nama AS petugas
                    FROM tanggapan t
                    LEFT JOIN users u ON u.id = t.id_user
                    WHERE t.id_pengaduan = :id
                    ORDER BY t.created_at ASC
                ");
                $stmtTanggapan->execute(['id' => $pengaduan_id]);
                $riwayat = $stmtTanggapan->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log('Error loading tanggapan: ' . $e->getMessage());
                $riwayat = [];
            }
        }
    } catch (PDOException $e) {
        error_log('Detail pengaduan admin error: ' . $e->getMessage());
        error_log('Error code: ' . $e->getCode());
        error_log('SQL State: ' . ($e->errorInfo[0] ?? 'N/A'));
        $error_message = 'Terjadi kesalahan saat mengambil data: ' . htmlspecialchars($e->getMessage());
    } catch (Exception $e) {
        error_log('Unexpected error in detail pengaduan: ' . $e->getMessage());
        $error_message = 'Terjadi kesalahan tidak terduga: ' . htmlspecialchars($e->getMessage());
    }
}

if ($pengaduan && $can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['action'] ?? '';
    if ($aksi === 'update_status') {
        $status_baru = $_POST['status'] ?? $pengaduan['status'];
        $tanggapan = trim($_POST['tanggapan'] ?? '');
        try {
            $pdo->beginTransaction();
            $stmtUpdate = $pdo->prepare("UPDATE pengaduan SET status = :status, updated_at = NOW() WHERE id = :id");
            $stmtUpdate->execute(['status' => $status_baru, 'id' => $pengaduan_id]);

            if ($tanggapan) {
                $stmtInsert = $pdo->prepare("
                    INSERT INTO tanggapan (id_pengaduan, id_user, isi_tanggapan)
                    VALUES (:pengaduan, :user, :isi)
                ");
                $stmtInsert->execute([
                    'pengaduan' => $pengaduan_id,
                    'user' => $_SESSION['user_id'],
                    'isi' => $tanggapan
                ]);
            }
            $pdo->commit();
            header('Location: detail_pengaduan.php?id=' . $pengaduan_id);
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log('Update pengaduan error: ' . $e->getMessage());
            $error_message = 'Gagal memperbarui pengaduan.';
        }
    }
}

include '../includes/header.php';
?>

<div class="container my-4">
    <a href="pengaduan.php" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left me-1"></i> Kembali</a>

    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo esc($error_message); ?></div>
    <?php elseif ($pengaduan): ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h4>
                    <?php if (!empty($pengaduan['kode_pengaduan'])): ?>
                        #<?php echo esc($pengaduan['kode_pengaduan']); ?> - 
                    <?php else: ?>
                        ID: <?php echo esc($pengaduan['id']); ?> - 
                    <?php endif; ?>
                    <?php echo esc($pengaduan['judul']); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Status:</strong> <span class="status-badge status-<?php echo esc(strtolower($pengaduan['status'])); ?>"><?php echo esc(ucfirst($pengaduan['status'])); ?></span></p>
                        <p><strong>Kategori:</strong> <?php echo esc($pengaduan['nama_kategori'] ?? '-'); ?></p>
                        <p><strong>Prioritas:</strong> <?php echo esc(ucfirst($pengaduan['prioritas'])); ?></p>
                        <p><strong>Tanggal Pengajuan:</strong> <?php echo date('d M Y', strtotime($pengaduan['tanggal_pengaduan'])); ?></p>
                        <p><strong>Lokasi:</strong> <?php echo esc($pengaduan['lokasi'] ?? '-'); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Pelapor:</strong> <?php echo esc($pengaduan['pelapor'] ?? 'Anonim'); ?></p>
                        <?php if ($pengaduan['email']): ?><p><strong>Email:</strong> <?php echo esc($pengaduan['email']); ?></p><?php endif; ?>
                        <?php if ($pengaduan['telepon']): ?><p><strong>Telepon:</strong> <?php echo esc($pengaduan['telepon']); ?></p><?php endif; ?>
                    </div>
                </div>
                <p class="mt-3"><strong>Deskripsi:</strong><br><?php echo nl2br(esc($pengaduan['deskripsi'])); ?></p>
                <?php if ($lampiran): ?>
                    <h5>Lampiran</h5>
                    <ul>
                        <?php foreach ($lampiran as $file): ?>
                            <li><a href="../uploads/<?php echo esc($file['path_file']); ?>" target="_blank"><?php echo esc($file['nama_file']); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($can_update): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Update Status / Tanggapan</h4>
                </div>
                <div class="card-body">
                    <form action="detail_pengaduan.php?id=<?php echo esc($pengaduan_id); ?>" method="POST">
                        <input type="hidden" name="action" value="update_status">
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-control">
                                <?php foreach (['menunggu','diproses','selesai','ditolak'] as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo ($pengaduan['status'] === $status ? 'selected' : ''); ?>><?php echo ucfirst($status); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="tanggapan" class="form-label">Tanggapan</label>
                            <textarea id="tanggapan" name="tanggapan" class="form-control" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header bg-info text-white">
                <h4>Riwayat Tanggapan</h4>
            </div>
            <div class="card-body">
                <?php if (empty($riwayat)): ?>
                    <p class="text-muted">Belum ada tanggapan.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php foreach ($riwayat as $item): ?>
                            <li class="list-group-item">
                                <strong><?php echo esc($item['petugas'] ?? 'Petugas Desa'); ?></strong>
                                <small class="text-muted d-block"><?php echo date('d M Y H:i', strtotime($item['created_at'])); ?></small>
                                <p class="mb-0"><?php echo nl2br(esc($item['isi_tanggapan'])); ?></p>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>









