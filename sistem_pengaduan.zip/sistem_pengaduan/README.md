# Sistem Pengaduan Desa Gembong Kulon

Sistem pengaduan dan pelayanan digital terpadu untuk Desa Gembong Kulon, Talang, Kabupaten Tegal.

## Fitur Utama

1. **Homepage/Beranda** - Halaman utama dengan statistik dan informasi desa
2. **Registrasi dan Login** - Sistem autentikasi untuk warga, admin, dan kepala desa
3. **Dashboard** - Dashboard khusus untuk setiap role
4. **Profil Desa** - Informasi tentang desa (CRUD untuk admin, view untuk warga/kepala desa)
5. **Tentang Aplikasi** - Informasi tentang aplikasi
6. **Berita** - Manajemen berita desa (CRUD untuk admin, view untuk semua)
7. **UMKM** - Manajemen UMKM desa (CRUD untuk admin, view untuk semua)
8. **Kalender Kegiatan** - Kalender kegiatan desa (CRUD untuk admin, view untuk warga)
9. **Komentar** - Sistem komentar untuk berita dan UMKM
10. **Surat Menyurat** - Permohonan surat online (CRUD untuk admin dan warga, view untuk kepala desa)
11. **Pengaduan** - Sistem pengaduan warga (CRUD untuk admin dan warga, view untuk kepala desa)
12. **Laporan** - Laporan statistik per periode dan per kategori (untuk admin dan kepala desa)

## Aktor dan Hak Akses

### Admin
- Akses penuh ke semua fitur
- CRUD untuk semua modul
- Validasi pengguna
- Manajemen data

### Warga
- Registrasi dan login
- Dashboard pribadi
- Buat pengaduan
- Ajukan surat online
- Lihat berita, UMKM, kalender
- Komentar pada berita dan UMKM

### Kepala Desa
- Login
- Dashboard
- Lihat laporan dan statistik
- View pengaduan dan surat warga
- Lihat status pengaduan dan surat

## Teknologi

- **Backend**: PHP Native
- **Frontend**: Tailwind CSS, Vue.js, JavaScript
- **Database**: MySQL (XAMPP)
- **Design**: Green & White theme, responsive, modern, user-friendly

## Instalasi

### Persyaratan
- XAMPP (PHP 7.4+ dan MySQL)
- Web browser modern

### Langkah Instalasi

1. **Clone atau extract project ke folder htdocs**
   ```
   C:\xampp\htdocs\sistem_pengaduan
   ```

2. **Buat database**
   - Buka phpMyAdmin (http://localhost/phpmyadmin)
   - Import file `database/schema.sql`
   - Atau jalankan SQL script secara manual

3. **Konfigurasi Database**
   - Edit file `config/config.php`
   - Sesuaikan konfigurasi database jika diperlukan:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'sistem_pengaduan');
     define('DB_USER', 'root');
     define('DB_PASS', '');
     ```

4. **Buat folder uploads**
   - Buat folder `uploads` di root project
   - Buat subfolder:
     - `uploads/pengaduan/`
     - `uploads/surat/`
     - `uploads/berita/`
     - `uploads/umkm/`
     - `uploads/profil/`
     - `uploads/ktp/`

5. **Set permissions (Linux/Mac)**
   ```bash
   chmod -R 755 uploads/
   ```

6. **Akses aplikasi**
   - Buka browser: `http://localhost/sistem_pengaduan`
   - Login dengan:
     - **Admin**: username: `admin`, password: `admin123`
     - **Kepala Desa**: username: `kades`, password: `kades123`

## Struktur Folder

```
sistem_pengaduan/
├── admin/              # Modul admin
├── kepala_desa/        # Modul kepala desa
├── warga/              # Modul warga
├── config/             # Konfigurasi
├── includes/           # File include (header, footer, functions)
├── database/           # Schema database
├── uploads/            # File uploads
├── assets/             # Assets (CSS, JS, images)
├── index.php           # Homepage
├── login.php           # Login
├── register.php        # Registrasi
└── logout.php          # Logout
```

## Default Credentials

### Admin
- Username: `admin`
- Password: `admin123`
- Email: `admin@desa.gembongkulon.id`

### Kepala Desa
- Username: `kades`
- Password: `kades123`
- Email: `kades@desa.gembongkulon.id`

**PENTING**: Ganti password default setelah instalasi pertama!

## Fitur CRUD per Modul

### Profil Desa
- **Admin**: CRUD
- **Warga**: View
- **Kepala Desa**: View

### Tentang Aplikasi
- **Admin**: CRUD
- **Warga**: View
- **Kepala Desa**: View

### Berita
- **Admin**: CRUD
- **Warga**: View
- **Kepala Desa**: View

### UMKM
- **Admin**: CRUD
- **Warga**: View
- **Kepala Desa**: View

### Kalender Kegiatan
- **Admin**: CRUD
- **Warga**: View

### Pengaduan
- **Admin**: CRUD (update status, hapus)
- **Warga**: CRUD (buat, lihat sendiri)
- **Kepala Desa**: View (lihat semua, lihat status)

### Surat Menyurat
- **Admin**: CRUD (update status, hapus)
- **Warga**: CRUD (buat, lihat sendiri)
- **Kepala Desa**: View (lihat semua, lihat status)

### Laporan
- **Admin**: View (laporan per periode, per kategori)
- **Kepala Desa**: View (laporan per periode, per kategori)

## Alur Pengaduan

1. Warga membuat akun dan login
2. Lengkapi profil dan upload foto KTP
3. Admin memverifikasi akun warga
4. Warga membuat pengaduan dengan:
   - Judul
   - Kategori pengaduan
   - Deskripsi
   - Saran (opsional)
   - Bukti (foto/video/dokumen)
   - Lokasi kejadian (opsional)
   - Prioritas
5. Admin mengubah status:
   - **Menunggu**: Pengaduan baru masuk
   - **Diproses**: Pengaduan sedang ditangani
   - **Selesai**: Penanganan selesai
   - **Ditolak**: Pengaduan ditolak
6. Warga dapat melihat status pengaduan di dashboard

## Alur Surat Menyurat

1. Warga membuat permohonan surat dengan:
   - Jenis surat
   - Kategori surat
   - Keperluan
   - Detail data tambahan (opsional)
2. Admin mengubah status:
   - **Menunggu**: Permohonan baru masuk
   - **Diproses**: Surat sedang diproses
   - **Selesai**: Surat selesai
   - **Ditolak**: Permohonan ditolak
3. Warga dapat melihat status permohonan di dashboard

## Laporan

Laporan mencakup:
- Statistik pengaduan (total, menunggu, diproses, selesai, ditolak)
- Statistik surat menyurat
- Statistik UMKM
- Statistik berita
- Statistik warga
- Perbandingan periode sekarang dengan periode sebelumnya
- Laporan per kategori pengaduan

## Keamanan

- Password di-hash menggunakan `password_hash()`
- Prepared statements untuk mencegah SQL injection
- Input sanitization
- Session management
- Role-based access control
- File upload validation

## Pengembangan

### Menambah Fitur Baru

1. Buat tabel di database (jika diperlukan)
2. Tambahkan CRUD di modul admin
3. Tambahkan view di modul warga (jika diperlukan)
4. Update navigation di `includes/header.php`
5. Update access control di `includes/functions.php`

### Customization

- **Warna**: Edit Tailwind classes (green-600, green-700, dll)
- **Logo**: Ganti di `includes/header.php`
- **Nama Aplikasi**: Edit di `config/config.php`

## Troubleshooting

### Database connection error
- Pastikan XAMPP MySQL service running
- Cek konfigurasi di `config/config.php`
- Pastikan database `sistem_pengaduan` sudah dibuat

### File upload error
- Pastikan folder `uploads` dan subfoldernya sudah dibuat
- Cek permissions folder (755 atau 777)
- Cek `upload_max_filesize` di php.ini

### Session error
- Pastikan `session_start()` dipanggil sebelum output
- Cek `session.save_path` di php.ini

## Support

Untuk pertanyaan atau masalah, hubungi administrator sistem.

## License

© 2025 Pemerintah Desa Gembong Kulon. All rights reserved.

