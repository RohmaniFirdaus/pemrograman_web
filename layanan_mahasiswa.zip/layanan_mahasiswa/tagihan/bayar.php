<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Pembayaran Tagihan';
$currentModule = 'tagihan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mhs = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$tagihan = $conn->query("
    SELECT * FROM tagihan 
    WHERE id = $id AND mahasiswa_id = " . $mhs['id'] . "
")->fetch_assoc();

if (!$tagihan || !in_array($tagihan['status'], ['open', 'pending'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metode = $_POST['metode_pembayaran'] ?? '';
    $nominal = floatval($_POST['nominal'] ?? 0);
    
    if (!$metode || $nominal <= 0) {
        $error = 'Pilih metode pembayaran dan masukkan nominal';
    } elseif ($nominal > $tagihan['sisa_tagihan']) {
        $error = 'Nominal melebihi sisa tagihan';
    } else {
        // Generate nomor pembayaran
        $count = $conn->query("SELECT COUNT(*) as total FROM pembayaran")->fetch_assoc()['total'];
        $nomor_pembayaran = 'PAY' . str_pad($count + 1, 8, '0', STR_PAD_LEFT);
        
        // Create payment record
        $stmt = $conn->prepare("INSERT INTO pembayaran (tagihan_id, mahasiswa_id, nomor_pembayaran, metode_pembayaran, nominal, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("iissd", $id, $mhs['id'], $nomor_pembayaran, $metode, $nominal);
        
        if ($stmt->execute()) {
            $payment_id = $conn->insert_id;
            
            // Generate virtual account or QR code based on method
            if ($metode === 'transfer_bank') {
                $va = '777' . str_pad($payment_id, 10, '0', STR_PAD_LEFT);
                $conn->query("UPDATE pembayaran SET virtual_account = '$va' WHERE id = $payment_id");
            } elseif ($metode === 'qris') {
                // Generate QR code (simplified - in production use QR code library)
                $qr_data = json_encode(['payment_id' => $payment_id, 'nominal' => $nominal]);
                $conn->query("UPDATE pembayaran SET qr_code = '" . base64_encode($qr_data) . "' WHERE id = $payment_id");
            }
            
            $success = 'Pembayaran berhasil dibuat. Silakan selesaikan pembayaran.';
            header('Location: payment-status.php?id=' . $payment_id);
            exit;
        }
        $stmt->close();
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Pembayaran Tagihan</h1>
        <a href="detail.php?id=<?= $id ?>" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info Tagihan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Tagihan</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <p class="text-gray-600 text-sm">Nomor Tagihan</p>
                <p class="font-semibold"><?= htmlspecialchars($tagihan['nomor_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Total Tagihan</p>
                <p class="font-semibold text-xl"><?= formatRupiah($tagihan['total_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Total Bayar</p>
                <p class="font-semibold text-green-600"><?= formatRupiah($tagihan['total_bayar']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Sisa Tagihan</p>
                <p class="font-semibold text-red-600 text-xl"><?= formatRupiah($tagihan['sisa_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jatuh Tempo</p>
                <p class="font-semibold"><?= formatTanggal($tagihan['jatuh_tempo']) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Form Pembayaran -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Metode Pembayaran</h2>
        <form method="POST">
            <div class="space-y-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Pilih Metode Pembayaran *</label>
                    <div class="space-y-2">
                        <label class="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                            <input type="radio" name="metode_pembayaran" value="transfer_bank" required class="mr-3">
                            <div>
                                <p class="font-semibold">Transfer Bank (Virtual Account)</p>
                                <p class="text-sm text-gray-600">Transfer melalui Virtual Account</p>
                            </div>
                        </label>
                        <label class="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                            <input type="radio" name="metode_pembayaran" value="e_wallet" required class="mr-3">
                            <div>
                                <p class="font-semibold">E-Wallet & QRIS</p>
                                <p class="text-sm text-gray-600">GoPay, OVO, DANA, dll</p>
                            </div>
                        </label>
                        <label class="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                            <input type="radio" name="metode_pembayaran" value="qris" required class="mr-3">
                            <div>
                                <p class="font-semibold">QRIS</p>
                                <p class="text-sm text-gray-600">Scan QR Code untuk pembayaran</p>
                            </div>
                        </label>
                        <label class="flex items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                            <input type="radio" name="metode_pembayaran" value="credit_card" required class="mr-3">
                            <div>
                                <p class="font-semibold">Credit Card</p>
                                <p class="text-sm text-gray-600">Visa, Mastercard</p>
                            </div>
                        </label>
                    </div>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Nominal Bayar *</label>
                    <select name="nominal" id="nominal" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option value="">Pilih Nominal</option>
                        <option value="<?= $tagihan['sisa_tagihan'] ?>">Lunas (<?= formatRupiah($tagihan['sisa_tagihan']) ?>)</option>
                        <?php
                        // Generate installment options
                        $installments = [0.25, 0.5, 0.75];
                        foreach ($installments as $percent) {
                            $amount = $tagihan['sisa_tagihan'] * $percent;
                            if ($amount > 0) {
                                echo '<option value="' . round($amount) . '">' . ($percent * 100) . '% (' . formatRupiah(round($amount)) . ')</option>';
                            }
                        }
                        ?>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">Atau masukkan nominal custom di bawah</p>
                    <input type="number" id="nominal_custom" placeholder="Masukkan nominal custom..." 
                           min="10000" max="<?= $tagihan['sisa_tagihan'] ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2">
                </div>
            </div>
            
            <div class="mt-6 flex justify-end space-x-4">
                <a href="detail.php?id=<?= $id ?>" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-credit-card mr-2"></i>Lanjutkan Pembayaran
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('nominal_custom').addEventListener('input', function() {
    if (this.value) {
        document.getElementById('nominal').value = this.value;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>



