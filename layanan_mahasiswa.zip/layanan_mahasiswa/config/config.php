<?php
session_start();

define('BASE_URL', 'http://localhost/layanan_mahasiswa/');
define('BASE_PATH', __DIR__ . '/../');

define('UPLOAD_PATH', BASE_PATH . 'uploads/');
define('UPLOAD_SURAT', UPLOAD_PATH . 'surat/');
define('UPLOAD_PENGADUAN', UPLOAD_PATH . 'pengaduan/');
define('UPLOAD_REPOSITORY', UPLOAD_PATH . 'repository/');
define('UPLOAD_BUKTI', UPLOAD_PATH . 'bukti_pembayaran/');

$dirs = [UPLOAD_PATH, UPLOAD_SURAT, UPLOAD_PENGADUAN, UPLOAD_REPOSITORY, UPLOAD_BUKTI];
foreach ($dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
}

date_default_timezone_set('Asia/Jakarta');

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/database.php';

require_once __DIR__ . '/../includes/functions.php';

require_once __DIR__ . '/auth.php';
?>

