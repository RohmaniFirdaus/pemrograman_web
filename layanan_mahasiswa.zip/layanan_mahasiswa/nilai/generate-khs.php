<?php
require_once '../config/config.php';
requireRole(['admin', 'dosen', 'pimpinan']);

$mahasiswa_id = intval($_GET['mahasiswa_id'] ?? 0);
$semester = intval($_GET['semester'] ?? 0);

if (!$mahasiswa_id || !$semester) {
    header('Location: khs.php');
    exit;
}

$conn = getDBConnection();

$mahasiswa = $conn->query("
    SELECT m.*, p.nama_prodi 
    FROM mahasiswa m 
    LEFT JOIN program_studi p ON m.prodi_id = p.id
    WHERE m.id = $mahasiswa_id
")->fetch_assoc();

$khs = $conn->query("
    SELECT * FROM khs 
    WHERE mahasiswa_id = $mahasiswa_id AND semester = $semester
")->fetch_assoc();

$nilai_list = $conn->query("
    SELECT n.*, mk.kode_mk, mk.nama_mk, mk.sks, d.nama_dosen
    FROM nilai n
    JOIN mata_kuliah mk ON n.mk_id = mk.id
    LEFT JOIN dosen d ON n.dosen_id = d.id
    WHERE n.mahasiswa_id = $mahasiswa_id AND n.semester = $semester AND n.status = 'final'
    ORDER BY mk.kode_mk
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

// Placeholder untuk PDF generation
// Di production, gunakan library seperti TCPDF atau FPDF

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="KHS_' . $mahasiswa['nim'] . '_Semester' . $semester . '.pdf"');

// Generate PDF content (simplified)
echo "KHS - " . $mahasiswa['nama_mahasiswa'] . "\n";
echo "NIM: " . $mahasiswa['nim'] . "\n";
echo "Semester: " . $semester . "\n\n";
echo "Mata Kuliah:\n";
foreach ($nilai_list as $n) {
    echo $n['kode_mk'] . " - " . $n['nama_mk'] . " | " . $n['nilai_huruf'] . "\n";
}
?>



