<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen', 'pimpinan']);

$pageTitle = 'KHS';
$currentModule = 'nilai';

$user = getCurrentUser();
$conn = getDBConnection();

$mahasiswa_id = intval($_GET['mahasiswa_id'] ?? 0);
$semester = intval($_GET['semester'] ?? 0);

if ($_SESSION['role'] === 'mahasiswa') {
    $mhs = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    $mahasiswa_id = $mhs['id'];
} elseif ($_SESSION['role'] === 'dosen') {
    if (!$mahasiswa_id) {
        // Show list of mahasiswa bimbingan
        $dosen = $conn->query("SELECT id FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
        $mhs_list = $conn->query("
            SELECT m.*, p.nama_prodi 
            FROM mahasiswa m 
            LEFT JOIN program_studi p ON m.prodi_id = p.id
            WHERE m.dosen_wali_id = " . $dosen['id'] . "
            ORDER BY m.nim
        ")->fetch_all(MYSQLI_ASSOC);
    }
}

if ($mahasiswa_id) {
    $mahasiswa = $conn->query("
        SELECT m.*, p.nama_prodi 
        FROM mahasiswa m 
        LEFT JOIN program_studi p ON m.prodi_id = p.id
        WHERE m.id = $mahasiswa_id
    ")->fetch_assoc();
    
    if (!$semester) {
        // Get latest semester
        $latest = $conn->query("SELECT MAX(semester) as max_sem FROM nilai WHERE mahasiswa_id = $mahasiswa_id AND status = 'final'")->fetch_assoc();
        $semester = $latest['max_sem'] ?? $mahasiswa['semester'];
    }
    
    // Get KHS
    $khs = $conn->query("
        SELECT * FROM khs 
        WHERE mahasiswa_id = $mahasiswa_id AND semester = $semester
    ")->fetch_assoc();
    
    // Get nilai for this semester
    $nilai_list = $conn->query("
        SELECT n.*, mk.kode_mk, mk.nama_mk, mk.sks, d.nama_dosen
        FROM nilai n
        JOIN mata_kuliah mk ON n.mk_id = mk.id
        LEFT JOIN dosen d ON n.dosen_id = d.id
        WHERE n.mahasiswa_id = $mahasiswa_id AND n.semester = $semester AND n.status = 'final'
        ORDER BY mk.kode_mk
    ")->fetch_all(MYSQLI_ASSOC);
    
    // Get all semesters
    $semesters = $conn->query("
        SELECT DISTINCT semester FROM nilai 
        WHERE mahasiswa_id = $mahasiswa_id AND status = 'final'
        ORDER BY semester
    ")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Kartu Hasil Studi (KHS)</h1>
        <?php if ($mahasiswa_id && $semester): ?>
        <a href="export-khs.php?mahasiswa_id=<?= $mahasiswa_id ?>&semester=<?= $semester ?>" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
        <?php endif; ?>
    </div>
    
    <?php if (isset($mhs_list)): ?>
    <!-- List Mahasiswa (Dosen) -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Pilih Mahasiswa</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($mhs_list as $m): ?>
            <a href="khs.php?mahasiswa_id=<?= $m['id'] ?>" class="border rounded-lg p-4 hover:bg-gray-50">
                <p class="font-semibold"><?= htmlspecialchars($m['nim']) ?></p>
                <p class="text-sm text-gray-600"><?= htmlspecialchars($m['nama_mahasiswa']) ?></p>
                <p class="text-xs text-gray-500"><?= htmlspecialchars($m['nama_prodi']) ?></p>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php elseif ($mahasiswa_id): ?>
    <!-- Info Mahasiswa -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <div>
                <h2 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($mahasiswa['nama_mahasiswa']) ?></h2>
                <p class="text-gray-600"><?= htmlspecialchars($mahasiswa['nim']) ?> - <?= htmlspecialchars($mahasiswa['nama_prodi']) ?></p>
            </div>
            <div>
                <form method="GET" class="flex gap-2">
                    <input type="hidden" name="mahasiswa_id" value="<?= $mahasiswa_id ?>">
                    <select name="semester" onchange="this.form.submit()" class="px-4 py-2 border border-gray-300 rounded-lg">
                        <?php foreach ($semesters as $s): ?>
                            <option value="<?= $s['semester'] ?>" <?= $semester == $s['semester'] ? 'selected' : '' ?>>
                                Semester <?= $s['semester'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
        </div>
    </div>
    
    <!-- KHS Data -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div>
                    <p class="text-gray-600 text-sm">Semester</p>
                    <p class="font-semibold text-lg"><?= $semester ?></p>
                </div>
                <div>
                    <p class="text-gray-600 text-sm">SKS Semester</p>
                    <p class="font-semibold text-lg"><?= $khs['sks_semester'] ?? 0 ?></p>
                </div>
                <div>
                    <p class="text-gray-600 text-sm">IP Semester</p>
                    <p class="font-semibold text-lg"><?= number_format($khs['ip_semester'] ?? 0, 2) ?></p>
                </div>
                <div>
                    <p class="text-gray-600 text-sm">IPK</p>
                    <p class="font-semibold text-lg"><?= number_format($khs['ipk'] ?? $mahasiswa['ipk'], 2) ?></p>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full table-auto">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2 text-left">No</th>
                            <th class="px-4 py-2 text-left">Kode MK</th>
                            <th class="px-4 py-2 text-left">Nama MK</th>
                            <th class="px-4 py-2 text-left">SKS</th>
                            <th class="px-4 py-2 text-left">Nilai</th>
                            <th class="px-4 py-2 text-left">Dosen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($nilai_list)): ?>
                            <tr>
                                <td colspan="6" class="px-4 py-4 text-center text-gray-500">Belum ada nilai</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($nilai_list as $index => $n): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?= $index + 1 ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($n['kode_mk']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                                <td class="px-4 py-2"><?= $n['sks'] ?></td>
                                <td class="px-4 py-2">
                                    <span class="font-semibold"><?= $n['nilai_huruf'] ?></span>
                                    <span class="text-gray-600">(<?= number_format($n['nilai_angka'], 2) ?>)</span>
                                </td>
                                <td class="px-4 py-2"><?= htmlspecialchars($n['nama_dosen'] ?? '-') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



