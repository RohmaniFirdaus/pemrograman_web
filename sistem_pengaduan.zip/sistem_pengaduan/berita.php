<?php
require_once 'includes/auth.php';

$pdo = getConnection();
$page_title = 'Berita Desa';
$search = trim($_GET['q'] ?? '');

$sql = "
    SELECT b.*, u.nama AS penulis
    FROM berita_desa b
    LEFT JOIN users u ON u.id = b.id_user
    WHERE b.is_published = 1
";
$params = [];
if ($search) {
    $sql .= " AND (b.judul LIKE :search OR b.konten LIKE :search)";
    $params['search'] = '%' . $search . '%';
}
$sql .= " ORDER BY COALESCE(b.tanggal_publish, b.created_at) DESC";

$berita_list = [];
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $berita_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Berita list error: ' . $e->getMessage());
}

$extra_styles = <<<CSS
.news-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}
.news-card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
        <div>
            <h2>Berita Desa Gembong Kulon</h2>
            <p class="text-muted mb-0">Informasi resmi dan kabar terbaru desa</p>
        </div>
        <form action="berita.php" method="GET" class="d-flex gap-2">
            <input type="text" name="q" class="form-control" placeholder="Cari berita..." value="<?php echo esc($search); ?>">
            <button type="submit" class="btn btn-primary">Cari</button>
        </form>
    </div>

    <div class="news-grid">
        <?php if (empty($berita_list)): ?>
            <p class="text-muted">Belum ada berita dipublikasi.</p>
        <?php else: ?>
            <?php foreach ($berita_list as $news): ?>
                <article class="news-card">
                    <span class="badge bg-warning text-dark mb-2"><?php echo date('d M Y', strtotime($news['tanggal_publish'] ?? $news['created_at'])); ?></span>
                    <h4><?php echo esc($news['judul']); ?></h4>
                    <p class="text-muted"><?php echo esc(substr(strip_tags($news['konten']), 0, 120)); ?>...</p>
                    <small class="text-muted">Oleh <?php echo esc($news['penulis'] ?? 'Admin Desa'); ?></small>
                    <a href="berita_detail.php?id=<?php echo esc($news['id']); ?>" class="btn btn-link mt-2">Baca selengkapnya</a>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>











