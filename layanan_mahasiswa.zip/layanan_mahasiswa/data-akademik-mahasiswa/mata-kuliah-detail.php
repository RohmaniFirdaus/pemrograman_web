<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Detail Mata Kuliah';
$currentModule = 'data-akademik-mahasiswa';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: mata-kuliah.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

// Get mahasiswa data to verify prodi
$mahasiswa = $conn->query("SELECT prodi_id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();

$mk = $conn->query("
    SELECT mk.*, p.nama_prodi, d.nama_dosen 
    FROM mata_kuliah mk 
    LEFT JOIN program_studi p ON mk.prodi_id = p.id 
    LEFT JOIN dosen d ON mk.dosen_pengampu_id = d.id 
    WHERE mk.id = $id AND mk.prodi_id = " . $mahasiswa['prodi_id'] . " AND mk.status = 'active'
")->fetch_assoc();

if (!$mk) {
    header('Location: mata-kuliah.php');
    exit;
}

// Get prasyarat
$prasyarat = $conn->query("
    SELECT mk2.kode_mk, mk2.nama_mk, mk2.semester
    FROM prasyarat_mk pm 
    JOIN mata_kuliah mk2 ON pm.mk_prasyarat_id = mk2.id 
    WHERE pm.mk_id = $id
    ORDER BY mk2.semester
")->fetch_all(MYSQLI_ASSOC);

// Get jadwal aktif (current semester)
$current_semester = date('n') <= 6 ? date('Y') . '/2' : date('Y') . '/1';
$jadwal = $conn->query("
    SELECT j.*, d.nama_dosen 
    FROM jadwal_kuliah j 
    LEFT JOIN dosen d ON j.dosen_id = d.id 
    WHERE j.mk_id = $id AND j.tahun_akademik = '" . $conn->real_escape_string($current_semester) . "'
    ORDER BY j.hari, j.jam_mulai
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Detail Mata Kuliah</h1>
        <a href="mata-kuliah.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <!-- Info Mata Kuliah -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Mata Kuliah</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <p class="text-gray-600 text-sm">Kode MK</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['kode_mk']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Nama MK</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_mk']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Program Studi</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_prodi']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Semester</p>
                <p class="font-semibold text-gray-800"><?= $mk['semester'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">SKS</p>
                <p class="font-semibold text-gray-800"><?= $mk['sks'] ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Jenis</p>
                <p>
                    <span class="px-2 py-1 rounded text-xs <?= $mk['jenis'] === 'wajib' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700' ?>">
                        <?= ucfirst($mk['jenis']) ?>
                    </span>
                </p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Dosen Pengampu</p>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($mk['nama_dosen'] ?? '-') ?></p>
            </div>
            <?php if ($mk['deskripsi']): ?>
            <div class="md:col-span-2">
                <p class="text-gray-600 text-sm">Deskripsi</p>
                <p class="text-gray-800"><?= nl2br(htmlspecialchars($mk['deskripsi'])) ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Prasyarat -->
    <?php if (!empty($prasyarat)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah Prasyarat</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode MK</th>
                        <th class="px-4 py-2 text-left">Nama Mata Kuliah</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($prasyarat as $p): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($p['kode_mk']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($p['nama_mk']) ?></td>
                        <td class="px-4 py-2"><?= $p['semester'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Jadwal -->
    <?php if (!empty($jadwal)): ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jadwal Kuliah (<?= htmlspecialchars($current_semester) ?>)</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left">Dosen</th>
                        <th class="px-4 py-2 text-left">Kelas</th>
                        <th class="px-4 py-2 text-left">Hari</th>
                        <th class="px-4 py-2 text-left">Jam</th>
                        <th class="px-4 py-2 text-left">Ruangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($jadwal as $j): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?= htmlspecialchars($j['nama_dosen'] ?? '-') ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['kelas']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['hari']) ?></td>
                        <td class="px-4 py-2"><?= date('H:i', strtotime($j['jam_mulai'])) ?> - <?= date('H:i', strtotime($j['jam_selesai'])) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($j['ruangan'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>




