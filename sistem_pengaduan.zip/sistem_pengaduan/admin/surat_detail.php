<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

$id = intval($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT s.*, u.nama_lengkap, u.email, u.no_hp, u.alamat, k.nama_kategori 
    FROM surat_menyurat s 
    LEFT JOIN users u ON s.user_id = u.id 
    LEFT JOIN kategori_surat k ON s.kategori_id = k.id
    WHERE s.id = ?
");
$stmt->execute([$id]);
$surat = $stmt->fetch();

if (!$surat) {
    setFlashMessage('error', 'Surat tidak ditemukan');
    header('Location: ' . BASE_URL . 'admin/surat.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $status = sanitize($_POST['status']);
    $stmt = $pdo->prepare("UPDATE surat_menyurat SET status = ?, updated_at = NOW() WHERE id = ?");
    if ($stmt->execute([$status, $id])) {
        setFlashMessage('success', 'Status surat berhasil diperbarui');
        header('Location: ' . $_SERVER['PHP_SELF'] . '?id=' . $id);
        exit;
    }
}

$pageTitle = 'Detail Surat - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-6">
        <a href="<?php echo BASE_URL; ?>admin/surat.php" class="text-blue-600 hover:text-blue-700 mb-4 inline-block">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-6">
                <div class="flex items-center justify-between mb-4">
                    <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($surat['jenis_surat']); ?></h1>
                    <?php echo getStatusBadge($surat['status'], 'surat'); ?>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Kategori</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($surat['nama_kategori'] ?? '-'); ?></p>
                    </div>

                    <div>
                        <label class="text-sm font-semibold text-gray-600">Keperluan</label>
                        <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($surat['keperluan']); ?></p>
                    </div>

                    <?php if ($surat['detail_data_tambahan']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Detail Data Tambahan</label>
                        <p class="text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($surat['detail_data_tambahan']); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div>
            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200 mb-6">
                <h2 class="text-xl font-bold mb-4 text-gray-800">Update Status</h2>
                <form method="POST">
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-green-500">
                        <option value="menunggu" <?php echo $surat['status'] === 'menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                        <option value="diproses" <?php echo $surat['status'] === 'diproses' ? 'selected' : ''; ?>>Diproses</option>
                        <option value="selesai" <?php echo $surat['status'] === 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                        <option value="ditolak" <?php echo $surat['status'] === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                    </select>
                    <button type="submit" name="update_status" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition">
                        Update Status
                    </button>
                </form>
            </div>

            <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h2 class="text-xl font-bold mb-4 text-gray-800">Informasi Pemohon</h2>
                <div class="space-y-3">
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Nama</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($surat['nama_lengkap']); ?></p>
                    </div>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Email</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($surat['email']); ?></p>
                    </div>
                    <?php if ($surat['no_hp']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">No. HP</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($surat['no_hp']); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ($surat['alamat']): ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Alamat</label>
                        <p class="text-gray-800"><?php echo htmlspecialchars($surat['alamat']); ?></p>
                    </div>
                    <?php endif; ?>
                    <div>
                        <label class="text-sm font-semibold text-gray-600">Tanggal</label>
                        <p class="text-gray-800"><?php echo formatTanggal($surat['created_at'], true); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

