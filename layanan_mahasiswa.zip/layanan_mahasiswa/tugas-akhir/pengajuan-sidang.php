<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Pengajuan Sidang';
$currentModule = 'tugas-akhir';

$ta_id = intval($_GET['id'] ?? 0);
if (!$ta_id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$ta = $conn->query("
    SELECT * FROM tugas_akhir 
    WHERE id = $ta_id AND mahasiswa_id = " . $mhs['id']
)->fetch_assoc();

if (!$ta) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deadline = $_POST['deadline_sidang'] ?? '';
    
    if ($deadline) {
        $stmt = $conn->prepare("UPDATE tugas_akhir SET deadline_sidang = ? WHERE id = ?");
        $stmt->bind_param("si", $deadline, $ta_id);
        if ($stmt->execute()) {
            $success = 'Pengajuan sidang berhasil';
            header('Location: index.php?success=1');
            exit;
        }
        $stmt->close();
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Pengajuan Sidang</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4"><?= htmlspecialchars($ta['judul_ta']) ?></h2>
        
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Deadline Sidang *</label>
                <input type="date" name="deadline_sidang" required
                       value="<?= $ta['deadline_sidang'] ? htmlspecialchars($ta['deadline_sidang']) : '' ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg">
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <p class="text-sm text-blue-800">
                    <i class="fas fa-info-circle mr-2"></i>
                    Pastikan semua bab sudah di-approve oleh dosen pembimbing sebelum mengajukan sidang.
                </p>
            </div>
            
            <div class="flex justify-end space-x-4">
                <a href="index.php" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-paper-plane mr-2"></i>Ajukan Sidang
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



