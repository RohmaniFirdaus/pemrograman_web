<?php
require_once '../../config/config.php';
requireRole(['admin', 'dosen']);

$pageTitle = 'Data Mahasiswa';
$currentModule = 'data-akademik';

$user = getCurrentUser();
$conn = getDBConnection();

// Get dosen data if role is dosen
$dosen = null;
if ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
}

$search = $_GET['search'] ?? '';
$prodi_filter = intval($_GET['prodi'] ?? 0);
$status_filter = $_GET['status'] ?? '';

$query = "SELECT m.*, p.nama_prodi, d.nama_dosen as nama_dosen_wali 
          FROM mahasiswa m 
          LEFT JOIN program_studi p ON m.prodi_id = p.id 
          LEFT JOIN dosen d ON m.dosen_wali_id = d.id 
          WHERE 1=1";

// Filter untuk dosen: hanya melihat mahasiswa bimbingannya
if ($_SESSION['role'] === 'dosen' && $dosen) {
    $query .= " AND m.dosen_wali_id = " . intval($dosen['id']);
}

if ($search) {
    $query .= " AND (m.nim LIKE '%" . $conn->real_escape_string($search) . "%' OR m.nama_mahasiswa LIKE '%" . $conn->real_escape_string($search) . "%')";
}
if ($prodi_filter) {
    $query .= " AND m.prodi_id = $prodi_filter";
}
if ($status_filter) {
    $query .= " AND m.status = '" . $conn->real_escape_string($status_filter) . "'";
}

$query .= " ORDER BY m.nim";
$mahasiswa_list = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

$prodi_list = $conn->query("SELECT * FROM program_studi ORDER BY nama_prodi")->fetch_all(MYSQLI_ASSOC);
$conn->close();

require_once '../../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Data Mahasiswa</h1>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="tambah.php" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i>Tambah Mahasiswa
        </a>
        <?php endif; ?>
    </div>
    
    <!-- Search and Filter -->
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="text" name="search" placeholder="Cari NIM atau Nama..." 
                   value="<?= htmlspecialchars($search) ?>"
                   class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            <select name="prodi" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Prodi</option>
                <?php foreach ($prodi_list as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $prodi_filter == $p['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nama_prodi']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg">
                <option value="">Semua Status</option>
                <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>Active</option>
                <option value="cuti" <?= $status_filter === 'cuti' ? 'selected' : '' ?>>Cuti</option>
                <option value="do" <?= $status_filter === 'do' ? 'selected' : '' ?>>DO</option>
                <option value="lulus" <?= $status_filter === 'lulus' ? 'selected' : '' ?>>Lulus</option>
            </select>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                <i class="fas fa-search mr-2"></i>Cari
            </button>
        </form>
    </div>
    
    <!-- Table -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">NIM</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Prodi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Dosen Wali</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Semester</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">IPK</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (empty($mahasiswa_list)): ?>
                        <tr>
                            <td colspan="<?= $_SESSION['role'] === 'admin' ? '8' : '8' ?>" class="px-6 py-4 text-center text-gray-500">Tidak ada data mahasiswa</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($mahasiswa_list as $m): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($m['nim']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($m['nama_mahasiswa']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($m['nama_prodi']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($m['nama_dosen_wali'] ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $m['semester'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= number_format($m['ipk'], 2) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?= getStatusBadge($m['status']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="detail.php?id=<?= $m['id'] ?>" class="text-blue-600 hover:text-blue-700 mr-3" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                <a href="edit.php?id=<?= $m['id'] ?>" class="text-green-600 hover:text-green-700 mr-3" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="hapus.php?id=<?= $m['id'] ?>" 
                                   onclick="return confirm('Yakin ingin menghapus?')"
                                   class="text-red-600 hover:text-red-700" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>



