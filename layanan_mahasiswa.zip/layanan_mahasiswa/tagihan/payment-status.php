<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Status Pembayaran';
$currentModule = 'tagihan';

$payment_id = intval($_GET['id'] ?? 0);
if (!$payment_id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$payment = $conn->query("
    SELECT p.*, t.nomor_tagihan, t.total_tagihan
    FROM pembayaran p
    JOIN tagihan t ON p.tagihan_id = t.id
    WHERE p.id = $payment_id AND p.mahasiswa_id = " . $mhs['id']
)->fetch_assoc();

if (!$payment) {
    header('Location: index.php');
    exit;
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Status Pembayaran</h1>
        <a href="index.php" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($payment['nomor_pembayaran']) ?></h2>
            <p class="text-gray-600">Nomor Tagihan: <?= htmlspecialchars($payment['nomor_tagihan']) ?></p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <p class="text-gray-600 text-sm">Nominal</p>
                <p class="font-semibold text-xl"><?= formatRupiah($payment['nominal']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Status</p>
                <p><?= getStatusBadge($payment['status']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Metode Pembayaran</p>
                <p class="font-semibold">
                    <?php
                    $metode = [
                        'transfer_bank' => 'Transfer Bank',
                        'e_wallet' => 'E-Wallet',
                        'qris' => 'QRIS',
                        'credit_card' => 'Credit Card'
                    ];
                    echo $metode[$payment['metode_pembayaran']] ?? $payment['metode_pembayaran'];
                    ?>
                </p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Tanggal</p>
                <p class="font-semibold"><?= formatTanggalWaktu($payment['created_at']) ?></p>
            </div>
        </div>
        
        <?php if ($payment['metode_pembayaran'] === 'transfer_bank' && $payment['virtual_account']): ?>
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p class="font-semibold text-blue-800 mb-2">Virtual Account</p>
            <p class="text-2xl font-bold text-blue-600"><?= htmlspecialchars($payment['virtual_account']) ?></p>
            <p class="text-sm text-blue-600 mt-2">Gunakan nomor ini untuk transfer bank</p>
        </div>
        <?php endif; ?>
        
        <?php if ($payment['metode_pembayaran'] === 'qris' && $payment['qr_code']): ?>
        <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 text-center">
            <p class="font-semibold text-green-800 mb-2">QR Code</p>
            <div class="bg-white p-4 inline-block rounded">
                <!-- QR Code would be generated here in production -->
                <p class="text-sm text-gray-600">Scan QR Code untuk pembayaran</p>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($payment['status'] === 'pending'): ?>
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p class="text-yellow-800">
                <i class="fas fa-info-circle mr-2"></i>
                Pembayaran Anda sedang diproses. Silakan tunggu konfirmasi.
            </p>
        </div>
        <?php elseif ($payment['status'] === 'success'): ?>
        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
            <p class="text-green-800 mb-2">
                <i class="fas fa-check-circle mr-2"></i>
                Pembayaran berhasil!
            </p>
            <?php if ($payment['e_receipt']): ?>
            <a href="<?= BASE_URL . htmlspecialchars($payment['e_receipt']) ?>" target="_blank" 
               class="text-green-600 hover:text-green-700">
                <i class="fas fa-download mr-1"></i>Download E-Receipt
            </a>
            <?php endif; ?>
        </div>
        <?php elseif ($payment['status'] === 'failed'): ?>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4">
            <p class="text-red-800 mb-2">
                <i class="fas fa-times-circle mr-2"></i>
                Pembayaran gagal. Silakan coba lagi.
            </p>
            <a href="bayar.php?id=<?= $payment['tagihan_id'] ?>" class="text-red-600 hover:text-red-700">
                <i class="fas fa-redo mr-1"></i>Coba Lagi
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



