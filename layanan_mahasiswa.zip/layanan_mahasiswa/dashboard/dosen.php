<?php
require_once '../config/config.php';
requireRole(['dosen']);

$pageTitle = 'Dashboard Dosen';
$currentModule = 'dashboard';

$user = getCurrentUser();
$conn = getDBConnection();

$dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();

$mahasiswa_bimbingan = $conn->query("SELECT COUNT(*) as total FROM tugas_akhir WHERE dosen_pembimbing1_id = " . $dosen['id'] . " OR dosen_pembimbing2_id = " . $dosen['id'])->fetch_assoc()['total'];
$mata_kuliah_diajar = $conn->query("SELECT COUNT(DISTINCT mk_id) as total FROM jadwal_kuliah WHERE dosen_id = " . $dosen['id'])->fetch_assoc()['total'];
$krs_pending = $conn->query("
    SELECT COUNT(DISTINCT k.id) as total 
    FROM krs k 
    JOIN mahasiswa m ON k.mahasiswa_id = m.id 
    WHERE k.status = 'menunggu_approval' AND m.dosen_wali_id = " . $dosen['id']
)->fetch_assoc()['total'];

$krs_menunggu = $conn->query("
    SELECT k.*, m.nim, m.nama_mahasiswa, m.semester 
    FROM krs k 
    JOIN mahasiswa m ON k.mahasiswa_id = m.id 
    WHERE k.status = 'menunggu_approval' AND m.dosen_wali_id = " . $dosen['id'] . "
    ORDER BY k.created_at DESC LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$jadwal_bimbingan = $conn->query("
    SELECT jb.*, ta.judul_ta, m.nama_mahasiswa 
    FROM jadwal_bimbingan jb
    JOIN tugas_akhir ta ON jb.ta_id = ta.id
    JOIN mahasiswa m ON ta.mahasiswa_id = m.id
    WHERE jb.dosen_id = " . $dosen['id'] . " 
    AND jb.tanggal >= CURDATE() 
    AND jb.tanggal <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    ORDER BY jb.tanggal, jb.waktu
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$nilai_pending = $conn->query("
    SELECT mk.nama_mk, j.kelas, COUNT(DISTINCT n.mahasiswa_id) as jml_mhs, 
           MAX(n.created_at) as deadline
    FROM nilai n
    JOIN mata_kuliah mk ON n.mk_id = mk.id
    JOIN jadwal_kuliah j ON n.mk_id = j.mk_id AND n.dosen_id = j.dosen_id
    WHERE n.dosen_id = " . $dosen['id'] . " AND n.status = 'draft'
    GROUP BY mk.id, j.kelas
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Dashboard Dosen</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Mahasiswa Bimbingan</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $mahasiswa_bimbingan ?></p>
                </div>
                <div class="bg-green-100 p-4 rounded-full">
                    <i class="fas fa-users text-green-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?= BASE_URL ?>tugas-akhir/mahasiswa-aktif.php" class="text-green-600 hover:text-green-700 text-sm mt-4 inline-block">
                Lihat List <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Mata Kuliah Diajar</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $mata_kuliah_diajar ?></p>
                </div>
                <div class="bg-blue-100 p-4 rounded-full">
                    <i class="fas fa-book text-blue-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?= BASE_URL ?>data-akademik/mata-kuliah/index.php" class="text-blue-600 hover:text-blue-700 text-sm mt-4 inline-block">
                Lihat Jadwal <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">KRS Pending</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2"><?= $krs_pending ?></p>
                </div>
                <div class="bg-yellow-100 p-4 rounded-full">
                    <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?= BASE_URL ?>krs/index.php" class="text-yellow-600 hover:text-yellow-700 text-sm mt-4 inline-block">
                Review <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">KRS Menunggu Approval</h2>
            <a href="<?= BASE_URL ?>krs/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">NIM</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Semester</th>
                        <th class="px-4 py-2 text-left">SKS</th>
                        <th class="px-4 py-2 text-left">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($krs_menunggu)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Tidak ada KRS yang menunggu approval</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($krs_menunggu as $k): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($k['nim']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($k['nama_mahasiswa']) ?></td>
                            <td class="px-4 py-2"><?= $k['semester'] ?></td>
                            <td class="px-4 py-2"><?= $k['sks_diambil'] ?></td>
                            <td class="px-4 py-2">
                                <a href="<?= BASE_URL ?>krs/review.php?id=<?= $k['id'] ?>" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-eye"></i> Review
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Jadwal Bimbingan Minggu Ini</h2>
            <a href="<?= BASE_URL ?>tugas-akhir/jadwal-bimbingan.php" class="text-green-600 hover:text-green-700 text-sm">
                Atur Jadwal <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="space-y-3">
            <?php if (empty($jadwal_bimbingan)): ?>
                <p class="text-gray-500 text-center py-4">Tidak ada jadwal bimbingan</p>
            <?php else: ?>
                <?php foreach ($jadwal_bimbingan as $j): ?>
                <div class="border-l-4 border-blue-500 pl-4 py-2">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold text-gray-800"><?= htmlspecialchars($j['judul_ta']) ?></p>
                            <p class="text-sm text-gray-600"><?= htmlspecialchars($j['nama_mahasiswa']) ?></p>
                            <p class="text-sm text-gray-500">
                                <i class="far fa-calendar mr-1"></i><?= formatTanggal($j['tanggal']) ?>
                                <i class="far fa-clock ml-3 mr-1"></i><?= date('H:i', strtotime($j['waktu'])) ?>
                            </p>
                        </div>
                        <?= getStatusBadge($j['status']) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Input Nilai Pending</h2>
            <a href="<?= BASE_URL ?>nilai/index.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Semua <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">MK</th>
                        <th class="px-4 py-2 text-left">Kelas</th>
                        <th class="px-4 py-2 text-left">Jml Mhs</th>
                        <th class="px-4 py-2 text-left">Deadline</th>
                        <th class="px-4 py-2 text-left">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($nilai_pending)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-4 text-center text-gray-500">Tidak ada nilai yang pending</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($nilai_pending as $n): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($n['nama_mk']) ?></td>
                            <td class="px-4 py-2"><?= htmlspecialchars($n['kelas']) ?></td>
                            <td class="px-4 py-2"><?= $n['jml_mhs'] ?></td>
                            <td class="px-4 py-2"><?= formatTanggal($n['deadline']) ?></td>
                            <td class="px-4 py-2">
                                <a href="<?= BASE_URL ?>nilai/input.php" class="text-green-600 hover:text-green-700">
                                    <i class="fas fa-edit"></i> Input
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



