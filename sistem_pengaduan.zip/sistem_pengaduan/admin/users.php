<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = has_role(ADMIN_ROLES);

$page_title = 'Manajemen Pengguna';
$pdo = getConnection();
$message = '';
$message_type = '';

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'add_user') {
            $stmt = $pdo->prepare("
                INSERT INTO users (nik, nama, email, password, telepon, alamat, role, is_active)
                VALUES (:nik, :nama, :email, :password, :telepon, :alamat, :role, 1)
            ");
            $stmt->execute([
                'nik' => $_POST['nik'],
                'nama' => $_POST['nama'],
                'email' => $_POST['email'],
                'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                'telepon' => $_POST['telepon'],
                'alamat' => $_POST['alamat'],
                'role' => $_POST['role']
            ]);
            $message = 'Pengguna baru berhasil ditambahkan.';
        } elseif ($action === 'delete_user') {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
            $stmt->execute(['id' => $_POST['user_id']]);
            $message = 'Pengguna dihapus.';
        } elseif ($action === 'toggle_active') {
            $stmt = $pdo->prepare("UPDATE users SET is_active = :active WHERE id = :id");
            $stmt->execute([
                'active' => $_POST['is_active'],
                'id' => $_POST['user_id']
            ]);
            $message = 'Status pengguna diperbarui.';
        }
        $message_type = 'success';
    } catch (PDOException $e) {
        error_log('Users admin error: ' . $e->getMessage());
        $message = 'Terjadi kesalahan.';
        $message_type = 'danger';
    }
}

$user_list = [];
try {
    $user_list = $pdo->query("SELECT id, nik, nama, email, telepon, role, is_active, created_at FROM users ORDER BY created_at DESC")->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch users error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Manajemen Pengguna</h2>
        <?php if ($can_update): ?>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addUserModal"><i class="fas fa-plus me-1"></i> Tambah Pengguna</button>
        <?php endif; ?>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Role</th>
                    <th>Status</th>
                    <?php if ($can_update): ?><th>Aksi</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($user_list)): ?>
                    <tr><td colspan="<?php echo $can_update ? 7 : 6; ?>" class="text-center text-muted">Belum ada pengguna.</td></tr>
                <?php else: ?>
                    <?php foreach ($user_list as $user): ?>
                        <tr>
                            <td><?php echo esc($user['nik']); ?></td>
                            <td><?php echo esc($user['nama']); ?></td>
                            <td><?php echo esc($user['email']); ?></td>
                            <td><?php echo esc($user['telepon']); ?></td>
                            <td><?php echo esc(ucfirst($user['role'])); ?></td>
                            <td><span class="badge <?php echo $user['is_active'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $user['is_active'] ? 'Aktif' : 'Nonaktif'; ?></span></td>
                            <?php if ($can_update): ?>
                                <td class="d-flex gap-2">
                                    <form action="users.php" method="POST">
                                        <input type="hidden" name="action" value="toggle_active">
                                        <input type="hidden" name="user_id" value="<?php echo esc($user['id']); ?>">
                                        <input type="hidden" name="is_active" value="<?php echo $user['is_active'] ? 0 : 1; ?>">
                                        <button class="btn btn-outline-primary btn-sm"><?php echo $user['is_active'] ? 'Nonaktifkan' : 'Aktifkan'; ?></button>
                                    </form>
                                    <form action="users.php" method="POST" onsubmit="return confirm('Hapus pengguna ini?');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?php echo esc($user['id']); ?>">
                                        <button class="btn btn-outline-danger btn-sm">Hapus</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($can_update): ?>
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="users.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Pengguna Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_user">
                    <div class="mb-3">
                        <label class="form-label">NIK</label>
                        <input type="text" name="nik" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telepon</label>
                        <input type="text" name="telepon" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-control">
                            <?php foreach (['admin','petugas','kepala_desa','warga'] as $role): ?>
                                <option value="<?php echo $role; ?>"><?php echo ucfirst(str_replace('_',' ', $role)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>











