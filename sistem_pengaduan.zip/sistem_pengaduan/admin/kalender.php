<?php
require_once '../includes/auth.php';

ensure_management_access();
$admin_page = true;
$can_update = !is_readonly_admin();

$pdo = getConnection();
$page_title = 'Kalender Desa';
$message = '';
$message_type = '';

if ($can_update && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $stmt = $pdo->prepare("
                INSERT INTO kalender_desa (judul_acara, deskripsi_acara, tanggal_mulai, tanggal_selesai, waktu_mulai, waktu_selesai, lokasi, jenis_acara)
                VALUES (:judul, :deskripsi, :mulai, :selesai, :w_mulai, :w_selesai, :lokasi, :jenis)
            ");
            $stmt->execute([
                'judul' => $_POST['judul_acara'],
                'deskripsi' => $_POST['deskripsi_acara'],
                'mulai' => $_POST['tanggal_mulai'],
                'selesai' => $_POST['tanggal_selesai'] ?: null,
                'w_mulai' => $_POST['waktu_mulai'] ?: null,
                'w_selesai' => $_POST['waktu_selesai'] ?: null,
                'lokasi' => $_POST['lokasi'],
                'jenis' => $_POST['jenis_acara']
            ]);
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM kalender_desa WHERE id = :id");
            $stmt->execute(['id' => $_POST['id']]);
        }
        $message = 'Agenda berhasil diperbarui.';
        $message_type = 'success';
    } catch (PDOException $e) {
        error_log('Kalender admin error: ' . $e->getMessage());
        $message = 'Terjadi kesalahan.';
        $message_type = 'danger';
    }
}

$events = [];
try {
    $events = $pdo->query("SELECT * FROM kalender_desa ORDER BY tanggal_mulai DESC")->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch kalender error: ' . $e->getMessage());
}

include '../includes/header.php';
?>

<div class="container my-4">
    <h2>Kalender Desa</h2>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>"><?php echo esc($message); ?></div>
    <?php endif; ?>

    <?php if ($can_update): ?>
        <div class="card mb-4">
            <div class="card-header">Tambah Agenda</div>
            <div class="card-body">
                <form action="kalender.php" method="POST">
                    <input type="hidden" name="action" value="create">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Judul Acara</label>
                            <input type="text" name="judul_acara" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Tanggal Mulai</label>
                            <input type="date" name="tanggal_mulai" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Tanggal Selesai</label>
                            <input type="date" name="tanggal_selesai" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Waktu Mulai</label>
                            <input type="time" name="waktu_mulai" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Waktu Selesai</label>
                            <input type="time" name="waktu_selesai" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Jenis Acara</label>
                            <select name="jenis_acara" class="form-control">
                                <?php foreach (['rapat','kegiatan','libur','peringatan','lainnya'] as $jenis): ?>
                                    <option value="<?php echo $jenis; ?>"><?php echo ucfirst($jenis); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Lokasi</label>
                            <input type="text" name="lokasi" class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi_acara" class="form-control" rows="3"></textarea>
                    </div>
                    <button class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Agenda Terdaftar</div>
        <div class="card-body">
            <?php if (empty($events)): ?>
                <p class="text-muted">Belum ada agenda.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php foreach ($events as $event): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo esc($event['judul_acara']); ?></strong>
                                <div class="text-muted small"><?php echo date('d M Y', strtotime($event['tanggal_mulai'])); ?><?php if ($event['tanggal_selesai']) echo ' - ' . date('d M Y', strtotime($event['tanggal_selesai'])); ?></div>
                                <p class="mb-0"><?php echo esc($event['deskripsi_acara']); ?></p>
                            </div>
                            <?php if ($can_update): ?>
                                <form action="kalender.php" method="POST" onsubmit="return confirm('Hapus agenda?');">
                                    <input type="hidden" name="id" value="<?php echo esc($event['id']); ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button class="btn btn-outline-danger btn-sm">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>











