<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('admin');

$pdo = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id = intval($_POST['id']);
    $status = sanitize($_POST['status']);
    
    $stmt = $pdo->prepare("UPDATE surat_menyurat SET status = ?, updated_at = NOW() WHERE id = ?");
    if ($stmt->execute([$status, $id])) {
        setFlashMessage('success', 'Status surat berhasil diperbarui');
    }
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$status_filter = $_GET['status'] ?? 'all';

$where = [];
$params = [];

if ($status_filter !== 'all') {
    $where[] = "s.status = ?";
    $params[] = $status_filter;
}

$whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "
    SELECT s.*, u.nama_lengkap, u.email, k.nama_kategori 
    FROM surat_menyurat s 
    LEFT JOIN users u ON s.user_id = u.id 
    LEFT JOIN kategori_surat k ON s.kategori_id = k.id
    $whereClause
    ORDER BY s.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$surat_list = $stmt->fetchAll();

$pageTitle = 'Kelola Surat Online - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-2 text-gray-800">Permohonan Surat Online</h1>
    <p class="text-gray-600 mb-6">Mode Admin: Hanya dapat mengelola surat yang sudah disetujui</p>

    <div class="bg-white rounded-lg p-4 mb-6 shadow-sm border border-gray-200">
        <form method="GET" class="flex items-center gap-4">
            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>Semua Status</option>
                <option value="menunggu" <?php echo $status_filter === 'menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                <option value="diproses" <?php echo $status_filter === 'diproses' ? 'selected' : ''; ?>>Diproses</option>
                <option value="selesai" <?php echo $status_filter === 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                <option value="ditolak" <?php echo $status_filter === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
            </select>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                Filter
            </button>
        </form>
    </div>

    <?php if (empty($surat_list)): ?>
        <div class="bg-white rounded-lg p-12 text-center border border-gray-200">
            <p class="text-gray-600 text-lg">Belum ada permohonan.</p>
        </div>
    <?php else: ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Surat</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Pemohon</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Keperluan</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Status</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Tanggal</th>
                            <th class="px-6 py-3 text-left text-sm font-semibold">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($surat_list as $surat): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($surat['jenis_surat']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($surat['nama_kategori'] ?? '-'); ?></div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($surat['nama_lengkap']); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo htmlspecialchars($surat['email']); ?></div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo htmlspecialchars(substr($surat['keperluan'], 0, 50)) . '...'; ?></td>
                                <td class="px-6 py-4">
                                    <?php echo getStatusBadge($surat['status'], 'surat'); ?>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo formatTanggal($surat['created_at']); ?></td>
                                <td class="px-6 py-4">
                                    <a href="<?php echo BASE_URL; ?>admin/surat_detail.php?id=<?php echo $surat['id']; ?>" 
                                        class="text-blue-600 hover:text-blue-700 text-sm">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

