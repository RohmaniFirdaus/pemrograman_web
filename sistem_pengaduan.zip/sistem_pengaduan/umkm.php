<?php
require_once 'includes/auth.php';

$pdo = getConnection();
$page_title = 'UMKM Desa';
$kategori = $_GET['kategori'] ?? '';

$sql = "
    SELECT u.*, us.nama AS pemilik
    FROM umkm u
    LEFT JOIN users us ON us.id = u.id_user
    WHERE 1=1
";
$params = [];
if ($kategori) {
    $sql .= " AND u.kategori = :kategori";
    $params['kategori'] = $kategori;
}
$sql .= " ORDER BY u.is_verified DESC, u.updated_at DESC";

$umkm_list = [];
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $umkm_list = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('UMKM list error: ' . $e->getMessage());
}

$extra_styles = <<<CSS
.umkm-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
}
.umkm-card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: var(--box-shadow);
}
.umkm-card img {
    width: 100%;
    height: 160px;
    object-fit: cover;
    border-radius: 10px;
    margin-bottom: 12px;
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
        <div>
            <h2>UMKM Unggulan</h2>
            <p class="text-muted mb-0">Mendukung ekonomi kreatif warga Gembong Kulon</p>
        </div>
        <form action="umkm.php" method="GET" class="d-flex gap-2">
            <select name="kategori" class="form-control">
                <option value="">Semua Kategori</option>
                <?php $opts = ['kuliner','kerajinan','jasa','perdagangan','pertanian','lainnya'];
                foreach ($opts as $opt): ?>
                    <option value="<?php echo $opt; ?>" <?php echo ($kategori === $opt ? 'selected' : ''); ?>><?php echo ucfirst($opt); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-primary">Filter</button>
        </form>
    </div>

    <div class="umkm-grid">
        <?php if (empty($umkm_list)): ?>
            <p class="text-muted">Belum ada data UMKM.</p>
        <?php else: ?>
            <?php foreach ($umkm_list as $umkm): ?>
                <div class="umkm-card">
                    <?php if ($umkm['gambar_umkm']): ?>
                        <img src="uploads/<?php echo esc($umkm['gambar_umkm']); ?>" alt="<?php echo esc($umkm['nama_umkm']); ?>">
                    <?php endif; ?>
                    <h4><?php echo esc($umkm['nama_umkm']); ?></h4>
                    <span class="badge bg-success mb-2"><?php echo esc(ucfirst($umkm['kategori'])); ?></span>
                    <p class="text-muted"><?php echo esc(substr($umkm['deskripsi'], 0, 120)); ?>...</p>
                    <small>Pemilik: <?php echo esc($umkm['pemilik'] ?? 'Warga'); ?></small><br>
                    <?php if ($umkm['telepon']): ?>
                        <small>Kontak: <?php echo esc($umkm['telepon']); ?></small>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>











