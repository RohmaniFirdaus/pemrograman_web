<?php
require_once '../config/config.php';
requireRole(['admin', 'pimpinan']);

$pageTitle = 'Laporan Surat';
$currentModule = 'laporan';

$conn = getDBConnection();

// Statistik surat
$total_surat = $conn->query("SELECT COUNT(*) as total FROM surat")->fetch_assoc()['total'];
$surat_masuk = $conn->query("SELECT COUNT(*) as total FROM surat WHERE jenis = 'masuk'")->fetch_assoc()['total'];
$surat_keluar = $conn->query("SELECT COUNT(*) as total FROM surat WHERE jenis = 'keluar'")->fetch_assoc()['total'];

// By status
$by_status = $conn->query("
    SELECT status, COUNT(*) as jumlah
    FROM surat
    GROUP BY status
")->fetch_all(MYSQLI_ASSOC);

// By tujuan
$by_tujuan = $conn->query("
    SELECT tujuan, COUNT(*) as jumlah
    FROM surat
    GROUP BY tujuan
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Laporan Surat</h1>
        <a href="export.php?type=surat" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
            <i class="fas fa-download mr-2"></i>Export PDF
        </a>
    </div>
    
    <!-- Statistik -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Total Surat</p>
            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_surat ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Surat Masuk</p>
            <p class="text-3xl font-bold text-blue-600 mt-2"><?= $surat_masuk ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <p class="text-gray-600 text-sm">Surat Keluar</p>
            <p class="text-3xl font-bold text-green-600 mt-2"><?= $surat_keluar ?></p>
        </div>
    </div>
    
    <!-- By Status -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jumlah Arsip Surat (by Status)</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <?php foreach ($by_status as $s): ?>
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm"><?= ucfirst(str_replace('_', ' ', $s['status'])) ?></p>
                <p class="text-2xl font-bold text-gray-800"><?= $s['jumlah'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- By Tujuan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Jumlah Surat (by Tujuan)</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <?php foreach ($by_tujuan as $t): ?>
            <div class="text-center p-4 bg-gray-50 rounded">
                <p class="text-gray-600 text-sm"><?= ucfirst($t['tujuan']) ?></p>
                <p class="text-2xl font-bold text-gray-800"><?= $t['jumlah'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



