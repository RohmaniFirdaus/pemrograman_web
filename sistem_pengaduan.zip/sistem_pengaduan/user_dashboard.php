<?php
require_once 'includes/auth.php';

require_login('user_login.php');

$page_title = 'Dashboard Warga';
$message = '';
$message_type = '';

$user_id = $_SESSION['user_id'] ?? null;
$current_user_data = current_user();
$username = $current_user_data['nama'] ?? 'Pengguna';

if (!$user_id) {
    header('Location: user_login.php');
    exit;
}

$pdo = getConnection();
if (!$pdo) {
    $message = 'Koneksi database tidak tersedia.';
    $message_type = 'danger';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['pengaduan_id'])) {
    if ($_POST['action'] === 'cancel_pengaduan') {
        try {
            $stmt = $pdo->prepare("UPDATE pengaduan SET status = 'ditolak', updated_at = NOW() WHERE id = :id AND id_user = :user AND status = 'menunggu'");
            $stmt->execute([
                'id' => $_POST['pengaduan_id'],
                'user' => $user_id
            ]);
            $message = 'Pengaduan berhasil dibatalkan.';
            $message_type = 'success';
        } catch (PDOException $e) {
            error_log('Cancel pengaduan error: ' . $e->getMessage());
            $message = 'Gagal membatalkan pengaduan.';
            $message_type = 'danger';
        }
    }
}

$pengaduan_user = [];
$surat_summary = [];
$stats = [
    'menunggu' => 0,
    'diproses' => 0,
    'selesai' => 0,
    'ditolak' => 0
];

if ($pdo && $user_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT id, kode_pengaduan, judul, status, prioritas, tanggal_pengaduan, created_at
            FROM pengaduan
            WHERE id_user = :user
            ORDER BY created_at DESC
        ");
        $stmt->execute(['user' => $user_id]);
        $pengaduan_user = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($pengaduan_user as $row) {
            $key = strtolower($row['status']);
            if (isset($stats[$key])) {
                $stats[$key]++;
            }
        }

        $stmtSurat = $pdo->prepare("
            SELECT s.id, s.status, s.tanggal_pengajuan, js.nama_surat
            FROM surat_online s
            LEFT JOIN jenis_surat js ON js.id = s.id_jenis_surat
            WHERE s.id_user = :user
            ORDER BY s.created_at DESC
            LIMIT 3
        ");
        $stmtSurat->execute(['user' => $user_id]);
        $surat_summary = $stmtSurat->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log('Dashboard user error: ' . $e->getMessage());
        $message = 'Terjadi kesalahan saat memuat data. Silakan refresh halaman atau hubungi administrator.';
        $message_type = 'danger';
        $pengaduan_user = [];
        $surat_summary = [];
    }
} else {
    if (!$pdo) {
        $message = 'Koneksi database tidak tersedia.';
        $message_type = 'danger';
    } elseif (!$user_id) {
        $message = 'Session tidak valid. Silakan login kembali.';
        $message_type = 'danger';
    }
    $pengaduan_user = [];
    $surat_summary = [];
}

$extra_styles = <<<CSS
.dashboard-welcome {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: #fff;
    border-radius: 15px;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.dashboard-welcome h2 {
    color: #fff;
    margin: 0 0 15px 0;
    font-size: 2rem;
}

.dashboard-welcome .action-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    margin-top: 20px;
}

.dashboard-welcome .btn {
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.dashboard-welcome .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(2, 136, 209, 0.1) 0%, transparent 70%);
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.stat-card:hover::before {
    top: -30%;
    right: -30%;
}

.stat-card.menunggu { border-left-color: var(--warning-color); }
.stat-card.diproses { border-left-color: var(--info-color); }
.stat-card.selesai { border-left-color: var(--success-color); }
.stat-card.ditolak { border-left-color: var(--danger-color); }

.stat-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.stat-card-icon {
    font-size: 2rem;
    opacity: 0.7;
}

.stat-card.menunggu .stat-card-icon { color: var(--warning-color); }
.stat-card.diproses .stat-card-icon { color: var(--info-color); }
.stat-card.selesai .stat-card-icon { color: var(--success-color); }
.stat-card.ditolak .stat-card-icon { color: var(--danger-color); }

.stat-card-label {
    color: #666;
    font-size: 0.9rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin: 0;
}

.stat-card-value {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin: 10px 0 0 0;
    line-height: 1;
}

.content-section {
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.content-section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
}

.content-section-header h3 {
    color: var(--primary-color);
    font-size: 1.75rem;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.content-section-header i {
    color: var(--accent-color);
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state i {
    font-size: 4rem;
    color: var(--border-color);
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state p {
    font-size: 1.1rem;
    margin: 0;
    color: #666;
}

.pengaduan-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 15px;
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.pengaduan-card:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.pengaduan-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
    gap: 15px;
}

.pengaduan-card-title {
    flex: 1;
}

.pengaduan-card-title strong {
    color: var(--primary-color);
    font-size: 1.1rem;
    display: block;
    margin-bottom: 5px;
}

.pengaduan-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px solid var(--border-color);
}

.pengaduan-card-meta small {
    color: #888;
    display: flex;
    align-items: center;
    gap: 5px;
}

.pengaduan-card-actions {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.surat-list-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 15px;
    border-left: 4px solid var(--accent-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.surat-list-card:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.surat-list-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.surat-list-card-title {
    font-weight: 700;
    color: var(--primary-color);
    font-size: 1.1rem;
}

.surat-list-card-meta {
    color: #888;
    font-size: 0.9rem;
    margin-top: 8px;
}

.btn-outline-primary {
    background: transparent;
    border: 2px solid var(--primary-color);
    color: var(--primary-color);
    transition: all 0.3s ease;
}

.btn-outline-primary:hover {
    background: var(--primary-color);
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .dashboard-welcome .action-buttons {
        flex-direction: column;
    }
    
    .dashboard-welcome .action-buttons .btn {
        width: 100%;
    }
    
    .pengaduan-card-actions {
        flex-direction: column;
    }
    
    .pengaduan-card-actions .btn {
        width: 100%;
    }
}
CSS;

include 'includes/header.php';
?>

<div class="container my-4">
    <!-- Welcome Section -->
    <div class="dashboard-welcome">
        <h2><i class="fas fa-user-circle"></i> Halo, <?php echo esc($username); ?></h2>
        <p style="margin: 0; opacity: 0.9;">Selamat datang di Dashboard Warga Desa Gembong Kulon</p>
        <div class="action-buttons">
            <a href="buat_pengaduan.php" class="btn btn-light">
                <i class="fas fa-plus"></i> Pengaduan Baru
            </a>
            <a href="surat_online.php" class="btn btn-light">
                <i class="fas fa-file-alt"></i> Ajukan Surat
            </a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?php echo esc($message_type); ?>" style="margin-bottom: 25px;">
            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo esc($message); ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card menunggu">
            <div class="stat-card-header">
                <div>
                    <p class="stat-card-label">Menunggu</p>
                    <h3 class="stat-card-value"><?php echo esc($stats['menunggu']); ?></h3>
                </div>
                <i class="fas fa-clock stat-card-icon"></i>
            </div>
        </div>
        <div class="stat-card diproses">
            <div class="stat-card-header">
                <div>
                    <p class="stat-card-label">Diproses</p>
                    <h3 class="stat-card-value"><?php echo esc($stats['diproses']); ?></h3>
                </div>
                <i class="fas fa-spinner stat-card-icon"></i>
            </div>
        </div>
        <div class="stat-card selesai">
            <div class="stat-card-header">
                <div>
                    <p class="stat-card-label">Selesai</p>
                    <h3 class="stat-card-value"><?php echo esc($stats['selesai']); ?></h3>
                </div>
                <i class="fas fa-check-circle stat-card-icon"></i>
            </div>
        </div>
        <div class="stat-card ditolak">
            <div class="stat-card-header">
                <div>
                    <p class="stat-card-label">Ditolak</p>
                    <h3 class="stat-card-value"><?php echo esc($stats['ditolak']); ?></h3>
                </div>
                <i class="fas fa-times-circle stat-card-icon"></i>
            </div>
        </div>
    </div>

    <!-- Pengaduan Section -->
    <div class="content-section">
        <div class="content-section-header">
            <h3>
                <i class="fas fa-clipboard-list"></i>
                Pengaduan Saya
            </h3>
        </div>
        <?php if (empty($pengaduan_user)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <p>Belum ada pengaduan.</p>
                <p style="font-size: 0.9rem; margin-top: 10px;">Mulai dengan membuat pengaduan baru di tombol di atas.</p>
            </div>
        <?php else: ?>
            <?php foreach ($pengaduan_user as $pengaduan): ?>
                <div class="pengaduan-card">
                    <div class="pengaduan-card-header">
                        <div class="pengaduan-card-title">
                            <strong><?php echo esc($pengaduan['judul']); ?></strong>
                            <span class="status-badge status-<?php echo esc(strtolower($pengaduan['status'])); ?>" style="margin-top: 8px; display: inline-block;">
                                <?php echo esc(ucfirst($pengaduan['status'])); ?>
                            </span>
                        </div>
                    </div>
                    <div class="pengaduan-card-meta">
                        <small>
                            <i class="fas fa-hashtag"></i>
                            <strong>Kode:</strong> <?php echo esc($pengaduan['kode_pengaduan']); ?>
                        </small>
                        <small>
                            <i class="fas fa-calendar"></i>
                            <strong>Tanggal:</strong> <?php echo date('d M Y', strtotime($pengaduan['tanggal_pengaduan'])); ?>
                        </small>
                        <small>
                            <i class="fas fa-flag"></i>
                            <strong>Prioritas:</strong> <?php echo esc(ucfirst($pengaduan['prioritas'])); ?>
                        </small>
                    </div>
                    <div class="pengaduan-card-actions">
                        <a href="detail_pengaduan_user.php?id=<?php echo esc($pengaduan['id']); ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-eye"></i> Lihat Detail
                        </a>
                        <?php if ($pengaduan['status'] === 'menunggu'): ?>
                            <form action="user_dashboard.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin membatalkan pengaduan ini?');" style="display: inline;">
                                <input type="hidden" name="action" value="cancel_pengaduan">
                                <input type="hidden" name="pengaduan_id" value="<?php echo esc($pengaduan['id']); ?>">
                                <button type="submit" class="btn btn-outline-danger btn-sm">
                                    <i class="fas fa-times"></i> Batalkan
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Surat Section -->
    <div class="content-section">
        <div class="content-section-header">
            <h3>
                <i class="fas fa-file-contract"></i>
                Permohonan Surat Terakhir
            </h3>
        </div>
        <?php if (empty($surat_summary)): ?>
            <div class="empty-state">
                <i class="fas fa-file-alt"></i>
                <p>Belum ada permohonan surat.</p>
                <p style="font-size: 0.9rem; margin-top: 10px;">Ajukan surat online melalui tombol di atas.</p>
            </div>
        <?php else: ?>
            <?php foreach ($surat_summary as $surat): ?>
                <div class="surat-list-card">
                    <div class="surat-list-card-header">
                        <div class="surat-list-card-title"><?php echo esc($surat['nama_surat'] ?? 'Surat'); ?></div>
                        <span class="status-badge status-<?php echo esc(strtolower($surat['status'])); ?>">
                            <?php echo esc(ucfirst($surat['status'])); ?>
                        </span>
                    </div>
                    <div class="surat-list-card-meta">
                        <i class="fas fa-calendar-alt"></i>
                        Pengajuan: <?php echo date('d M Y', strtotime($surat['tanggal_pengajuan'])); ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <div style="text-align: center; margin-top: 20px;">
                <a href="surat_online.php" class="btn btn-primary">
                    <i class="fas fa-list"></i> Lihat Semua Surat
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>