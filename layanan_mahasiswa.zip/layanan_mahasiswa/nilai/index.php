<?php
require_once '../config/config.php';
requireRole(['admin', 'mahasiswa', 'dosen', 'pimpinan']);

$pageTitle = 'Nilai';
$currentModule = 'nilai';

$user = getCurrentUser();
$conn = getDBConnection();

if ($_SESSION['role'] === 'mahasiswa') {
    $mahasiswa = $conn->query("SELECT * FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
    header('Location: khs.php');
    exit;
} elseif ($_SESSION['role'] === 'dosen') {
    $dosen = $conn->query("SELECT * FROM dosen WHERE user_id = " . $user['id'])->fetch_assoc();
    // Get mata kuliah yang diajar
    $mk_list = $conn->query("
        SELECT DISTINCT mk.* 
        FROM mata_kuliah mk
        JOIN jadwal_kuliah j ON mk.id = j.mk_id
        WHERE j.dosen_id = " . $dosen['id'] . "
        ORDER BY mk.semester, mk.kode_mk
    ")->fetch_all(MYSQLI_ASSOC);
} else {
    // Admin/Pimpinan - show all
    $mk_list = $conn->query("SELECT * FROM mata_kuliah WHERE status = 'active' ORDER BY semester, kode_mk")->fetch_all(MYSQLI_ASSOC);
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Nilai</h1>
    
    <?php if ($_SESSION['role'] === 'dosen'): ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="input.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-edit text-green-600 text-4xl mb-3"></i>
            <h2 class="text-xl font-bold text-gray-800">Input Nilai</h2>
            <p class="text-gray-600 text-sm mt-2">Input nilai mahasiswa</p>
        </a>
        
        <a href="khs.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-file-alt text-blue-600 text-4xl mb-3"></i>
            <h2 class="text-xl font-bold text-gray-800">KHS</h2>
            <p class="text-gray-600 text-sm mt-2">Lihat KHS mahasiswa</p>
        </a>
        
        <a href="transkrip.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-certificate text-purple-600 text-4xl mb-3"></i>
            <h2 class="text-xl font-bold text-gray-800">Transkrip</h2>
            <p class="text-gray-600 text-sm mt-2">Lihat transkrip nilai</p>
        </a>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Mata Kuliah yang Diajar</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($mk_list as $mk): ?>
            <a href="input.php?mk_id=<?= $mk['id'] ?>" class="border rounded-lg p-4 hover:bg-gray-50">
                <p class="font-semibold"><?= htmlspecialchars($mk['kode_mk']) ?> - <?= htmlspecialchars($mk['nama_mk']) ?></p>
                <p class="text-sm text-gray-600"><?= $mk['sks'] ?> SKS | Semester <?= $mk['semester'] ?></p>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php elseif (in_array($_SESSION['role'], ['admin', 'pimpinan'])): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <a href="khs.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-file-alt text-blue-600 text-4xl mb-3"></i>
            <h2 class="text-xl font-bold text-gray-800">KHS</h2>
            <p class="text-gray-600 text-sm mt-2">Lihat KHS mahasiswa</p>
        </a>
        
        <a href="transkrip.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-certificate text-purple-600 text-4xl mb-3"></i>
            <h2 class="text-xl font-bold text-gray-800">Transkrip</h2>
            <p class="text-gray-600 text-sm mt-2">Lihat transkrip nilai</p>
        </a>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>



