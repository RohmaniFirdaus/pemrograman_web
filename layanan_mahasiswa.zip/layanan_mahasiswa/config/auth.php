<?php

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'auth/login.php');
        exit;
    }
}

function requireRole($allowedRoles) {
    requireLogin();
    if (!in_array($_SESSION['role'], $allowedRoles)) {
        header('Location: ' . BASE_URL . 'dashboard/index.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $conn = getDBConnection();
    $user_id = $_SESSION['user_id'];
    $role = $_SESSION['role'];
    
    $user = null;
    
    switch ($role) {
        case 'admin':
            $stmt = $conn->prepare("SELECT u.*, d.nip, d.nama_dosen as nama, d.email FROM users u LEFT JOIN dosen d ON u.id = d.user_id WHERE u.id = ?");
            break;
        case 'mahasiswa':
            $stmt = $conn->prepare("SELECT u.*, m.nim, m.nama_mahasiswa as nama, m.prodi_id, m.semester, m.ipk, m.sks_tempuh FROM users u LEFT JOIN mahasiswa m ON u.id = m.user_id WHERE u.id = ?");
            break;
        case 'dosen':
            $stmt = $conn->prepare("SELECT u.*, d.nip, d.nama_dosen as nama, d.prodi_id, d.email FROM users u LEFT JOIN dosen d ON u.id = d.user_id WHERE u.id = ?");
            break;
        case 'pimpinan':
            $stmt = $conn->prepare("SELECT u.*, p.nip, p.nama_pimpinan as nama, p.jabatan, p.email FROM users u LEFT JOIN pimpinan p ON u.id = p.user_id WHERE u.id = ?");
            break;
        default:
            return null;
    }
    
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    return $user;
}

function logout() {
    session_unset();
    session_destroy();
    header('Location: ' . BASE_URL . 'auth/login.php');
    exit;
}
?>



