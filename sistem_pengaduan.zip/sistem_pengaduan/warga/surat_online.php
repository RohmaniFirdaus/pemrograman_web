<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

requireRole('warga');

$pdo = getDBConnection();
$user_id = $_SESSION['user_id'];

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis_surat = sanitize($_POST['jenis_surat'] ?? '');
    $kategori_id = intval($_POST['kategori_id'] ?? 0);
    $keperluan = sanitize($_POST['keperluan'] ?? '');
    $detail_tambahan = sanitize($_POST['detail_tambahan'] ?? '');
    
    if (empty($jenis_surat) || empty($keperluan)) {
        $error = 'Jenis surat dan keperluan harus diisi';
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO surat_menyurat (user_id, jenis_surat, kategori_id, keperluan, detail_data_tambahan, status) 
            VALUES (?, ?, ?, ?, ?, 'menunggu')
        ");
        
        if ($stmt->execute([$user_id, $jenis_surat, $kategori_id ?: null, $keperluan, $detail_tambahan ?: null])) {
            setFlashMessage('success', 'Permohonan surat berhasil dikirim! Menunggu verifikasi admin.');
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $error = 'Gagal mengirim permohonan surat';
        }
    }
}

$stmt = $pdo->query("SELECT * FROM kategori_surat ORDER BY nama_kategori");
$kategori_list = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT * FROM surat_menyurat 
    WHERE user_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$user_id]);
$surat_list = $stmt->fetchAll();

$flash = getFlashMessage();
if ($flash) {
    if ($flash['type'] === 'success') {
        $success = $flash['message'];
    } else {
        $error = $flash['message'];
    }
}

$pageTitle = 'Surat Online Warga - ' . APP_NAME;
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">
                <i class="fas fa-file-alt mr-2"></i>Ajukan Surat Online
            </h2>

            <?php if ($error): ?>
                <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
                    <p><?php echo $error; ?></p>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 mb-6 rounded">
                    <p><?php echo $success; ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Jenis Surat <span class="text-red-500">*</span></label>
                    <select name="jenis_surat" required class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">-- Pilih Jenis Surat --</option>
                        <option value="Surat Keterangan">Surat Keterangan</option>
                        <option value="Surat Pengantar">Surat Pengantar</option>
                        <option value="Surat Domisili">Surat Domisili</option>
                        <option value="Surat Keterangan Tidak Mampu">Surat Keterangan Tidak Mampu</option>
                        <option value="Surat Izin">Surat Izin</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Keperluan <span class="text-red-500">*</span></label>
                    <textarea name="keperluan" required rows="5"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Jelaskan keperluan surat yang Anda butuhkan..."></textarea>
                </div>

                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Detail Data Tambahan</label>
                    <textarea name="detail_tambahan" rows="4"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Contoh: Nama orang tua, alamat tujuan, atau informasi tambahan lainnya"></textarea>
                    <p class="text-sm text-gray-500 mt-1">Opsional: Isi jika diperlukan informasi tambahan</p>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition">
                    <i class="fas fa-paper-plane mr-2"></i>Kirim Permohonan
                </button>
            </form>
        </div>

        <div class="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">
                <i class="fas fa-clock mr-2"></i>Riwayat Permohonan Surat
            </h2>

            <?php if (empty($surat_list)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-file-alt text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 mb-2">Belum ada permohonan surat.</p>
                    <p class="text-gray-500 text-sm">Mulai dengan mengajukan permohonan surat di form sebelah kiri.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($surat_list as $surat): ?>
                        <div class="border-l-4 border-blue-500 pl-4 py-3 bg-gray-50 rounded">
                            <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($surat['jenis_surat']); ?></h3>
                            <p class="text-sm text-gray-600 mt-1"><?php echo htmlspecialchars(substr($surat['keperluan'], 0, 50)) . '...'; ?></p>
                            <div class="flex items-center justify-between mt-2">
                                <?php echo getStatusBadge($surat['status'], 'surat'); ?>
                                <span class="text-xs text-gray-500"><?php echo formatTanggal($surat['created_at']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

