<?php
require_once '../config/config.php';
requireRole(['mahasiswa']);

$pageTitle = 'Ajukan Cicilan';
$currentModule = 'tagihan';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$user = getCurrentUser();
$conn = getDBConnection();

$mhs = $conn->query("SELECT id FROM mahasiswa WHERE user_id = " . $user['id'])->fetch_assoc();
$tagihan = $conn->query("
    SELECT * FROM tagihan 
    WHERE id = $id AND mahasiswa_id = " . $mhs['id'] . "
")->fetch_assoc();

if (!$tagihan) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jumlah_cicilan = intval($_POST['jumlah_cicilan'] ?? 0);
    
    if ($jumlah_cicilan >= 2 && $jumlah_cicilan <= 6) {
        // Calculate cicilan amount
        $nominal_cicilan = $tagihan['sisa_tagihan'] / $jumlah_cicilan;
        
        // Create cicilan schedule (simplified - in production would create multiple payment records)
        $success = 'Pengajuan cicilan berhasil. Silakan hubungi admin untuk konfirmasi.';
        header('Location: detail.php?id=' . $id);
        exit;
    } else {
        $error = 'Jumlah cicilan harus antara 2-6 kali';
    }
}

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Ajukan Cicilan</h1>
        <a href="detail.php?id=<?= $id ?>" class="text-gray-600 hover:text-gray-800">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>
    
    <!-- Info Tagihan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Informasi Tagihan</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <p class="text-gray-600 text-sm">Nomor Tagihan</p>
                <p class="font-semibold"><?= htmlspecialchars($tagihan['nomor_tagihan']) ?></p>
            </div>
            <div>
                <p class="text-gray-600 text-sm">Sisa Tagihan</p>
                <p class="font-semibold text-xl text-red-600"><?= formatRupiah($tagihan['sisa_tagihan']) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Form Cicilan -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Form Pengajuan Cicilan</h2>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">Jumlah Cicilan *</label>
                <select name="jumlah_cicilan" required class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                    <option value="">Pilih Jumlah Cicilan</option>
                    <?php for ($i = 2; $i <= 6; $i++): ?>
                        <option value="<?= $i ?>">
                            <?= $i ?>x Cicilan (<?= formatRupiah($tagihan['sisa_tagihan'] / $i) ?> per cicilan)
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <p class="text-sm text-yellow-800">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Pengajuan cicilan akan direview oleh admin. Anda akan mendapat notifikasi setelah disetujui.
                </p>
            </div>
            
            <div class="flex justify-end space-x-4">
                <a href="detail.php?id=<?= $id ?>" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                    Batal
                </a>
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                    <i class="fas fa-paper-plane mr-2"></i>Ajukan Cicilan
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



