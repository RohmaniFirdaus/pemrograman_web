<?php
require_once 'includes/auth.php';

$pdo = getConnection();

$profil_default = [
    'nama_desa'    => 'Desa Gembong Kulon',
    'alamat_desa'  => 'Kecamatan Talang, Kabupaten Tegal',
    'telepon_desa' => '0283-123456',
    'email_desa'   => 'info@desagembongkulon.id',
    'deskripsi_desa' => 'Portal pelayanan publik terpadu untuk pengaduan, surat online, berita, UMKM, dan kalender kegiatan Desa Gembong Kulon.',
    'visi_misi'    => 'Visi: Desa maju, mandiri, dan sejahtera. Misi: Pelayanan prima, transparansi data, dan partisipasi aktif masyarakat.',
    'sejarah_desa' => 'Gembong Kulon berkembang dari komunitas agraris menjadi desa digital yang berpihak pada warga.',
    'logo_desa'    => null,
    'gambar_desa'  => null,
];

$profil_desa = $profil_default;

if ($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM profil_desa ORDER BY id DESC LIMIT 1");
        $profil_db = $stmt->fetch();
        if ($profil_db) {
            $profil_desa = array_merge($profil_desa, array_filter($profil_db, fn($value) => $value !== null));
        }
    } catch (PDOException $e) {
        error_log('Profil desa error: ' . $e->getMessage());
    }
}

$stats = [
    'total_pengaduan' => 0,
    'menunggu'        => 0,
    'diproses'        => 0,
    'selesai'         => 0,
    'ditolak'         => 0,
    'surat_diproses'  => 0,
    'umkm_verified'   => 0,
    'berita_published'=> 0,
];

if ($pdo) {
    try {
        $counts = $pdo->query("SELECT status, COUNT(*) as total FROM pengaduan GROUP BY status")->fetchAll();
        foreach ($counts as $row) {
            $key = strtolower($row['status']);
            if (isset($stats[$key])) {
                $stats[$key] = (int)$row['total'];
            }
        }
        $stats['total_pengaduan'] = (int)$pdo->query("SELECT COUNT(*) FROM pengaduan")->fetchColumn();
        $stats['surat_diproses'] = (int)$pdo->query("SELECT COUNT(*) FROM surat_online WHERE status IN ('menunggu','diproses')")->fetchColumn();
        $stats['umkm_verified'] = (int)$pdo->query("SELECT COUNT(*) FROM umkm WHERE is_verified = 1")->fetchColumn();
        $stats['berita_published'] = (int)$pdo->query("SELECT COUNT(*) FROM berita_desa WHERE is_published = 1")->fetchColumn();
    } catch (PDOException $e) {
        error_log('Stats error: ' . $e->getMessage());
    }
}

$latest_pengaduan = [];
$berita_terbaru = [];
$umkm_unggulan = [];
$kalender_events = [];

if ($pdo) {
    try {
        $stmt = $pdo->query("
            SELECT p.id, p.kode_pengaduan, p.judul, p.deskripsi, p.status, p.prioritas, p.tanggal_pengaduan,
                   kp.nama_kategori, u.nama AS nama_pelapor
            FROM pengaduan p
            LEFT JOIN kategori_pengaduan kp ON kp.id = p.id_kategori
            LEFT JOIN users u ON u.id = p.id_user
            ORDER BY p.created_at DESC
            LIMIT 6
        ");
        $latest_pengaduan = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('Pengaduan terbaru error: ' . $e->getMessage());
    }

    try {
        $stmt = $pdo->prepare("
            SELECT b.id, b.judul, b.konten, b.gambar_utama, b.tanggal_publish, u.nama AS penulis
            FROM berita_desa b
            LEFT JOIN users u ON u.id = b.id_user
            WHERE b.is_published = 1
            ORDER BY COALESCE(b.tanggal_publish, b.created_at) DESC
            LIMIT 3
        ");
        $stmt->execute();
        $berita_terbaru = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('Berita error: ' . $e->getMessage());
    }

    try {
        $stmt = $pdo->query("
            SELECT uks.id, uks.nama_umkm, uks.deskripsi, uks.kategori, uks.gambar_umkm,
                   uks.is_verified, uks.telepon, us.nama AS pemilik
            FROM umkm uks
            LEFT JOIN users us ON us.id = uks.id_user
            WHERE uks.is_verified = 1
            ORDER BY uks.updated_at DESC
            LIMIT 3
        ");
        $umkm_unggulan = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('UMKM error: ' . $e->getMessage());
    }

    try {
        $stmt = $pdo->prepare("
            SELECT * FROM kalender_desa
            WHERE (tanggal_mulai >= CURDATE()) OR (tanggal_mulai <= CURDATE() AND tanggal_selesai >= CURDATE())
            ORDER BY tanggal_mulai ASC
            LIMIT 5
        ");
        $stmt->execute();
        $kalender_events = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('Kalender error: ' . $e->getMessage());
    }
}

function format_ticket(array $pengaduan): string {
    if (!empty($pengaduan['kode_pengaduan'])) {
        return $pengaduan['kode_pengaduan'];
    }
    return sprintf('PGD-%05d', $pengaduan['id'] ?? 0);
}

function format_tanggal($tanggal): string {
    if (!$tanggal) {
        return '-';
    }
    return date('d M Y', strtotime($tanggal));
}

$hero_background = !empty($profil_desa['gambar_desa']) ? 'uploads/' . $profil_desa['gambar_desa'] : null;
$page_title = 'Beranda - Sistem Desa Gembong Kulon';

$extra_styles = <<<CSS
.hero-section {
    color: #fff;
    padding: 100px 0;
    text-align: center;
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--dark-bg) 100%);
    background-size: cover;
    background-position: center;
    position: relative;
    overflow: hidden;
}
.hero-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(1, 87, 155, 0.85);
    z-index: 1;
}
.hero-content {
    position: relative;
    z-index: 2;
}
.hero-section h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}
.hero-section .lead {
    font-size: 1.3rem;
    margin-bottom: 30px;
    opacity: 0.95;
}

.stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 25px;
    margin-top: 30px;
}
.stat-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    text-align: center;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
.stat-card p {
    color: #666;
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.stat-card h3 {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin: 0;
}

.section-title {
    text-align: center;
    margin-bottom: 40px;
}
.section-title h2 {
    color: var(--primary-color);
    font-size: 2.2rem;
    margin-bottom: 10px;
    position: relative;
    display: inline-block;
}
.section-title h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 4px;
    background: var(--primary-color);
    border-radius: 2px;
}
.section-title p {
    color: #666;
    font-size: 1rem;
    margin-top: 20px;
}

.profil-desa {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 40px;
    align-items: center;
    background: #fff;
    padding: 40px;
    border-radius: 16px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
}
.profil-desa img {
    width: 100%;
    border-radius: 16px;
    box-shadow: var(--box-shadow);
}
.mask-gradient {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: #fff;
    border-radius: 16px;
    padding: 50px 40px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    text-align: center;
}
.mask-gradient h4 {
    font-size: 1.8rem;
    margin-bottom: 20px;
}

.card-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
}
.card-item {
    background: #fff;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    height: 100%;
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border-top: 4px solid var(--primary-color);
}
.card-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
.empty-state-card {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border: 2px dashed var(--border-color);
    border-radius: 16px;
    padding: 60px 30px;
    text-align: center;
    grid-column: 1 / -1;
}
.empty-state-card i {
    font-size: 4rem;
    color: var(--border-color);
    margin-bottom: 20px;
    opacity: 0.5;
}
.empty-state-card p {
    color: #666;
    font-size: 1.1rem;
    margin: 0;
}

.calendar-list {
    list-style: none;
    padding: 0;
    margin: 0;
}
.calendar-item {
    display: flex;
    gap: 20px;
    padding: 25px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    border-left: 4px solid var(--primary-color);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.calendar-item:hover {
    transform: translateX(5px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.12);
}
.calendar-date {
    min-width: 80px;
    text-align: center;
    border-right: 2px solid var(--border-color);
    padding-right: 20px;
}
.calendar-date strong {
    display: block;
    font-size: 2rem;
    color: var(--primary-color);
    line-height: 1;
}
.calendar-date div {
    color: #666;
    font-size: 0.9rem;
    margin-top: 5px;
}

.umkm-card {
    position: relative;
}
.umkm-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.umkm-card .badge-kategori {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--primary-color);
    color: #fff;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
}

.badge-prioritas {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}
.badge-prioritas.rendah {
    background: #e3f2fd;
    color: var(--info-color);
}
.badge-prioritas.sedang {
    background: #fff3e0;
    color: #f57c00;
}
.badge-prioritas.tinggi {
    background: #ffebee;
    color: var(--danger-color);
}

.how-it-works-section {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}
.how-it-works-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}
.how-it-works-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    padding: 40px 30px;
    text-align: center;
    position: relative;
    overflow: hidden;
}
.how-it-works-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color) 0%, var(--secondary-color) 100%);
}
.how-it-works-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
.how-it-works-number {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    font-size: 2rem;
    font-weight: 700;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.how-it-works-number.primary {
    background: var(--primary-color);
    color: #fff;
}
.how-it-works-number.warning {
    background: var(--warning-color);
    color: #856404;
}
.how-it-works-number.success {
    background: var(--success-color);
    color: #fff;
}
.how-it-works-icon {
    font-size: 2.5rem;
    color: var(--primary-color);
    margin-bottom: 20px;
}
.how-it-works-card h3 {
    color: var(--primary-color);
    font-size: 1.4rem;
    margin-bottom: 15px;
    font-weight: 700;
}
.how-it-works-card p {
    color: #666;
    line-height: 1.7;
    margin: 0;
}
@media (max-width: 992px) {
    .how-it-works-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
    }
}
@media (max-width: 768px) {
    .how-it-works-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    .how-it-works-card {
        padding: 30px 20px;
    }
}

.cta-section {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--dark-bg) 100%);
    color: #fff;
    text-align: center;
}
.cta-section h3 {
    font-size: 2.5rem;
    margin-bottom: 15px;
}
.cta-section .lead {
    font-size: 1.2rem;
    opacity: 0.95;
    margin-bottom: 30px;
}

@media (max-width: 768px) {
    .hero-section {
        padding: 60px 0;
    }
    .hero-section h1 {
        font-size: 2rem;
    }
    .stat-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
    }
    .card-list {
        grid-template-columns: 1fr;
    }
    .profil-desa {
        grid-template-columns: 1fr;
        padding: 25px;
    }
}
CSS;

include 'includes/header.php';
?>

<section class="hero-section" <?php if ($hero_background): ?>style="background-image: url('<?php echo esc($hero_background); ?>');"<?php endif; ?>>
    <div class="container hero-content">
        <h1 class="display-4 fw-bold">Sistem Desa Gembong Kulon</h1>
        <p class="lead mb-4">Layanan digital terpadu untuk pengaduan warga, surat online, berita desa, UMKM unggulan, dan kalender kegiatan secara real time.</p>
        <div class="d-flex justify-content-center flex-wrap gap-3">
            <a href="buat_pengaduan.php" class="btn btn-light btn-lg" style="padding: 15px 30px; font-weight: 600;">
                <i class="fas fa-bullhorn"></i> Ajukan Pengaduan
            </a>
            <a href="surat_online.php" class="btn btn-outline-light btn-lg" style="padding: 15px 30px; font-weight: 600;">
                <i class="fas fa-file-alt"></i> Permohonan Surat
            </a>
        </div>
    </div>
</section>

<section class="container py-4">
    <div class="section-title">
        <h2>Statistik Pengaduan & Pelayanan</h2>
        <p class="text-muted">Rekapitulasi terkini per <?php echo date('d M Y'); ?></p>
    </div>
    <div class="stat-grid">
        <div class="stat-card">
            <i class="fas fa-clipboard-list" style="font-size: 2.5rem; color: var(--primary-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>Total Pengaduan</p>
            <h3><?php echo esc($stats['total_pengaduan']); ?></h3>
        </div>
        <div class="stat-card">
            <i class="fas fa-clock" style="font-size: 2.5rem; color: var(--warning-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>Menunggu Verifikasi</p>
            <h3><?php echo esc($stats['menunggu']); ?></h3>
        </div>
        <div class="stat-card">
            <i class="fas fa-spinner" style="font-size: 2.5rem; color: var(--info-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>Sedang Diproses</p>
            <h3><?php echo esc($stats['diproses']); ?></h3>
        </div>
        <div class="stat-card">
            <i class="fas fa-check-circle" style="font-size: 2.5rem; color: var(--success-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>Selesai</p>
            <h3><?php echo esc($stats['selesai']); ?></h3>
        </div>
        <div class="stat-card">
            <i class="fas fa-file-alt" style="font-size: 2.5rem; color: var(--primary-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>Surat Diproses</p>
            <h3><?php echo esc($stats['surat_diproses']); ?></h3>
        </div>
        <div class="stat-card">
            <i class="fas fa-store" style="font-size: 2.5rem; color: var(--primary-color); margin-bottom: 15px; opacity: 0.8;"></i>
            <p>UMKM Terverifikasi</p>
            <h3><?php echo esc($stats['umkm_verified']); ?></h3>
        </div>
    </div>
</section>

<section class="container py-5">
    <div class="section-title">
        <h2><i class="fas fa-village"></i> Profil Desa</h2>
        <p class="text-muted"><?php echo esc($profil_desa['nama_desa']); ?> · <?php echo esc($profil_desa['alamat_desa']); ?></p>
    </div>
    <div class="profil-desa">
        <div>
            <h3 style="color: var(--primary-color); margin-bottom: 20px; font-size: 2rem;">
                <i class="fas fa-landmark"></i> <?php echo esc($profil_desa['nama_desa']); ?>
            </h3>
            <p style="line-height: 1.8; color: #555; margin-bottom: 25px; font-size: 1.05rem;">
                <?php echo esc($profil_desa['deskripsi_desa']); ?>
            </p>
            <div style="background: #f8f9fa; padding: 25px; border-radius: 12px; margin-bottom: 25px; border-left: 4px solid var(--primary-color);">
                <h4 style="color: var(--primary-color); margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-bullseye"></i> Visi & Misi
                </h4>
                <p style="line-height: 1.8; color: #555; margin: 0;">
                    <?php echo nl2br(esc($profil_desa['visi_misi'])); ?>
                </p>
            </div>
            <div style="display: grid; gap: 15px;">
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-map-marker-alt" style="font-size: 1.5rem; color: var(--primary-color);"></i>
                    <div>
                        <strong style="color: var(--primary-color); display: block; margin-bottom: 3px;">Alamat</strong>
                        <span style="color: #666;"><?php echo esc($profil_desa['alamat_desa']); ?></span>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-phone" style="font-size: 1.5rem; color: var(--primary-color);"></i>
                    <div>
                        <strong style="color: var(--primary-color); display: block; margin-bottom: 3px;">Telepon</strong>
                        <span style="color: #666;"><?php echo esc($profil_desa['telepon_desa']); ?></span>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-envelope" style="font-size: 1.5rem; color: var(--primary-color);"></i>
                    <div>
                        <strong style="color: var(--primary-color); display: block; margin-bottom: 3px;">Email</strong>
                        <a href="mailto:<?php echo esc($profil_desa['email_desa']); ?>" style="color: var(--primary-color); text-decoration: none;">
                            <?php echo esc($profil_desa['email_desa']); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <?php if ($hero_background): ?>
                <img src="<?php echo esc($hero_background); ?>" alt="Profil Desa">
            <?php else: ?>
                <div class="mask-gradient">
                    <i class="fas fa-digital-tachograph" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.9;"></i>
                    <h4 style="font-size: 1.8rem; margin-bottom: 20px;">Desa Digital</h4>
                    <p style="line-height: 1.8; font-size: 1.05rem; opacity: 0.95;">
                        Layanan publik berbasis data dengan transparansi APBDes, keterbukaan pengaduan, dan dukungan UMKM unggulan.
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="py-5 bg-light">
    <div class="container">
        <div class="section-title">
            <h2><i class="fas fa-clipboard-list"></i> Pengaduan Terbaru</h2>
            <p class="text-muted">Pantau progres secara real time</p>
        </div>
        <div class="card-list">
            <?php if (empty($latest_pengaduan)): ?>
                <div class="empty-state-card">
                    <i class="fas fa-inbox"></i>
                    <p><strong>Belum ada pengaduan yang masuk.</strong></p>
                    <p style="font-size: 0.95rem; margin-top: 10px;">Jadilah yang pertama untuk mengajukan pengaduan dan membantu membangun desa yang lebih baik.</p>
                    <a href="buat_pengaduan.php" class="btn btn-primary mt-3">
                        <i class="fas fa-plus"></i> Ajukan Pengaduan Pertama
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($latest_pengaduan as $pengaduan): ?>
                    <div class="card-item">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="status-badge status-<?php echo esc(strtolower($pengaduan['status'])); ?>">
                                <i class="fas fa-circle"></i> <?php echo esc(ucfirst($pengaduan['status'])); ?>
                            </span>
                            <span class="badge-prioritas <?php echo esc(strtolower($pengaduan['prioritas'] ?? 'sedang')); ?>">
                                <i class="fas fa-flag"></i> <?php echo esc(ucfirst($pengaduan['prioritas'] ?? 'sedang')); ?>
                            </span>
                        </div>
                        <h5 style="color: var(--primary-color); margin-bottom: 15px; font-weight: 700;">
                            <?php echo esc($pengaduan['judul']); ?>
                        </h5>
                        <p class="text-muted" style="flex-grow: 1; margin-bottom: 15px;">
                            <?php echo esc(substr($pengaduan['deskripsi'], 0, 120)); ?>...
                        </p>
                        <div class="d-flex justify-content-between align-items-center mb-3" style="padding-top: 15px; border-top: 1px solid var(--border-color);">
                            <small style="color: #666;">
                                <i class="fas fa-tag" style="color: var(--primary-color);"></i>
                                <?php echo esc($pengaduan['nama_kategori'] ?? '-'); ?>
                            </small>
                            <small style="color: #666;">
                                <i class="fas fa-calendar-alt" style="color: var(--primary-color);"></i>
                                <?php echo format_tanggal($pengaduan['tanggal_pengaduan']); ?>
                            </small>
                        </div>
                        <a href="cek_status.php?kode=<?php echo urlencode(format_ticket($pengaduan)); ?>" class="btn btn-primary btn-sm w-100">
                            <i class="fas fa-eye"></i> Detail & Tracking
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="container py-5">
    <div class="section-title">
        <h2><i class="fas fa-newspaper"></i> Berita Desa</h2>
        <p class="text-muted">Informasi resmi dari Pemerintah Desa</p>
    </div>
    <div class="card-list">
        <?php if (empty($berita_terbaru)): ?>
            <div class="empty-state-card">
                <i class="fas fa-newspaper"></i>
                <p><strong>Belum ada berita dipublikasi.</strong></p>
                <p style="font-size: 0.95rem; margin-top: 10px;">Informasi terbaru dari Pemerintah Desa akan ditampilkan di sini.</p>
            </div>
        <?php else: ?>
            <?php foreach ($berita_terbaru as $berita): ?>
                <div class="card-item">
                    <?php if (!empty($berita['gambar_utama'])): ?>
                        <img src="uploads/<?php echo esc($berita['gambar_utama']); ?>" alt="<?php echo esc($berita['judul']); ?>" style="width: 100%; height: 200px; object-fit: cover; border-radius: 12px; margin-bottom: 20px;">
                    <?php else: ?>
                        <div style="width: 100%; height: 200px; background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-newspaper" style="font-size: 3rem; color: rgba(255,255,255,0.5);"></i>
                        </div>
                    <?php endif; ?>
                    <span class="badge" style="background: var(--primary-color); color: #fff; margin-bottom: 15px; padding: 6px 12px;">
                        <i class="fas fa-calendar"></i> <?php echo format_tanggal($berita['tanggal_publish']); ?>
                    </span>
                    <h4 style="color: var(--primary-color); margin-bottom: 15px; font-weight: 700;">
                        <?php echo esc($berita['judul']); ?>
                    </h4>
                    <p class="text-muted" style="flex-grow: 1; margin-bottom: 15px; line-height: 1.7;">
                        <?php echo esc(substr(strip_tags($berita['konten']), 0, 140)); ?>...
                    </p>
                    <div style="padding-top: 15px; border-top: 1px solid var(--border-color); margin-bottom: 15px;">
                        <small class="text-muted">
                            <i class="fas fa-user" style="color: var(--primary-color);"></i>
                            Oleh <?php echo esc($berita['penulis'] ?? 'Admin Desa'); ?>
                        </small>
                    </div>
                    <a href="berita_detail.php?id=<?php echo esc($berita['id']); ?>" class="btn btn-primary btn-sm w-100">
                        <i class="fas fa-book-open"></i> Baca Selengkapnya
                    </a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<section class="py-5 bg-light">
    <div class="container">
        <div class="section-title">
            <h2><i class="fas fa-store"></i> UMKM Unggulan</h2>
            <p class="text-muted">Produk lokal terbaik dari warga Gembong Kulon</p>
        </div>
        <div class="card-list">
            <?php if (empty($umkm_unggulan)): ?>
                <div class="empty-state-card">
                    <i class="fas fa-store"></i>
                    <p><strong>Belum ada UMKM terverifikasi.</strong></p>
                    <p style="font-size: 0.95rem; margin-top: 10px;">UMKM terverifikasi akan ditampilkan di sini untuk mendukung ekonomi lokal.</p>
                </div>
            <?php else: ?>
                <?php foreach ($umkm_unggulan as $umkm): ?>
                    <div class="card-item umkm-card">
                        <?php if (!empty($umkm['gambar_umkm'])): ?>
                            <img src="uploads/<?php echo esc($umkm['gambar_umkm']); ?>" alt="<?php echo esc($umkm['nama_umkm']); ?>">
                        <?php else: ?>
                            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-store" style="font-size: 3rem; color: rgba(255,255,255,0.5);"></i>
                            </div>
                        <?php endif; ?>
                        <span class="badge-kategori">
                            <?php echo esc(ucfirst($umkm['kategori'] ?? 'lainnya')); ?>
                        </span>
                        <h4 style="color: var(--primary-color); margin-bottom: 15px; font-weight: 700;">
                            <?php echo esc($umkm['nama_umkm']); ?>
                        </h4>
                        <p class="text-muted" style="flex-grow: 1; margin-bottom: 15px; line-height: 1.7;">
                            <?php echo esc(substr($umkm['deskripsi'], 0, 120)); ?>...
                        </p>
                        <div style="padding-top: 15px; border-top: 1px solid var(--border-color);">
                            <small style="color: #666;">
                                <i class="fas fa-user" style="color: var(--primary-color);"></i>
                                <?php echo esc($umkm['pemilik'] ?? 'Warga'); ?>
                            </small>
                            <?php if (!empty($umkm['telepon'])): ?>
                                <br>
                                <small style="color: #666;">
                                    <i class="fas fa-phone" style="color: var(--primary-color);"></i>
                                    <?php echo esc($umkm['telepon']); ?>
                                </small>
                            <?php endif; ?>
                        </div>
                        <a href="umkm.php#umkm-<?php echo esc($umkm['id']); ?>" class="btn btn-primary btn-sm w-100 mt-3">
                            <i class="fas fa-info-circle"></i> Lihat Detail
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="container py-5">
    <div class="section-title">
        <h2><i class="fas fa-calendar-alt"></i> Kalender Desa (Realtime)</h2>
        <p class="text-muted">Agenda rapat, kegiatan warga, dan hari penting desa</p>
    </div>
    <?php if (empty($kalender_events)): ?>
        <div class="empty-state-card" style="max-width: 800px; margin: 0 auto;">
            <i class="fas fa-calendar-times"></i>
            <p><strong>Belum ada agenda dalam waktu dekat.</strong></p>
            <p style="font-size: 0.95rem; margin-top: 10px;">Agenda kegiatan desa akan ditampilkan di sini untuk memudahkan warga mengikuti kegiatan.</p>
        </div>
    <?php else: ?>
        <ul class="calendar-list">
            <?php foreach ($kalender_events as $event): ?>
                <li class="calendar-item">
                    <div class="calendar-date">
                        <strong><?php echo date('d', strtotime($event['tanggal_mulai'])); ?></strong>
                        <div><?php echo date('M Y', strtotime($event['tanggal_mulai'])); ?></div>
                    </div>
                    <div style="flex: 1;">
                        <h4 style="color: var(--primary-color); margin-bottom: 10px; font-weight: 700;">
                            <?php echo esc($event['judul_acara']); ?>
                        </h4>
                        <p class="mb-2 text-muted" style="line-height: 1.6;">
                            <?php echo esc($event['deskripsi_acara']); ?>
                        </p>
                        <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-top: 10px;">
                            <small style="color: #666;">
                                <i class="fas fa-map-marker-alt" style="color: var(--primary-color);"></i>
                                <?php echo esc($event['lokasi'] ?? 'Balai Desa'); ?>
                            </small>
                            <?php if (!empty($event['waktu_mulai'])): ?>
                                <small style="color: #666;">
                                    <i class="fas fa-clock" style="color: var(--primary-color);"></i>
                                    <?php echo date('H:i', strtotime($event['waktu_mulai'])); ?>
                                    <?php if (!empty($event['waktu_selesai'])): ?>
                                        - <?php echo date('H:i', strtotime($event['waktu_selesai'])); ?>
                                    <?php endif; ?>
                                </small>
                            <?php endif; ?>
                            <small style="color: #666;">
                                <i class="fas fa-tag" style="color: var(--primary-color);"></i>
                                <?php echo esc(ucfirst($event['jenis_acara'] ?? 'lainnya')); ?>
                            </small>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>

<section class="py-5 bg-light how-it-works-section">
    <div class="container">
        <div class="section-title">
            <h2><i class="fas fa-info-circle"></i> Cara Mengakses Layanan</h2>
            <p class="text-muted">Ikuti langkah-langkah berikut untuk menggunakan layanan desa</p>
        </div>
        <div class="how-it-works-grid">
            <div class="how-it-works-card">
                <div class="how-it-works-number primary">1</div>
                <div class="how-it-works-icon">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h3>Buat Akun / Login</h3>
                <p>Gunakan NIK untuk membuat akun warga dan akses dashboard pribadi.</p>
            </div>
            <div class="how-it-works-card">
                <div class="how-it-works-number warning">2</div>
                <div class="how-it-works-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <h3>Ajukan Pengaduan / Surat</h3>
                <p>Lengkapi formulir pengaduan atau surat online dengan bukti pendukung.</p>
            </div>
            <div class="how-it-works-card">
                <div class="how-it-works-number success">3</div>
                <div class="how-it-works-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3>Pantau Status Realtime</h3>
                <p>Administrator dan kepala desa menindaklanjuti, Anda bisa memantau progres kapan saja.</p>
            </div>
        </div>
    </div>
</section>

<section class="cta-section py-5">
    <div class="container">
        <h3 class="mb-3">Berpartisipasi Membangun Desa</h3>
        <p class="lead mb-4">Laporkan aspirasi, ikuti agenda desa, dan dukung UMKM lokal.</p>
        <a href="buat_pengaduan.php" class="btn btn-outline-light btn-lg me-3" style="padding: 15px 30px; font-weight: 600;">
            <i class="fas fa-paper-plane"></i> Laporkan Sekarang
        </a>
        <a href="user_login.php" class="btn btn-light btn-lg" style="padding: 15px 30px; font-weight: 600;">
            <i class="fas fa-sign-in-alt"></i> Masuk Dashboard
        </a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

