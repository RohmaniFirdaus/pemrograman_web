<?php
require_once '../config/config.php';
requireRole(['pimpinan']);

$pageTitle = 'Dashboard Pimpinan';
$currentModule = 'dashboard';

$user = getCurrentUser();
$conn = getDBConnection();

// Overview Kampus
$total_mhs = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'active'")->fetch_assoc()['total'];
$total_dosen = $conn->query("SELECT COUNT(*) as total FROM dosen WHERE status = 'active'")->fetch_assoc()['total'];
$total_mk = $conn->query("SELECT COUNT(*) as total FROM mata_kuliah WHERE status = 'active'")->fetch_assoc()['total'];
$total_aktif = $conn->query("SELECT COUNT(*) as total FROM mahasiswa WHERE status = 'active'")->fetch_assoc()['total'];

// Status Keuangan YTD
$ukt_terbayar = $conn->query("SELECT SUM(total_bayar) as total FROM tagihan WHERE status = 'paid' OR status = 'lunas'")->fetch_assoc()['total'] ?? 0;
$ukt_tertunggak = $conn->query("SELECT SUM(sisa_tagihan) as total FROM tagihan WHERE status IN ('open', 'pending')")->fetch_assoc()['total'] ?? 0;
$beasiswa_tersalurkan = $conn->query("SELECT SUM(nominal) as total FROM beasiswa WHERE status = 'dicairkan'")->fetch_assoc()['total'] ?? 0;

// Pengaduan Terbaru by Priority
$pengaduan_high = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE prioritas = 'high' AND status IN ('menunggu', 'diproses')")->fetch_assoc()['total'];
$pengaduan_medium = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE prioritas = 'medium' AND status IN ('menunggu', 'diproses')")->fetch_assoc()['total'];
$pengaduan_low = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE prioritas = 'low' AND status IN ('menunggu', 'diproses')")->fetch_assoc()['total'];

$conn->close();

require_once '../includes/header.php';
?>

<div class="space-y-6">
    <h1 class="text-3xl font-bold text-gray-800">Dashboard Pimpinan</h1>
    
    <!-- Overview Kampus -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Overview Kampus</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="text-center">
                <div class="text-4xl font-bold text-green-600 mb-2"><?= $total_mhs ?></div>
                <div class="text-gray-600">Mahasiswa</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold text-blue-600 mb-2"><?= $total_dosen ?></div>
                <div class="text-gray-600">Dosen</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold text-purple-600 mb-2"><?= $total_mk ?></div>
                <div class="text-gray-600">Mata Kuliah</div>
            </div>
            <div class="text-center">
                <div class="text-4xl font-bold text-orange-600 mb-2"><?= $total_aktif ?></div>
                <div class="text-gray-600">Aktif</div>
            </div>
        </div>
    </div>
    
    <!-- Status Keuangan YTD -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Status Keuangan (YTD)</h2>
        <div class="space-y-4">
            <div class="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-600 text-2xl mr-3"></i>
                    <div>
                        <p class="font-semibold text-gray-800">UKT Terbayar</p>
                        <p class="text-2xl font-bold text-green-600"><?= formatRupiah($ukt_terbayar) ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-hourglass-half text-yellow-600 text-2xl mr-3"></i>
                    <div>
                        <p class="font-semibold text-gray-800">UKT Tertunggak</p>
                        <p class="text-2xl font-bold text-yellow-600"><?= formatRupiah($ukt_tertunggak) ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-money-bill-wave text-blue-600 text-2xl mr-3"></i>
                    <div>
                        <p class="font-semibold text-gray-800">Beasiswa Tersalurkan</p>
                        <p class="text-2xl font-bold text-blue-600"><?= formatRupiah($beasiswa_tersalurkan) ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <a href="<?= BASE_URL ?>laporan/keuangan.php" class="text-green-600 hover:text-green-700">
                <i class="fas fa-download mr-2"></i>Download Laporan Keuangan
            </a>
        </div>
    </div>
    
    <!-- Pengaduan Terbaru by Priority -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800">Pengaduan Terbaru (by Priority)</h2>
            <a href="<?= BASE_URL ?>laporan/analytics.php" class="text-green-600 hover:text-green-700 text-sm">
                Lihat Detail Analytics <i class="fas fa-arrow-right ml-1"></i>
            </a>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="border-l-4 border-red-500 pl-4 py-3 bg-red-50 rounded">
                <div class="flex items-center mb-2">
                    <div class="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
                    <span class="font-semibold text-gray-800">HIGH</span>
                </div>
                <p class="text-3xl font-bold text-red-600"><?= $pengaduan_high ?></p>
            </div>
            <div class="border-l-4 border-yellow-500 pl-4 py-3 bg-yellow-50 rounded">
                <div class="flex items-center mb-2">
                    <div class="w-4 h-4 bg-yellow-500 rounded-full mr-2"></div>
                    <span class="font-semibold text-gray-800">MEDIUM</span>
                </div>
                <p class="text-3xl font-bold text-yellow-600"><?= $pengaduan_medium ?></p>
            </div>
            <div class="border-l-4 border-green-500 pl-4 py-3 bg-green-50 rounded">
                <div class="flex items-center mb-2">
                    <div class="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
                    <span class="font-semibold text-gray-800">LOW</span>
                </div>
                <p class="text-3xl font-bold text-green-600"><?= $pengaduan_low ?></p>
            </div>
        </div>
    </div>
    
    <!-- Quick Links -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="<?= BASE_URL ?>nilai/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-star text-green-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800 mb-2">Nilai</h3>
            <p class="text-gray-600 text-sm">Lihat KHS dan Transkrip</p>
        </a>
        <a href="<?= BASE_URL ?>tagihan/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-money-bill-wave text-green-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800 mb-2">Tagihan</h3>
            <p class="text-gray-600 text-sm">Lihat Tagihan & Beasiswa</p>
        </a>
        <a href="<?= BASE_URL ?>laporan/index.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
            <i class="fas fa-chart-bar text-green-600 text-3xl mb-3"></i>
            <h3 class="font-semibold text-gray-800 mb-2">Laporan</h3>
            <p class="text-gray-600 text-sm">Lihat Statistik & Laporan</p>
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>



