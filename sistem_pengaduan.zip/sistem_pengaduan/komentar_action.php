<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$pdo = getDBConnection();

$tipe_entitas = sanitize($_POST['tipe_entitas'] ?? '');
$entitas_id = (int)($_POST['entitas_id'] ?? 0);
$komentar_text = sanitize($_POST['komentar'] ?? '');

if (empty($komentar_text) || !in_array($tipe_entitas, ['berita', 'umkm']) || $entitas_id <= 0) {
    setFlashMessage('error', 'Data tidak valid.');
    header('Location: ' . ($tipe_entitas === 'berita' ? 'berita_detail.php?id=' . $entitas_id : 'umkm_detail.php?id=' . $entitas_id));
    exit;
}

$stmt = $pdo->prepare("
    INSERT INTO komentar (user_id, tipe_entitas, entitas_id, komentar, status) 
    VALUES (?, ?, ?, ?, 'aktif')
");
$stmt->execute([$_SESSION['user_id'], $tipe_entitas, $entitas_id, $komentar_text]);

setFlashMessage('success', 'Komentar berhasil ditambahkan.');
header('Location: ' . ($tipe_entitas === 'berita' ? 'berita_detail.php?id=' . $entitas_id : 'umkm_detail.php?id=' . $entitas_id));
exit;



